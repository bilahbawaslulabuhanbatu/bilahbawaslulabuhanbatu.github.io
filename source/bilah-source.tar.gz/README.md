# BILAH MVP — Tahap 5: kurasi dan uji internal

Bot Informasi, Layanan, Aspirasi, dan Hukum — Bawaslu Kabupaten Labuhanbatu.

## Status

- Halaman publik dan chat simulasi berwarna marun/emas sesuai acuan Ray.
- Proyek Supabase Free bilah-mvp di Singapura sudah dibuat.
- Sebelas tabel, empat peran, lima kategori, RLS dan audit sudah diterapkan.
- Login email/password Supabase dan shell internal sudah dihubungkan.
- Statistik agregat mengambil data aktual melalui RPC dengan pemeriksaan peran.
- Admin utama aktif melalui undangan Auth resmi; pengguna telah mengonfirmasi login dashboard berhasil.
- Chat publik masih simulasi, tidak menyimpan pertanyaan, dan belum memakai AI.
- Pengelolaan dokumen dan uji kutipan sumber internal sudah tersedia di /admin/knowledge.
- Sambungan server Gemini untuk uji admin disiapkan; pemilik perlu menyimpan
  AI_API_KEY di Secrets Supabase sebelum jawaban nyata dapat diuji. Lihat docs/gemini-trial.md.
- Unggah PDF dapat membaca beberapa dokumen otomatis dan menyetujui pilihan sekaligus;
  lihat docs/pdf-import.md untuk batas dan hasil pengujiannya.
- Belum ada dokumen resmi disetujui. Tiket, log pelayanan dan backend chat publik
  masih mengikuti tahap berikutnya; tidak ada data legal atau statistik fiktif.

## Menjalankan

Node.js >=22.13.0 dan npm. Versi dependency dipatok dalam package-lock.json.

```sh
npm ci
cp .env.example .env.local
npm run dev
```

Isi URL dan publishable key Supabase pada .env.local. Key publishable memang
untuk akses klien; semua izin data ditegakkan oleh RLS. Jangan menambahkan
service-role/secret key ke field NEXT_PUBLIC atau ke source repository.

```sh
npm run typecheck
npm test
npm run build
npm start
```

## Hosting

Proyek kanonik memakai Next.js App Router. Guard server memverifikasi Auth dan
profil aktif. Proxy refresh cookie berjalan pada halaman internal. API internal
mendapat konteks pengguna, tidak menggunakan service-role key.

Pratinjau Sites saat ini menggunakan `npm run build:preview`: ekspor statis
halaman publik dan shell internal yang menggunakan SDK Supabase di browser.
Shell client tidak memuat data sebelum getUser dan profil aktif diverifikasi.
RLS membatasi semua request database meskipun UI diubah. Peran pimpinan hanya
mendapat agregat, bukan percakapan mentah. Halaman HTML sendiri tidak berisi
data pribadi atau statistik internal sebelum autentikasi.

Script build-preview hanya menyalin field NEXT_PUBLIC_SUPABASE_* ke build
sementara. Output dist/ tidak memuat API server atau secret. Source Next.js
server tetap dipertahankan untuk hosting backend di tahap berikutnya.

## Database

Snapshot SQL: supabase/schema/bilah_core.sql dan bilah_knowledge.sql. Migrasi kanonik `bilah_core` dan `bilah_knowledge`
tersimpan dalam history proyek Supabase. Jangan menjalankan ulang snapshot
CREATE TABLE pada database yang sudah dibuat. Perubahan berikutnya harus
berupa migrasi baru. Profil Auth baru selalu inactive/petugas; tidak ada
signup bebas yang langsung mendapat akses admin.

`supabase/schema/verify_rls.sql` memeriksa izin memakai data uji dalam transaksi
ROLLBACK. Script ini untuk proyek pengembangan dan dijalankan oleh pengelola
terpercaya. Semua identitas dan catatan uji dibatalkan di akhir transaksi.

## Verifikasi

- TypeScript dan ekspor statis lulus.
- 20 pengujian aturan peran, profil, konfigurasi, simulasi dan pipeline uji lulus.
- Pengujian RLS nyata di Postgres lulus dan tidak meninggalkan data uji.
- Verifikasi SQL kurasi/retrieval lulus, seluruh fixture di-ROLLBACK.
- Security Advisor: tidak ada masalah RLS; pemeriksaan password bocor belum aktif
  (fitur Pro ke atas; tidak mengubah paket Free).
- Login dashboard dikonfirmasi berhasil oleh pengguna.
- Browser QA/visual perangkat nyata belum terverifikasi.

Panduan rinci dan batas tahap ada dalam docs/phase-4.md dan docs/phase-5-knowledge.md.
