Seed demonstrasi dibuat pada fase 7. Jangan memasukkan sumber hukum atau akun fiktif sebagai data resmi.
