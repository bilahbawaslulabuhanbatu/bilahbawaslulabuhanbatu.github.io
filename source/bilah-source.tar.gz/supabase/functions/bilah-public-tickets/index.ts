import {createTicketHandler} from '../../../src/lib/tickets/public-handler.ts';
declare const Deno:{env:{get:(key:string)=>string|undefined};serve:(handler:(req:Request)=>Promise<Response>)=>void};
Deno.serve(createTicketHandler(Deno.env));
