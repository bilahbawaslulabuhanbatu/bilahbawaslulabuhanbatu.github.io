import {createPreviewHandler} from '../../../src/lib/ai/preview-handler.ts';
// Auth.getUser plus active database role checks run in the handler for EVERY
// non-preflight request. Supports modern Auth signing keys and publishable keys.
declare const Deno:{env:{get:(name:string)=>string|undefined};serve:(handler:(req:Request)=>Promise<Response>)=>void};
Deno.serve(createPreviewHandler(Deno.env,fetch,event=>console.warn('BILAH_DIAGNOSTIC '+JSON.stringify(event))));
