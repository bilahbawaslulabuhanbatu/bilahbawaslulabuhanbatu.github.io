import {createPublicChatHandler} from '../../../src/lib/chat/public-handler.ts';
declare const Deno:{env:{get:(key:string)=>string|undefined};serve:(handler:(req:Request)=>Promise<Response>)=>void};
Deno.serve(createPublicChatHandler(Deno.env,fetch,event=>console.info('BILAH_PUBLIC_DIAGNOSTIC',JSON.stringify(event))));
