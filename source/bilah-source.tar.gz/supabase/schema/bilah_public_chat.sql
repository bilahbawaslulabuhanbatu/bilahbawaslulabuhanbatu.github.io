-- Public HTTP handler uses these RPCs server-side. Browsers receive no RPC grants.
create table bilah_private.public_chat_requests (
 id uuid primary key,
 session_hash text not null check(session_hash ~ '^[a-f0-9]{64}$'),
 ip_hash text not null check(ip_hash ~ '^[a-f0-9]{64}$'),
 question_hash text not null check(question_hash ~ '^[a-f0-9]{64}$'),
 conversation_id uuid not null references public.conversations(id) on delete cascade,
 user_message_id uuid not null references public.messages(id) on delete cascade,
 response jsonb,
 created_at timestamptz not null default now()
);
create index public_chat_rate_time on bilah_private.public_chat_requests(created_at);
create index public_chat_rate_ip on bilah_private.public_chat_requests(ip_hash,created_at);
create index public_chat_rate_session on bilah_private.public_chat_requests(session_hash,created_at);
create index public_chat_conversation on bilah_private.public_chat_requests(conversation_id);
create index public_chat_user_message on bilah_private.public_chat_requests(user_message_id);
create table bilah_private.public_ai_calls (
 id bigint generated always as identity primary key,
 request_id uuid not null references bilah_private.public_chat_requests(id) on delete cascade,
 created_at timestamptz not null default now()
);
create index public_ai_calls_time on bilah_private.public_ai_calls(created_at);
create index public_ai_calls_request on bilah_private.public_ai_calls(request_id);
alter table bilah_private.public_chat_requests enable row level security;
alter table bilah_private.public_ai_calls enable row level security;
create policy public_chat_backend_only on bilah_private.public_chat_requests for all to service_role using(true) with check(true);
create policy public_ai_backend_only on bilah_private.public_ai_calls for all to service_role using(true) with check(true);
revoke all on bilah_private.public_chat_requests,bilah_private.public_ai_calls from public,anon,authenticated;
grant select,insert,update on bilah_private.public_chat_requests to service_role;
grant select,insert on bilah_private.public_ai_calls to service_role;
grant usage on sequence bilah_private.public_ai_calls_id_seq to service_role;
create index conversations_session_hash on public.conversations(session_token_hash,expires_at);

create function public.bilah_public_chat_begin(p_request_id uuid,p_session_hash text,p_ip_hash text,p_question_hash text,p_question text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare existing bilah_private.public_chat_requests; conversation uuid; message uuid;
begin
 if current_user <> 'service_role' then raise insufficient_privilege; end if;
 if p_session_hash !~ '^[a-f0-9]{64}$' or p_ip_hash !~ '^[a-f0-9]{64}$' or p_question_hash !~ '^[a-f0-9]{64}$' or char_length(trim(p_question)) not between 1 and 2000 then raise check_violation; end if;
 perform pg_advisory_xact_lock(720061101);
 select * into existing from bilah_private.public_chat_requests where id=p_request_id;
 if found then
  if existing.session_hash<>p_session_hash or existing.question_hash<>p_question_hash then raise insufficient_privilege; end if;
  return jsonb_build_object('state',case when existing.response is null then 'pending' else 'complete' end,'response',existing.response);
 end if;
 if (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '24 hours')>=100
  or (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '1 minute' and (session_hash=p_session_hash or ip_hash=p_ip_hash))>=3
  or (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '24 hours' and (session_hash=p_session_hash or ip_hash=p_ip_hash))>=30 then return jsonb_build_object('state','limited'); end if;
 select id into conversation from public.conversations where session_token_hash=p_session_hash and expires_at>now() and not is_demo order by created_at desc limit 1;
 if conversation is null then insert into public.conversations(session_token_hash) values(p_session_hash) returning id into conversation; end if;
 insert into public.messages(conversation_id,role,content,guardrail_status) values(conversation,'user',p_question,'pending') returning id into message;
 insert into bilah_private.public_chat_requests(id,session_hash,ip_hash,question_hash,conversation_id,user_message_id) values(p_request_id,p_session_hash,p_ip_hash,p_question_hash,conversation,message);
 update public.conversations set last_activity_at=now() where id=conversation;
 return jsonb_build_object('state','new');
end $$;

create function public.bilah_public_ai_reserve(p_request_id uuid) returns boolean
language plpgsql security invoker set search_path='' as $$
begin
 if current_user <> 'service_role' then raise insufficient_privilege; end if;
 perform pg_advisory_xact_lock(720061102);
 if not exists(select 1 from bilah_private.public_chat_requests where id=p_request_id and response is null) then return false; end if;
 if (select count(*) from bilah_private.public_ai_calls where created_at>now()-interval '24 hours')>=50
  or (select count(*) from bilah_private.public_ai_calls where created_at>now()-interval '1 minute')>=6
  or (select count(*) from bilah_private.public_ai_calls where request_id=p_request_id)>=2 then return false; end if;
 insert into bilah_private.public_ai_calls(request_id) values(p_request_id);
 return true;
end $$;

create function public.bilah_public_chat_finish(p_request_id uuid,p_response jsonb,p_response_time_ms integer)
returns boolean language plpgsql security invoker set search_path='' as $$
declare item bilah_private.public_chat_requests; assistant_id uuid;
begin
 if current_user <> 'service_role' then raise insufficient_privilege; end if;
 if jsonb_typeof(p_response)<>'object' or jsonb_typeof(p_response->'sources')<>'array' or char_length(p_response->>'answer') not between 1 and 20000 or octet_length(p_response::text)>50000 then raise check_violation; end if;
 select * into item from bilah_private.public_chat_requests where id=p_request_id for update;
 if not found then return false; end if;
 if item.response is not null then return true; end if;
 insert into public.messages(conversation_id,role,content,reply_to_id,sources,domain_status,guardrail_status,response_time_ms)
 values(item.conversation_id,'assistant',p_response->>'answer',item.user_message_id,p_response->'sources',
 case when p_response->>'decision'='out_of_domain' then 'out_of_domain' when p_response->>'decision'='ambiguous' then 'ambiguous' else 'in_domain' end,
 p_response->>'decision',greatest(0,least(p_response_time_ms,120000))) returning id into assistant_id;
 update public.messages set guardrail_status=p_response->>'decision',domain_status=case when p_response->>'decision'='out_of_domain' then 'out_of_domain' when p_response->>'decision'='ambiguous' then 'ambiguous' else 'in_domain' end where id=item.user_message_id;
 update bilah_private.public_chat_requests set response=p_response||jsonb_build_object('messageId',assistant_id,'recorded',true) where id=p_request_id;
 update public.conversations set last_activity_at=now() where id=item.conversation_id;
 return true;
end $$;
revoke all on function public.bilah_public_chat_begin(uuid,text,text,text,text),public.bilah_public_ai_reserve(uuid),public.bilah_public_chat_finish(uuid,jsonb,integer) from public,anon,authenticated;
grant execute on function public.bilah_public_chat_begin(uuid,text,text,text,text),public.bilah_public_ai_reserve(uuid),public.bilah_public_chat_finish(uuid,jsonb,integer) to service_role;

-- Prefer application instructions over templates when asking how to submit an election dispute.
create function public.bilah_public_search_knowledge(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,section_reference text,content text,score real,source_origin text,source_filename text,source_sha256 text)
language plpgsql stable security invoker set search_path='' as $$
declare query_value tsquery; report_intent boolean; dispute_intent boolean;
begin
 if current_user <> 'service_role' then
  raise insufficient_privilege using message='Akses dibatasi';
 end if;
 if coalesce(cardinality(search_terms),0)=0 or cardinality(search_terms)>24 then return; end if;
 select to_tsquery('simple'::regconfig,string_agg(quote_literal(t),' | ')),
  bool_or(t in ('lapor','melapor','melaporkan','laporkan','pelaporan')),
  bool_or(t='sengketa') and bool_or(t in ('permohonan','mengajukan','pengajuan','ajukan','mengajukannya','daftar','mendaftar'))
 into query_value,report_intent,dispute_intent
 from (select distinct lower(v) as t from unnest(search_terms) as v where v ~ '^[a-zA-Z0-9]{2,40}$') terms;
 if query_value is null then return; end if;
 return query
 with candidates as (
  select d.id as doc_id,c.id as cid,d.title as doc_title,d.version as doc_version,d.source_url as url,
   c.section_reference as section,c.content as body,d.source_origin as origin,d.source_filename as filename,d.source_sha256 as sha,
   c.chunk_index,
   ts_rank_cd(setweight(to_tsvector('simple'::regconfig,d.title),'A')||c.search_vector,query_value) as base_rank,
   lower(regexp_replace(c.content,'\s+',' ','g')) as flat_body
  from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id
  where d.status='active' and d.visibility='public' and c.document_version=d.version
   and (d.effective_date is null or d.effective_date<=((now() at time zone 'Asia/Jakarta')::date))
   and (d.category_id is null or exists(select 1 from public.categories cat where cat.id=d.category_id and cat.is_active))
   and (to_tsvector('simple'::regconfig,d.title)||c.search_vector) @@ query_value
 ), ranked as (
  select candidates.*,
   case when dispute_intent then
    base_rank/(1+base_rank)
    + case when flat_body ~ 'permohonan.{0,100}disampaikan oleh pemohon dengan cara' then 8 else 0 end
    + case when flat_body ~ 'paragraf [[:digit:]]+ permohonan secara (tidak )?langsung' then 7 else 0 end
    + case when flat_body ~ 'penyampaian permohonan secara (tidak )?langsung.{0,180}(loket|sips)' then 5 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}disampaikan secara tertulis' then 4 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}harus dilampiri' then 5 else 0 end
    + case when flat_body ~ 'pemohon menyampaikan permohonan' then 2 else 0 end
    - case when flat_body like '%pihak terkait%' and not ('terkait'=any(search_terms)) then 3 else 0 end
    - case when flat_body ~ 'dalam hal ini mengajukan|berisi uraian|nama pemohon[[:space:]]*:' then 12 else 0 end
   when report_intent then
    -- Bound repetition's influence; prefer instructions over internal recaps/templates.
    base_rank/(1+base_rank)
    + case when flat_body ~ 'laporan.{0,100}disampaikan dengan cara' then 4 else 0 end
    + case when flat_body ~ 'penyampaian laporan.{0,100}dilakukan dengan cara' then 3 else 0 end
    + case when flat_body ~ 'pelapor (menyampaikan|mengisi|menyerahkan)' then 1.5 else 0 end
    + case when flat_body ~ 'pelapor.{0,120}terdiri atas|laporan.{0,100}disampaikan paling lama' then 1 else 0 end
    - case when flat_body like '%kop pengawas pemilu%' then 2 else 0 end
   else base_rank end as relevance
  from candidates
 )
 select doc_id,cid,doc_title,doc_version,url,section,body,relevance::real,origin,filename,sha
 from ranked order by relevance desc,doc_id,chunk_index limit 5;
end $$;
revoke all on function public.bilah_public_search_knowledge(text[]) from public,anon,authenticated;
grant execute on function public.bilah_public_search_knowledge(text[]) to service_role;
