begin;
create temporary table bilah_test_identities(role_name text primary key,id uuid default gen_random_uuid());
insert into bilah_test_identities(role_name) values ('admin'),('pimpinan'),('petugas'),('superadmin'),('inactive');
insert into auth.users(id,aud,role,email,email_confirmed_at,created_at,updated_at)
 select id,'authenticated','authenticated','bilah-rls-'||role_name||'@example.invalid',now(),now(),now() from bilah_test_identities;
update public.users u set role_id=r.id,is_active=(i.role_name<>'inactive')
 from bilah_test_identities i,public.roles r where u.id=i.id and r.name=(case when i.role_name='inactive' then 'admin' else i.role_name end);
create temporary table bilah_test_records(conversation_id uuid default gen_random_uuid(),ticket_id uuid default gen_random_uuid());
insert into bilah_test_records default values;
insert into public.conversations(id,session_token_hash) select conversation_id,repeat('a',64) from bilah_test_records;
insert into public.messages(conversation_id,role,content) select conversation_id,'user','Pertanyaan uji izin; transaksi akan dibatalkan' from bilah_test_records;
insert into public.tickets(id,ticket_number,conversation_id,question,assigned_to,access_token_hash,idempotency_key)
 select x.ticket_id,'BILAH-TEST-ROLLBACK',x.conversation_id,'Uji izin',u.id,repeat('b',64),gen_random_uuid()
 from bilah_test_records x,bilah_test_identities u where u.role_name='petugas';
grant select on bilah_test_identities,bilah_test_records to authenticated;
create function pg_temp.assert_bilah(condition boolean,label text) returns void language plpgsql as $$
begin if not coalesce(condition,false) then raise exception 'BILAH RLS FAILED: %',label; end if; end $$;
create function pg_temp.use_bilah_identity(label text) returns void language plpgsql as $$
declare who uuid; begin select id into who from pg_temp.bilah_test_identities where role_name=label;
 perform set_config('request.jwt.claims',json_build_object('sub',who,'role','authenticated')::text,true);
 perform set_config('request.jwt.claim.sub',who::text,true);
end $$;
set local role authenticated;
select pg_temp.use_bilah_identity('pimpinan');
select pg_temp.assert_bilah((select count(*)=0 from public.messages),'pimpinan cannot read raw messages');
select pg_temp.assert_bilah((select count(*)=0 from public.tickets),'pimpinan cannot read tickets');
select pg_temp.assert_bilah((public.bilah_service_statistics()->>'total_questions')::int=1,'pimpinan can read aggregate');
with changed as (update public.users set is_active=false returning id)
 select pg_temp.assert_bilah(count(*)=0,'pimpinan cannot update profiles') from changed;
select pg_temp.use_bilah_identity('petugas');
select pg_temp.assert_bilah((select count(*)=1 from public.tickets),'assigned petugas can read ticket');
select pg_temp.assert_bilah((select count(*)=0 from public.messages),'petugas cannot browse raw messages');
update public.tickets set status='dalam_proses' where id=(select ticket_id from bilah_test_records);
do $$ begin
 begin
   update public.tickets set priority='tinggi' where id=(select ticket_id from pg_temp.bilah_test_records);
   raise exception 'BILAH RLS FAILED: petugas changed priority';
 exception when insufficient_privilege then null; end;
 begin perform public.bilah_service_statistics();
   raise exception 'BILAH RLS FAILED: petugas read aggregate';
 exception when insufficient_privilege then null; end;
end $$;
select pg_temp.use_bilah_identity('admin');
select pg_temp.assert_bilah((select count(*)=1 from public.messages),'admin can read raw messages');
with changed as (update public.users set is_active=false where id=(select id from bilah_test_identities where role_name='petugas') returning id)
 select pg_temp.assert_bilah(count(*)=0,'admin cannot change user permissions') from changed;
select pg_temp.use_bilah_identity('inactive');
select pg_temp.assert_bilah((select count(*)=0 from public.messages),'inactive account cannot read messages');
do $$ begin
 begin perform public.bilah_service_statistics();
   raise exception 'BILAH RLS FAILED: inactive account read aggregate';
 exception when insufficient_privilege then null; end;
end $$;
select pg_temp.use_bilah_identity('superadmin');
select pg_temp.assert_bilah((select count(*)=5 from public.users),'superadmin reads internal users');
update public.users set display_name='Uji rollback' where id=(select id from bilah_test_identities where role_name='petugas');
reset role;
set local role anon;
do $$ begin
 begin perform * from public.messages;
   raise exception 'BILAH RLS FAILED: anon can read messages';
 exception when insufficient_privilege then null; end;
 begin perform public.bilah_service_statistics();
   raise exception 'BILAH RLS FAILED: anon can read aggregate';
 exception when insufficient_privilege then null; end;
end $$;
reset role;
rollback;
select jsonb_build_object('rls_checks','passed','test_rows_persisted',false) as verification;
