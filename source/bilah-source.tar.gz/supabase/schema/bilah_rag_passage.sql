alter table public.knowledge_chunks add column if not exists rag_lex tsvector generated always as (to_tsvector('pg_catalog.indonesian'::regconfig,content)) stored;
create or replace function public.bilah_rag_search(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,section_reference text,content text,source_origin text,source_filename text,source_sha256 text,score real)
language plpgsql stable security invoker set search_path='' as $$
begin
if current_user <> 'service_role' and coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then raise insufficient_privilege;end if;
return query with legacy as materialized(
 select a.chunk_id,row_number() over() n from public.bilah_public_search_knowledge(search_terms) a where current_user='service_role'
 union all select a.chunk_id,row_number() over() n from public.bilah_search_knowledge(search_terms) a where current_user<>'service_role'
), semantic as materialized(select s.chunk_id,row_number() over() n from public.bilah_rag_latent(search_terms) s),
definitions as materialized(select c.id id,count(distinct t) cnt from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id and d.version=c.document_version cross join unnest(search_terms[1:24]) t where 'ragdef'=any(search_terms) and t ~ '^[a-z]{3,30}$' and t not in ('ragdef','maksud','arti','beda','nomor','tahun','menurut','perbawaslu') and d.status='active' and d.visibility='public' and d.rag_review_note is null and (d.effective_date is null or d.effective_date<=current_date) and (d.category_id is null or exists(select from public.categories k where k.id=d.category_id and k.is_active)) and regexp_replace(lower(c.content),'[[:space:]]+',' ','g') ~ ('(^|[^a-z])'||t||' (adalah|merupakan|yang selanjutnya)') group by c.id order by 2 desc,c.id limit 5),
base as(select coalesce(l.chunk_id,s.chunk_id) id,coalesce(1.0/(16+l.n),0)+coalesce(1.05/(16+s.n),0) rank from legacy l full join semantic s using(chunk_id)),
merged as(select coalesce(b.id,f.id) id,coalesce(b.rank,0)+coalesce(0.15*f.cnt,0) rank from base b full join definitions f using(id))
-- Match a short legal relationship within a passage, not just topic frequency on a page.
, phrase_terms as (select array_agg(t order by ix) filter(where t not in ('ragdef','membentuk','dibentuk','siapa','untuk','arti','maksud','ikut','memilih')) topic from unnest(search_terms[1:24]) with ordinality u(t,ix) where t ~ '^[a-z]{2,30}$'),
precision_hits as materialized (
select c.id,
 case when cardinality(pt.topic) between 1 and 3 and txt ~ (array_to_string(pt.topic,' +')||'( pemilu| pemilihan)? (adalah|merupakan|meliputi|terdiri dari|terdiri atas)') then 2 + case when txt ~ ('pasal [0-9]+ '||array_to_string(pt.topic,' +')||'( pemilu| pemilihan)? (adalah|merupakan|meliputi|terdiri)') then 2 else 0 end else 0 end
 + case when search_terms && array['membentuk','dibentuk'] and cardinality(pt.topic) between 1 and 3 and txt ~ (array_to_string(pt.topic,' +')||' [^.]{0,80}dibentuk oleh') then 3 else 0 end
 + case when search_terms && array['tni','polri','asn','pns'] and ts_rank_cd(c.rag_lex,plainto_tsquery('pg_catalog.indonesian',array_to_string(array(select a from unnest(search_terms) a where length(a)>2 and a not in ('tni','polri','ikut','ragdef','boleh','bisa','menurut')),' ')))>0 then 1 + ts_rank_cd(c.rag_lex,plainto_tsquery('pg_catalog.indonesian',array_to_string(array(select a from unnest(search_terms) a where length(a)>2 and a not in ('tni','polri','ikut','ragdef','boleh','bisa','menurut')),' ')),32) else 0 end val
from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id and d.version=c.document_version cross join phrase_terms pt cross join lateral (select regexp_replace(lower(c.content),'[[:space:]]+',' ','g') txt) norm
where d.status='active' and d.visibility='public' and d.rag_review_note is null and (d.effective_date is null or d.effective_date<=current_date) and (d.category_id is null or exists(select from public.categories k where k.id=d.category_id and k.is_active))
), precision_top as (select id,val from precision_hits where val>0 order by val desc,id limit 4),
final_hits as(select coalesce(m.id,p.id) id,coalesce(m.rank,0)+case when p.val is not null then 0.18+p.val*0.02 else 0 end rank from merged m full join precision_top p using(id))
select d.id,c.id,d.title,d.version,d.source_url,c.section_reference,c.content,d.source_origin,d.source_filename,d.source_sha256,m.rank::real from final_hits m join public.knowledge_chunks c on c.id=m.id join public.knowledge_documents d on d.id=c.document_id where d.rag_review_note is null and d.status='active' and d.visibility='public' and c.document_version=d.version order by m.rank desc,c.id limit 14;
end $$;
revoke all on function public.bilah_rag_search(text[]) from public,anon;
grant execute on function public.bilah_rag_search(text[]) to authenticated,service_role;
