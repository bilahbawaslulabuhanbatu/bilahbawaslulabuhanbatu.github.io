create or replace function public.bilah_rag_search(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,section_reference text,content text,source_origin text,source_filename text,source_sha256 text,score real)
language plpgsql stable security invoker set search_path='' as $$
begin
if current_user <> 'service_role' and coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then raise insufficient_privilege;end if;
return query with legacy as materialized(
 select a.chunk_id,row_number() over() n from public.bilah_public_search_knowledge(search_terms) a where current_user='service_role'
 union all select a.chunk_id,row_number() over() n from public.bilah_search_knowledge(search_terms) a where current_user<>'service_role'
), semantic as materialized(select s.chunk_id,row_number() over() n from public.bilah_rag_latent(search_terms) s),
definitions as materialized(select c.id id,count(distinct t) cnt from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id and d.version=c.document_version cross join unnest(search_terms[1:24]) t where 'ragdef'=any(search_terms) and t ~ '^[a-z]{3,30}$' and t not in ('ragdef','maksud','arti','beda','nomor','tahun','menurut','perbawaslu') and d.status='active' and d.visibility='public' and d.rag_review_note is null and (d.effective_date is null or d.effective_date<=current_date) and (d.category_id is null or exists(select from public.categories k where k.id=d.category_id and k.is_active)) and regexp_replace(lower(c.content),'[[:space:]]+',' ','g') ~ ('(^|[^a-z])'||t||' (adalah|merupakan|yang selanjutnya)') group by c.id order by 2 desc,c.id limit 5),
base as(select coalesce(l.chunk_id,s.chunk_id) id,coalesce(1.0/(16+l.n),0)+coalesce(1.05/(16+s.n),0) rank from legacy l full join semantic s using(chunk_id)),
merged as(select coalesce(b.id,f.id) id,coalesce(b.rank,0)+coalesce(0.15*f.cnt,0) rank from base b full join definitions f using(id))
select d.id,c.id,d.title,d.version,d.source_url,c.section_reference,c.content,d.source_origin,d.source_filename,d.source_sha256,m.rank::real from merged m join public.knowledge_chunks c on c.id=m.id join public.knowledge_documents d on d.id=c.document_id where d.rag_review_note is null and d.status='active' and d.visibility='public' and c.document_version=d.version order by m.rank desc,c.id limit 14;
end $$;
revoke all on function public.bilah_rag_search(text[]) from public,anon;
grant execute on function public.bilah_rag_search(text[]) to authenticated,service_role;
