-- BILAH core schema. Hosted migration: bilah_core.
-- No public writes and no legal seed documents are enabled in phase 4.
create schema if not exists bilah_private;
revoke all on schema bilah_private from public, anon;
grant usage on schema bilah_private to authenticated, service_role;

create table public.roles (
  id smallint generated always as identity primary key,
  name text not null unique check (name in ('petugas','admin','pimpinan','superadmin'))
);
insert into public.roles(name) values ('petugas'),('admin'),('pimpinan'),('superadmin');

create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '' check (char_length(display_name) <= 120),
  role_id smallint not null references public.roles(id),
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index users_role_idx on public.users(role_id);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (char_length(name) between 1 and 100),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.knowledge_documents (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 300),
  category_id uuid references public.categories(id),
  source_type text not null check (source_type in ('regulasi','pedoman_internal','informasi_pelayanan','informasi_kelembagaan')),
  document_number text,
  year smallint check (year between 1900 and 2200),
  content text not null default '' check (char_length(content) <= 500000),
  summary text not null default '' check (char_length(summary) <= 10000),
  source_url text check (source_url is null or source_url ~ '^https://'),
  effective_date date,
  status text not null default 'inactive' check (status in ('active','inactive','outdated')),
  version integer not null default 1 check (version > 0),
  verified_by uuid references public.users(id),
  verified_at timestamptz,
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint active_document_verified check (status <> 'active' or (verified_by is not null and verified_at is not null and source_url is not null and length(content) > 0))
);
create index knowledge_documents_category_idx on public.knowledge_documents(category_id);
create index knowledge_documents_verified_by_idx on public.knowledge_documents(verified_by);
create index knowledge_documents_created_by_idx on public.knowledge_documents(created_by);
create index knowledge_documents_active_idx on public.knowledge_documents(status) where status = 'active';

create table public.knowledge_chunks (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.knowledge_documents(id) on delete cascade,
  document_version integer not null check (document_version > 0),
  chunk_index integer not null check (chunk_index >= 0),
  content text not null check (char_length(content) between 1 and 12000),
  section_reference text,
  search_vector tsvector generated always as (to_tsvector('simple'::regconfig,content)) stored,
  created_at timestamptz not null default now(),
  unique(document_id,document_version,chunk_index)
);
create index knowledge_chunks_search_idx on public.knowledge_chunks using gin(search_vector);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  session_token_hash text not null check (length(session_token_hash) = 64),
  created_at timestamptz not null default now(),
  last_activity_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 days'),
  is_demo boolean not null default false
);
create index conversations_expiry_idx on public.conversations(expires_at);
create index conversations_created_idx on public.conversations(created_at);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) between 1 and 20000),
  reply_to_id uuid references public.messages(id) on delete set null,
  category_id uuid references public.categories(id),
  sources jsonb not null default '[]'::jsonb check (jsonb_typeof(sources) = 'array'),
  domain_status text check (domain_status in ('in_domain','out_of_domain','ambiguous')),
  guardrail_status text,
  escalated boolean not null default false,
  response_time_ms integer check (response_time_ms >= 0),
  created_at timestamptz not null default now()
);
create index messages_conversation_idx on public.messages(conversation_id,created_at);
create index messages_reply_idx on public.messages(reply_to_id);
create index messages_category_idx on public.messages(category_id);
create index messages_question_time_idx on public.messages(created_at) where role = 'user';

create table public.tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_number text not null unique,
  conversation_id uuid references public.conversations(id) on delete set null,
  origin_message_id uuid references public.messages(id) on delete set null,
  user_name_optional text check (char_length(user_name_optional) <= 120),
  contact_optional text check (char_length(contact_optional) <= 200),
  category_id uuid references public.categories(id),
  question text not null check (char_length(question) between 1 and 4000),
  summary text not null default '' check (char_length(summary) <= 4000),
  status text not null default 'baru' check (status in ('baru','dalam_proses','menunggu_informasi','selesai')),
  priority text not null default 'normal' check (priority in ('normal','tinggi')),
  assigned_to uuid references public.users(id),
  access_token_hash text not null check (length(access_token_hash) = 64),
  idempotency_key uuid not null unique,
  resolution_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  resolved_at timestamptz,
  constraint ticket_resolved_consistent check ((status = 'selesai' and resolved_at is not null and length(trim(resolution_note)) > 0) or (status <> 'selesai' and resolved_at is null))
);
create index tickets_conversation_idx on public.tickets(conversation_id);
create index tickets_origin_message_idx on public.tickets(origin_message_id);
create index tickets_category_idx on public.tickets(category_id);
create index tickets_assigned_idx on public.tickets(assigned_to,status);
create index tickets_active_idx on public.tickets(status,created_at) where status <> 'selesai';

create table public.ticket_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.tickets(id) on delete cascade,
  author_id uuid not null references public.users(id),
  message text not null check (char_length(message) between 1 and 10000),
  visibility text not null default 'public' check (visibility in ('public','internal')),
  created_at timestamptz not null default now()
);
create index ticket_messages_ticket_idx on public.ticket_messages(ticket_id,created_at);
create index ticket_messages_author_idx on public.ticket_messages(author_id);

create table public.system_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default now()
);
create index system_logs_actor_idx on public.system_logs(actor_id);
create index system_logs_created_idx on public.system_logs(created_at);

create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.messages(id) on delete cascade,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  helpful boolean not null,
  created_at timestamptz not null default now(),
  unique(message_id,conversation_id)
);
create index feedback_conversation_idx on public.feedback(conversation_id);

-- This private lookup is deliberately SECURITY DEFINER to avoid recursive
-- users RLS. It derives identity from auth.uid(), not user-editable metadata.
create function bilah_private.current_role() returns text
language sql stable security definer set search_path = ''
as $$
  select r.name from public.users u join public.roles r on r.id=u.role_id
  where auth.uid() is not null and u.id=auth.uid() and u.is_active
$$;
revoke all on function bilah_private.current_role() from public, anon;
grant execute on function bilah_private.current_role() to authenticated, service_role;

create function bilah_private.touch_updated_at() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin new.updated_at=now(); return new; end $$;
revoke all on function bilah_private.touch_updated_at() from public, anon, authenticated;

create function bilah_private.record_change() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.system_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),lower(tg_op),tg_table_name,
    case when tg_op='DELETE' then old.id::text else new.id::text end,
    jsonb_build_object('record_change',true));
  if tg_op='DELETE' then return old; end if;
  return new;
end $$;
revoke all on function bilah_private.record_change() from public, anon, authenticated;

-- New Auth identities are inactive until explicitly provisioned by the owner.
create function bilah_private.create_inactive_profile() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.users(id,display_name,role_id,is_active)
  select new.id,'',id,false from public.roles where name='petugas';
  return new;
end $$;
revoke all on function bilah_private.create_inactive_profile() from public, anon, authenticated;
create trigger bilah_auth_profile after insert on auth.users
for each row execute function bilah_private.create_inactive_profile();

-- Aggregate only: pimpinan can read counts without reading conversations.
create function bilah_private.service_statistics() returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare total_count bigint; today_count bigint; ticket_count bigint;
active_count bigint; positive_count bigint; feedback_count bigint;
begin
  if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','pimpinan','superadmin') then
    raise insufficient_privilege using message='Akses dibatasi';
  end if;
  select count(*),count(*) filter(where m.created_at >= (date_trunc('day',now() at time zone 'Asia/Jakarta') at time zone 'Asia/Jakarta'))
    into total_count,today_count
    from public.messages m join public.conversations c on c.id=m.conversation_id
    where m.role='user' and not c.is_demo;
  select count(*),count(*) filter(where t.status <> 'selesai') into ticket_count,active_count
    from public.tickets t left join public.conversations c on c.id=t.conversation_id
    where not coalesce(c.is_demo,false);
  select count(*) filter(where f.helpful),count(*) into positive_count,feedback_count
    from public.feedback f join public.conversations c on c.id=f.conversation_id where not c.is_demo;
  return jsonb_build_object('total_questions',total_count,'today_questions',today_count,
    'total_escalations',ticket_count,'active_tickets',active_count,
    'helpful_responses',positive_count,'feedback_count',feedback_count,
    'timezone','Asia/Jakarta','generated_at',now());
end $$;
revoke all on function bilah_private.service_statistics() from public, anon;
grant execute on function bilah_private.service_statistics() to authenticated,service_role;
create function public.bilah_service_statistics() returns jsonb
language sql stable security invoker set search_path = ''
as $$ select bilah_private.service_statistics() $$;
revoke all on function public.bilah_service_statistics() from public,anon;
grant execute on function public.bilah_service_statistics() to authenticated;

-- Grant table capabilities explicitly, then constrain rows with RLS.
revoke all on all tables in schema public from anon, authenticated;
grant select on public.roles,public.users,public.categories,public.knowledge_documents,
 public.knowledge_chunks,public.conversations,public.messages,public.tickets,
 public.ticket_messages,public.system_logs,public.feedback to authenticated;
grant update(display_name,role_id,is_active) on public.users to authenticated;
grant insert,update on public.categories,public.knowledge_documents to authenticated;
grant insert on public.ticket_messages to authenticated;
grant update(status,priority,assigned_to,resolution_note,resolved_at) on public.tickets to authenticated;

alter table public.roles enable row level security;
alter table public.users enable row level security;
alter table public.categories enable row level security;
alter table public.knowledge_documents enable row level security;
alter table public.knowledge_chunks enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.tickets enable row level security;
alter table public.ticket_messages enable row level security;
alter table public.system_logs enable row level security;
alter table public.feedback enable row level security;

create policy roles_internal_read on public.roles for select to authenticated
using ((select bilah_private.current_role()) is not null);
create policy users_internal_read on public.users for select to authenticated
using (id=(select auth.uid()) or (select bilah_private.current_role()) in ('admin','superadmin'));
create policy users_superadmin_update on public.users for update to authenticated
using ((select bilah_private.current_role())='superadmin')
with check ((select bilah_private.current_role())='superadmin');

create policy categories_internal_read on public.categories for select to authenticated
using ((select bilah_private.current_role()) is not null);
create policy categories_admin_insert on public.categories for insert to authenticated
with check ((select bilah_private.current_role()) in ('admin','superadmin'));
create policy categories_admin_update on public.categories for update to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin'))
with check ((select bilah_private.current_role()) in ('admin','superadmin'));
create policy knowledge_admin_read on public.knowledge_documents for select to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin'));
create policy knowledge_admin_insert on public.knowledge_documents for insert to authenticated
with check ((select bilah_private.current_role()) in ('admin','superadmin') and created_by=(select auth.uid()) and status='inactive' and verified_by is null and verified_at is null and version=1);
create policy knowledge_admin_update on public.knowledge_documents for update to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin'))
with check ((select bilah_private.current_role()) in ('admin','superadmin'));
create policy chunks_admin_read on public.knowledge_chunks for select to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin'));
create policy conversations_admin_read on public.conversations for select to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin'));
create policy messages_admin_read on public.messages for select to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin'));
create policy tickets_internal_read on public.tickets for select to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin') or
 ((select bilah_private.current_role())='petugas' and assigned_to=(select auth.uid())));
create policy tickets_internal_update on public.tickets for update to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin') or
 ((select bilah_private.current_role())='petugas' and assigned_to=(select auth.uid())))
with check ((select bilah_private.current_role()) in ('admin','superadmin') or
 ((select bilah_private.current_role())='petugas' and assigned_to=(select auth.uid())));
create policy ticket_messages_internal_read on public.ticket_messages for select to authenticated
using (exists(select 1 from public.tickets t where t.id=ticket_id));
create policy ticket_messages_internal_insert on public.ticket_messages for insert to authenticated
with check (author_id=(select auth.uid()) and exists(select 1 from public.tickets t where t.id=ticket_id));
create policy audit_superadmin_read on public.system_logs for select to authenticated
using ((select bilah_private.current_role())='superadmin');
create policy feedback_admin_read on public.feedback for select to authenticated
using ((select bilah_private.current_role()) in ('admin','superadmin'));

-- Protect sensitive changes beyond RLS row ownership.
create function bilah_private.guard_user_update() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin
  if new.id <> old.id then raise insufficient_privilege; end if;
  if auth.uid()=old.id and (not new.is_active or new.role_id<>old.role_id) then
    raise check_violation using message='Akun tidak dapat menonaktifkan atau mengubah peran dirinya sendiri';
  end if;
  return new;
end $$;
revoke all on function bilah_private.guard_user_update() from public,anon,authenticated;
create trigger bilah_guard_user_update before update on public.users
for each row execute function bilah_private.guard_user_update();

create function bilah_private.guard_ticket_update() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin
  if bilah_private.current_role()='petugas' and
    (new.assigned_to is distinct from old.assigned_to or new.priority is distinct from old.priority) then
    raise insufficient_privilege using message='Penugasan dan prioritas diatur admin';
  end if;
  if new.assigned_to is not null and not exists(
    select 1 from public.users u join public.roles r on r.id=u.role_id
    where u.id=new.assigned_to and u.is_active and r.name in ('petugas','admin','superadmin')) then
    raise check_violation using message='Petugas penanggung jawab tidak valid';
  end if;
  return new;
end $$;
revoke all on function bilah_private.guard_ticket_update() from public,anon,authenticated;
create trigger bilah_guard_ticket_update before update on public.tickets
for each row execute function bilah_private.guard_ticket_update();

-- Trusted service performs KB chunk maintenance in phase 5.
create function bilah_private.guard_document_revision() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin
  if new.content is distinct from old.content or new.source_url is distinct from old.source_url or
     new.document_number is distinct from old.document_number or new.title is distinct from old.title then
    new.version=old.version+1;
    new.status='inactive'; new.verified_by=null; new.verified_at=null;
  else new.version=old.version; end if;
  if new.status='active' and (new.status is distinct from old.status or new.verified_by is distinct from old.verified_by or new.verified_at is distinct from old.verified_at) then
    if new.verified_by is distinct from auth.uid() or auth.uid() is null then
      raise insufficient_privilege using message='Verifikasi harus dilakukan oleh admin yang sedang masuk';
    end if;
    new.verified_at=now();
  end if;
  return new;
end $$;
revoke all on function bilah_private.guard_document_revision() from public,anon,authenticated;
create trigger bilah_document_revision before update on public.knowledge_documents
for each row execute function bilah_private.guard_document_revision();

create trigger bilah_users_timestamp before update on public.users for each row execute function bilah_private.touch_updated_at();
create trigger bilah_categories_timestamp before update on public.categories for each row execute function bilah_private.touch_updated_at();
create trigger bilah_documents_timestamp before update on public.knowledge_documents for each row execute function bilah_private.touch_updated_at();
create trigger bilah_tickets_timestamp before update on public.tickets for each row execute function bilah_private.touch_updated_at();
create trigger bilah_users_audit after insert or update on public.users for each row execute function bilah_private.record_change();
create trigger bilah_categories_audit after insert or update on public.categories for each row execute function bilah_private.record_change();
create trigger bilah_documents_audit after insert or update on public.knowledge_documents for each row execute function bilah_private.record_change();
create trigger bilah_tickets_audit after update on public.tickets for each row execute function bilah_private.record_change();

-- Category labels only. No fabricated legal sources or service records.
insert into public.categories(name,slug) values
 ('Informasi Pemilu','informasi-pemilu'),('Tugas dan Kewenangan Bawaslu','tugas-bawaslu'),
 ('Pengawasan Partisipatif','pengawasan-partisipatif'),('Informasi Pelayanan dan PPID','pelayanan-ppid'),
 ('Pendidikan Hukum Pemilu','pendidikan-hukum-pemilu');
