-- Internal trial only. No anonymous execution or conversation contents logged.
create index system_logs_ai_preview_rate_idx on public.system_logs(actor_id,created_at) where action='ai_preview_attempt';
create function bilah_private.reserve_ai_preview_call() returns boolean
language plpgsql security definer set search_path='' as $$
declare minute_count bigint;day_count bigint;
begin
 if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
  raise insufficient_privilege using message='Akses dibatasi';
 end if;
 perform pg_advisory_xact_lock(hashtextextended('bilah-ai-preview:'||auth.uid()::text,0));
 select count(*) filter(where created_at>=now()-interval '1 minute'),count(*) into minute_count,day_count
 from public.system_logs where actor_id=auth.uid() and action='ai_preview_attempt'
 and created_at>=(date_trunc('day',now() at time zone 'Asia/Jakarta') at time zone 'Asia/Jakarta');
 if minute_count>=3 or day_count>=50 then return false;end if;
 insert into public.system_logs(actor_id,action,entity_type,metadata)
 values(auth.uid(),'ai_preview_attempt','ai_preview','{"scope":"admin_trial"}'::jsonb);
 return true;
end $$;
revoke all on function bilah_private.reserve_ai_preview_call() from public,anon;
grant execute on function bilah_private.reserve_ai_preview_call() to authenticated;
create function public.bilah_reserve_ai_preview_call() returns boolean
language sql security invoker set search_path='' as $$ select bilah_private.reserve_ai_preview_call() $$;
revoke all on function public.bilah_reserve_ai_preview_call() from public,anon;
grant execute on function public.bilah_reserve_ai_preview_call() to authenticated;
