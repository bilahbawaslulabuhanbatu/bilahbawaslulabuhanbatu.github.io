create extension if not exists vector with schema extensions;
create table if not exists bilah_private.rag_terms(term text primary key, direction extensions.vector(32) not null);
alter table bilah_private.rag_terms enable row level security;
revoke all on bilah_private.rag_terms from public,anon,authenticated;
create or replace function bilah_private.rag_vec(t text) returns extensions.vector
language sql stable security definer set search_path='' as $$
select extensions.l2_normalize(extensions.sum(direction)) from bilah_private.rag_terms where term=any(tsvector_to_array(to_tsvector('pg_catalog.indonesian',left(t,16000))))
$$;
revoke all on function bilah_private.rag_vec(text) from public,anon;
grant execute on function bilah_private.rag_vec(text) to authenticated,service_role;
alter table public.knowledge_chunks add column if not exists semantic_vector extensions.vector(32);
create or replace function bilah_private.rag_index_chunk() returns trigger language plpgsql security definer set search_path='' as $$ begin new.semantic_vector=bilah_private.rag_vec(new.content);return new; end $$;
revoke all on function bilah_private.rag_index_chunk() from public,anon,authenticated;
drop trigger if exists rag_index_chunk on public.knowledge_chunks;
create trigger rag_index_chunk before insert or update of content on public.knowledge_chunks for each row execute function bilah_private.rag_index_chunk();
create or replace function public.bilah_rag_search(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,section_reference text,content text,source_origin text,source_filename text,source_sha256 text,score real)
language plpgsql stable security invoker set search_path='' as $$
declare terms text[]; q tsquery; v extensions.vector; begin
if current_user <> 'service_role' and coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then raise insufficient_privilege;end if;
select array_agg(distinct lower(s)) into terms from unnest(search_terms[1:24]) s where s ~ '^[a-zA-Z0-9]{2,40}$';
if terms is null then return;end if;
select to_tsquery('pg_catalog.indonesian',string_agg(quote_literal(t),' | ')) into q from unnest(terms) t;
v=bilah_private.rag_vec(array_to_string(terms,' '));
return query with pool as materialized (
select d.id doc,c.id cid,c.chunk_index ix,d.title ttl,d.version ver,d.source_url url,c.section_reference sec,c.content body,d.source_origin org,d.source_filename fn,d.source_sha256 sha,
ts_rank_cd(to_tsvector('pg_catalog.indonesian',coalesce(d.document_number,'')||' '||coalesce(d.year::text,'')||' '||d.title||' '||c.content),q,32) lex,
case when v is null or c.semantic_vector is null then 0 else greatest(0,1-(c.semantic_vector operator(extensions.<=>) v)) end sim
from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id and d.version=c.document_version
where d.status='active' and d.visibility='public' and (d.effective_date is null or d.effective_date<=current_date)
and (d.category_id is null or exists(select from public.categories k where k.id=d.category_id and k.is_active))
and length(trim(c.content))>=20
), ranks as (select p.*,rank() over(order by lex desc) lr,rank() over(order by sim desc) sr from pool p),
hits as (select r.*, (case when lex>0 then 1.2/(16+lr) else 0 end+case when sim>0.18 then 1.0/(16+sr) else 0 end) sc from ranks r where lex>0 or sim>0.18),
best as (select * from hits order by sc desc,cid limit 5),
neighbors as (select p.*,max(b.sc*(case when b.ix=p.ix then 1 else 0.78 end)) weight from best b join pool p on p.doc=b.doc and abs(p.ix-b.ix)<=1 group by p.doc,p.cid,p.ix,p.ttl,p.ver,p.url,p.sec,p.body,p.org,p.fn,p.sha,p.lex,p.sim)
select doc,cid,ttl,ver,url,sec,body,org,fn,sha,weight::real from neighbors order by weight desc,doc,ix limit 10;
end $$;
revoke all on function public.bilah_rag_search(text[]) from public,anon;
grant execute on function public.bilah_rag_search(text[]) to authenticated,service_role;
create or replace function public.bilah_index_status() returns table(document_id uuid,title text,stage text,chunks bigint,vectors bigint,weak bigint)
language sql stable security invoker set search_path='' as $$
select d.id,d.title,case when count(c.id)=0 then 'Belum terindeks' when count(c.semantic_vector)<count(c.id) then 'Periksa teks tanpa vektor' when d.status<>'active' or d.visibility<>'public' then 'Terindeks, tidak untuk publik' else 'Terindeks' end,count(c.id),count(c.semantic_vector),count(c.id) filter(where length(trim(c.content))<20) from public.knowledge_documents d left join public.knowledge_chunks c on c.document_id=d.id and c.document_version=d.version where bilah_private.current_role() in ('admin','superadmin') group by d.id order by d.title
$$;
revoke all on function public.bilah_index_status() from public,anon;
grant execute on function public.bilah_index_status() to authenticated;
create or replace function public.bilah_reindex_document(target uuid) returns integer
language plpgsql security definer set search_path = '' as $$
declare new public.knowledge_documents; start_at integer; part integer:=0; local_part integer; segment text; page_text text; page_number text;
begin
 if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
   raise insufficient_privilege using message='Pengelolaan sumber hanya untuk admin aktif';
 end if;
 select * into strict new from public.knowledge_documents where id=target for update;
 delete from public.knowledge_chunks where document_id=new.id;
 if length(trim(new.content))=0 then return part; end if;
 if new.source_origin='uploaded_pdf' and new.content like '[[HALAMAN PDF %' then
   foreach segment in array string_to_array(new.content,'[[HALAMAN PDF ') loop
     if segment !~ '^[1-9][0-9]{0,2}\]\]' then continue; end if;
     page_number=split_part(segment,']]',1);
     page_text=trim(substring(segment from strpos(segment,']]')+2));
     if length(page_text)=0 or page_number::integer>new.source_page_count then continue; end if;
     start_at=1;local_part=1;
     while start_at<=length(page_text) loop
       insert into public.knowledge_chunks(document_id,document_version,chunk_index,content,section_reference)
       values(new.id,new.version,part,substring(page_text from start_at for 2400),'Halaman PDF '||page_number||' · bagian '||local_part::text);
       start_at=start_at+2200;part=part+1;local_part=local_part+1;
     end loop;
   end loop;
 else
   start_at=1;
   while start_at<=length(new.content) loop
     insert into public.knowledge_chunks(document_id,document_version,chunk_index,content,section_reference)
     values(new.id,new.version,part,substring(new.content from start_at for 2400),'Bagian '||(part+1)::text);
     start_at=start_at+2200;part=part+1;
   end loop;
 end if;
 return part;
end $$;

revoke all on function public.bilah_reindex_document(uuid) from public,anon;
grant execute on function public.bilah_reindex_document(uuid) to authenticated;
