begin;
select set_config('request.jwt.claim.sub',(select id::text from auth.users where lower(email)='rangkutiray3@gmail.com' and email_confirmed_at is not null),true);
set local role authenticated;
do $$
declare doc uuid; matches integer;
begin
 insert into public.knowledge_documents(title,source_type,content,source_url,visibility,created_by)
 values('PPID fixture zqxppid','informasi_pelayanan','zqxppid PPID permohonan informasi publik. Teks fiktif khusus uji perangkat lunak, bukan prosedur pelayanan.','https://ppid-labuhanbatu.bawaslu.go.id/','public',auth.uid()) returning id into doc;
 perform set_config('bilah.test_document',doc::text,true);
 select count(*) into matches from public.bilah_search_knowledge(array['ppid','permohonan','zqxppid']) where document_id=doc;
 if matches<>0 then raise exception 'Draft PPID leaked'; end if;
 update public.knowledge_documents set status='active',verified_by=auth.uid(),verified_at=now() where id=doc;
 select count(*) into matches from public.bilah_search_knowledge(array['ppid','permohonan','zqxppid']) where document_id=doc;
 if matches<>1 then raise exception 'Approved PPID not retrieved'; end if;
 if exists(select 1 from public.bilah_search_knowledge(array['ppid','permohonan']) where content !~* 'ppid|informasi[[:space:]]+publik|keterbukaan[[:space:]]+informasi|permohonan[[:space:]]+informasi|pelayanan[[:space:]]+informasi' and title !~* 'ppid|informasi publik') then raise exception 'Generic application contaminated PPID context'; end if;
end $$;
reset role;
set local role service_role;
do $$ begin
 if not exists(select 1 from public.bilah_public_search_knowledge(array['ppid','permohonan','zqxppid']) where document_id=current_setting('bilah.test_document')::uuid) then raise exception 'Public PPID retrieval differs'; end if;
 if exists(select 1 from public.bilah_public_search_knowledge(array['ppid','permohonan']) where content !~* 'ppid|informasi[[:space:]]+publik|keterbukaan[[:space:]]+informasi|permohonan[[:space:]]+informasi|pelayanan[[:space:]]+informasi' and title !~* 'ppid|informasi publik') then raise exception 'Public PPID contamination'; end if;
end $$;
reset role;
rollback;
select 'PPID retrieval verified; fixtures rolled back' as result;
