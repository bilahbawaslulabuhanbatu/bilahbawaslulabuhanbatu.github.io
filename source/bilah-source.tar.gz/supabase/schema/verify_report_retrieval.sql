-- Read-only regression against the approved Perbawaslu 7/2022 upload, if present.
begin;
select set_config('request.jwt.claim.sub',(select id::text from auth.users where lower(email)='rangkutiray3@gmail.com' and email_confirmed_at is not null),true);
set local role authenticated;
do $$
declare top_body text; terms text[];
begin
 if exists(select 1 from public.knowledge_documents where title='Peraturan Bawaslu Nomor 7 Tahun 2022' and status='active' and visibility='public') then
  foreach terms slice 1 in array array[
   array['melapor','pelanggaran','pelaporan','laporan'],
   array['melaporkan','pelanggaran','pelaporan','laporan'],
   array['prosedur','pelaporan','pelanggaran','laporan']
  ] loop
   select content into top_body from public.bilah_search_knowledge(terms) limit 1;
   if top_body is null or top_body not like '%SigapLapor%' or top_body not like '%disampaikan dengan cara%' then
    raise exception 'Reporting instructions not retrieved first';
   end if;
  end loop;
 end if;
 if exists(select 1 from public.bilah_search_knowledge(array['zqxunrelated'])) then
  raise exception 'Unrelated query retrieved a source';
 end if;
end $$;
rollback;
select 'report procedure retrieval passed' as result;
