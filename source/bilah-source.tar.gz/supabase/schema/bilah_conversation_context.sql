CREATE OR REPLACE FUNCTION public.bilah_public_chat_begin(p_request_id uuid, p_session_hash text, p_ip_hash text, p_question_hash text, p_question text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare existing bilah_private.public_chat_requests; conversation uuid; message uuid;
begin
 if current_user <> 'service_role' then raise insufficient_privilege; end if;
 if p_session_hash !~ '^[a-f0-9]{64}$' or p_ip_hash !~ '^[a-f0-9]{64}$' or p_question_hash !~ '^[a-f0-9]{64}$' or char_length(trim(p_question)) not between 1 and 2000 then raise check_violation; end if;
 perform pg_advisory_xact_lock(720061101);
 select * into existing from bilah_private.public_chat_requests where id=p_request_id;
 if found then
  if existing.session_hash<>p_session_hash or existing.question_hash<>p_question_hash then raise insufficient_privilege; end if;
  return jsonb_build_object('state',case when existing.response is null then 'pending' else 'complete' end,'response',existing.response);
 end if;
 if (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '24 hours')>=100
  or (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '1 minute' and (session_hash=p_session_hash or ip_hash=p_ip_hash))>=3
  or (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '24 hours' and (session_hash=p_session_hash or ip_hash=p_ip_hash))>=30 then return jsonb_build_object('state','limited'); end if;
 select id into conversation from public.conversations where session_token_hash=p_session_hash and expires_at>now() and not is_demo order by created_at desc limit 1;
 if conversation is null then insert into public.conversations(session_token_hash) values(p_session_hash) returning id into conversation; end if;
 insert into public.messages(conversation_id,role,content,guardrail_status) values(conversation,'user',p_question,'pending') returning id into message;
 insert into bilah_private.public_chat_requests(id,session_hash,ip_hash,question_hash,conversation_id,user_message_id) values(p_request_id,p_session_hash,p_ip_hash,p_question_hash,conversation,message);
 update public.conversations set last_activity_at=now() where id=conversation;
 return jsonb_build_object('state','new','previousQuestions',coalesce((
 select jsonb_agg(recent.content order by recent.created_at desc)
 from (select m.content,m.created_at from public.messages m
 where m.conversation_id=conversation and m.role='user' and m.id<>message
 and m.guardrail_status in ('information','report','no_source')
 and m.created_at > now()-interval '30 minutes'
 order by m.created_at desc limit 3) recent
 ),'[]'::jsonb));
end $function$;

CREATE OR REPLACE FUNCTION public.bilah_public_search_knowledge(search_terms text[])
 RETURNS TABLE(document_id uuid, chunk_id uuid, title text, version integer, source_url text, section_reference text, content text, score real, source_origin text, source_filename text, source_sha256 text)
 LANGUAGE plpgsql
 STABLE
 SET search_path TO ''
AS $function$
declare query_value tsquery; report_intent boolean; dispute_intent boolean;
begin
 if current_user <> 'service_role' then
  raise insufficient_privilege using message='Akses dibatasi';
 end if;
 if coalesce(cardinality(search_terms),0)=0 or cardinality(search_terms)>24 then return; end if;
 select to_tsquery('simple'::regconfig,string_agg(quote_literal(t),' | ')),
  bool_or(t in ('lapor','melapor','melaporkan','laporkan','pelaporan')),
  bool_or(t='sengketa') and bool_or(t in ('permohonan','mengajukan','pengajuan','ajukan','mengajukannya','daftar','mendaftar'))
 into query_value,report_intent,dispute_intent
 from (select distinct lower(v) as t from unnest(search_terms) as v where v ~ '^[a-zA-Z0-9]{2,40}$') terms;
 if query_value is null then return; end if;
 return query
 with candidates as (
  select d.id as doc_id,c.id as cid,d.title as doc_title,d.version as doc_version,d.source_url as url,
   c.section_reference as section,c.content as body,d.source_origin as origin,d.source_filename as filename,d.source_sha256 as sha,
   c.chunk_index,
   ts_rank_cd(setweight(to_tsvector('simple'::regconfig,d.title),'A')||c.search_vector,query_value) as base_rank,
   lower(regexp_replace(c.content,'\s+',' ','g')) as flat_body
  from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id
  where d.status='active' and d.visibility='public' and c.document_version=d.version
   and (not ('ppid'=any(search_terms)) or (d.title||' '||c.content) ~* '(^|[^a-z])ppid([^a-z]|$)|informasi[[:space:]]+publik|keterbukaan[[:space:]]+informasi|permohonan[[:space:]]+informasi|pelayanan[[:space:]]+informasi')
   and (d.effective_date is null or d.effective_date<=((now() at time zone 'Asia/Jakarta')::date))
   and (d.category_id is null or exists(select 1 from public.categories cat where cat.id=d.category_id and cat.is_active))
   and (to_tsvector('simple'::regconfig,d.title)||c.search_vector) @@ query_value
 ), ranked as (
  select candidates.*,
   case when search_terms && array['kampanye','berkampanye']
    and search_terms && array['cuti','gubernur','bupati','walikota','kepala','daerah']
    and not (search_terms && array['pilkada','pemilihan']) then
    base_rank/(1+base_rank)
    + case when doc_title ~* '(uu|undang).{0,20}7.{0,20}2017' then
      case when flat_body ~ 'pasal 281' and flat_body like '%menjalani cuti%' then 14
           when flat_body like '%cuti bagi gubernur%' and flat_body like '%hari libur%' then 13
           when flat_body ~ 'pasal 303' and flat_body like '%gubernur%' then 12
           when flat_body ~ 'pasal 299' and flat_body like '%hak melaksanakan%' then 11
           else 0 end
      else 0 end
   when search_terms && array['ketua','komisioner','pimpinan','anggota']
    and search_terms && array['ri','pusat','indonesia','labuhanbatu']
    and not (search_terms && array['tugas','wewenang','kewenangan','fungsi','syarat','persyaratan','laporan','pelaporan','sengketa']) then
    base_rank/(1+base_rank)
    + case when doc_title ~* 'profil.*pimpinan' and flat_body ~ 'ketua:'
      and (not ('labuhanbatu'=any(search_terms)) or flat_body like '%labuhanbatu%') then 12 else 0 end
   when 'divisi'=any(search_terms) and 'labuhanbatu'=any(search_terms) then
    base_rank/(1+base_rank)
    + case when doc_title ~* 'labuhanbatu' and flat_body ~ 'divisi'
           and flat_body ~ 'partisipasi masyarakat' and flat_body ~ 'penanganan pelanggaran' then 16 else 0 end
    + case when url = 'https://labuhanbatu.bawaslu.go.id/profil/struktur-organisasi-bawaslu-kabupaten-labuhanbatu' then 4 else 0 end
    + case when doc_title ~* '^Peraturan Bawaslu Nomor 3 Tahun 2022'
           and flat_body ~ 'pasal 37 [(]1[)] divisi' then 8 else 0 end
   when dispute_intent then
    base_rank/(1+base_rank)
    + case when flat_body ~ 'permohonan.{0,100}disampaikan oleh pemohon dengan cara' then 8 else 0 end
    + case when flat_body ~ 'paragraf [[:digit:]]+ permohonan secara (tidak )?langsung' then 7 else 0 end
    + case when flat_body ~ 'penyampaian permohonan secara (tidak )?langsung.{0,180}(loket|sips)' then 5 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}disampaikan secara tertulis' then 4 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}harus dilampiri' then 5 else 0 end
    + case when flat_body ~ 'pemohon menyampaikan permohonan' then 2 else 0 end
    - case when flat_body like '%pihak terkait%' and not ('terkait'=any(search_terms)) then 3 else 0 end
    - case when flat_body ~ 'dalam hal ini mengajukan|berisi uraian|nama pemohon[[:space:]]*:' then 12 else 0 end
   when report_intent then
    -- Bound repetition's influence; prefer instructions over internal recaps/templates.
    base_rank/(1+base_rank)
    + case when flat_body ~ 'laporan.{0,100}disampaikan dengan cara' then 4 else 0 end
    + case when flat_body ~ 'penyampaian laporan.{0,100}dilakukan dengan cara' then 3 else 0 end
    + case when flat_body ~ 'pelapor (menyampaikan|mengisi|menyerahkan)' then 1.5 else 0 end
    + case when flat_body ~ 'pelapor.{0,120}terdiri atas|laporan.{0,100}disampaikan paling lama' then 1 else 0 end
    - case when flat_body like '%kop pengawas pemilu%' then 2 else 0 end
   else base_rank end as relevance
  from candidates
 )
 select doc_id,cid,doc_title,doc_version,url,section,body,relevance::real,origin,filename,sha
 from ranked order by relevance desc,doc_id,chunk_index limit 5;
end $function$;

CREATE OR REPLACE FUNCTION public.bilah_search_knowledge(search_terms text[])
 RETURNS TABLE(document_id uuid, chunk_id uuid, title text, version integer, source_url text, section_reference text, content text, score real, source_origin text, source_filename text, source_sha256 text)
 LANGUAGE plpgsql
 STABLE
 SET search_path TO ''
AS $function$
declare query_value tsquery; report_intent boolean; dispute_intent boolean;
begin
 if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
  raise insufficient_privilege using message='Akses dibatasi';
 end if;
 if coalesce(cardinality(search_terms),0)=0 or cardinality(search_terms)>24 then return; end if;
 select to_tsquery('simple'::regconfig,string_agg(quote_literal(t),' | ')),
  bool_or(t in ('lapor','melapor','melaporkan','laporkan','pelaporan')),
  bool_or(t='sengketa') and bool_or(t in ('permohonan','mengajukan','pengajuan','ajukan','mengajukannya','daftar','mendaftar'))
 into query_value,report_intent,dispute_intent
 from (select distinct lower(v) as t from unnest(search_terms) as v where v ~ '^[a-zA-Z0-9]{2,40}$') terms;
 if query_value is null then return; end if;
 return query
 with candidates as (
  select d.id as doc_id,c.id as cid,d.title as doc_title,d.version as doc_version,d.source_url as url,
   c.section_reference as section,c.content as body,d.source_origin as origin,d.source_filename as filename,d.source_sha256 as sha,
   c.chunk_index,
   ts_rank_cd(setweight(to_tsvector('simple'::regconfig,d.title),'A')||c.search_vector,query_value) as base_rank,
   lower(regexp_replace(c.content,'\s+',' ','g')) as flat_body
  from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id
  where d.status='active' and d.visibility='public' and c.document_version=d.version
   and (not ('ppid'=any(search_terms)) or (d.title||' '||c.content) ~* '(^|[^a-z])ppid([^a-z]|$)|informasi[[:space:]]+publik|keterbukaan[[:space:]]+informasi|permohonan[[:space:]]+informasi|pelayanan[[:space:]]+informasi')
   and (d.effective_date is null or d.effective_date<=((now() at time zone 'Asia/Jakarta')::date))
   and (d.category_id is null or exists(select 1 from public.categories cat where cat.id=d.category_id and cat.is_active))
   and (to_tsvector('simple'::regconfig,d.title)||c.search_vector) @@ query_value
 ), ranked as (
  select candidates.*,
   case when search_terms && array['kampanye','berkampanye']
    and search_terms && array['cuti','gubernur','bupati','walikota','kepala','daerah']
    and not (search_terms && array['pilkada','pemilihan']) then
    base_rank/(1+base_rank)
    + case when doc_title ~* '(uu|undang).{0,20}7.{0,20}2017' then
      case when flat_body ~ 'pasal 281' and flat_body like '%menjalani cuti%' then 14
           when flat_body like '%cuti bagi gubernur%' and flat_body like '%hari libur%' then 13
           when flat_body ~ 'pasal 303' and flat_body like '%gubernur%' then 12
           when flat_body ~ 'pasal 299' and flat_body like '%hak melaksanakan%' then 11
           else 0 end
      else 0 end
   when search_terms && array['ketua','komisioner','pimpinan','anggota']
    and search_terms && array['ri','pusat','indonesia','labuhanbatu']
    and not (search_terms && array['tugas','wewenang','kewenangan','fungsi','syarat','persyaratan','laporan','pelaporan','sengketa']) then
    base_rank/(1+base_rank)
    + case when doc_title ~* 'profil.*pimpinan' and flat_body ~ 'ketua:'
      and (not ('labuhanbatu'=any(search_terms)) or flat_body like '%labuhanbatu%') then 12 else 0 end
   when 'divisi'=any(search_terms) and 'labuhanbatu'=any(search_terms) then
    base_rank/(1+base_rank)
    + case when doc_title ~* 'labuhanbatu' and flat_body ~ 'divisi'
           and flat_body ~ 'partisipasi masyarakat' and flat_body ~ 'penanganan pelanggaran' then 16 else 0 end
    + case when url = 'https://labuhanbatu.bawaslu.go.id/profil/struktur-organisasi-bawaslu-kabupaten-labuhanbatu' then 4 else 0 end
    + case when doc_title ~* '^Peraturan Bawaslu Nomor 3 Tahun 2022'
           and flat_body ~ 'pasal 37 [(]1[)] divisi' then 8 else 0 end
   when dispute_intent then
    base_rank/(1+base_rank)
    + case when flat_body ~ 'permohonan.{0,100}disampaikan oleh pemohon dengan cara' then 8 else 0 end
    + case when flat_body ~ 'paragraf [[:digit:]]+ permohonan secara (tidak )?langsung' then 7 else 0 end
    + case when flat_body ~ 'penyampaian permohonan secara (tidak )?langsung.{0,180}(loket|sips)' then 5 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}disampaikan secara tertulis' then 4 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}harus dilampiri' then 5 else 0 end
    + case when flat_body ~ 'pemohon menyampaikan permohonan' then 2 else 0 end
    - case when flat_body like '%pihak terkait%' and not ('terkait'=any(search_terms)) then 3 else 0 end
    - case when flat_body ~ 'dalam hal ini mengajukan|berisi uraian|nama pemohon[[:space:]]*:' then 12 else 0 end
   when report_intent then
    -- Bound repetition's influence; prefer instructions over internal recaps/templates.
    base_rank/(1+base_rank)
    + case when flat_body ~ 'laporan.{0,100}disampaikan dengan cara' then 4 else 0 end
    + case when flat_body ~ 'penyampaian laporan.{0,100}dilakukan dengan cara' then 3 else 0 end
    + case when flat_body ~ 'pelapor (menyampaikan|mengisi|menyerahkan)' then 1.5 else 0 end
    + case when flat_body ~ 'pelapor.{0,120}terdiri atas|laporan.{0,100}disampaikan paling lama' then 1 else 0 end
    - case when flat_body like '%kop pengawas pemilu%' then 2 else 0 end
   else base_rank end as relevance
  from candidates
 )
 select doc_id,cid,doc_title,doc_version,url,section,body,relevance::real,origin,filename,sha
 from ranked order by relevance desc,doc_id,chunk_index limit 5;
end $function$;

