create table public.bilah_import_errors(id uuid primary key default gen_random_uuid(),created_at timestamptz not null default now(),filename text not null check(length(filename)<=255),message text not null check(length(message)<=400));
alter table public.bilah_import_errors enable row level security;
revoke all on public.bilah_import_errors from public,anon,authenticated;
grant insert(filename,message),select on public.bilah_import_errors to authenticated;
create policy bilah_import_admin_read on public.bilah_import_errors for select to authenticated using(bilah_private.current_role() in ('admin','superadmin'));
create policy bilah_import_admin_write on public.bilah_import_errors for insert to authenticated with check(bilah_private.current_role() in ('admin','superadmin'));
