-- Transactional integration fixtures. Never retain these as service interactions.
begin;
set local role service_role;
do $$
declare req uuid:=gen_random_uuid(); session_value text:=repeat('a',64); ip_value text:=repeat('b',64); question_value text:=repeat('c',64); result jsonb; n integer; reply jsonb;
begin
 result=public.bilah_public_chat_begin(req,session_value,ip_value,question_value,'Uji integrasi perangkat lunak, bukan permohonan pelayanan.');
 if result->>'state'<>'new' then raise exception 'Request not admitted'; end if;
 result=public.bilah_public_chat_begin(req,session_value,ip_value,question_value,'Uji integrasi perangkat lunak, bukan permohonan pelayanan.');
 if result->>'state'<>'pending' then raise exception 'Duplicate request not pending'; end if;
 begin
  perform public.bilah_public_chat_begin(req,repeat('d',64),ip_value,question_value,'Different session');
  raise exception 'Session ownership check missing';
 exception when insufficient_privilege then null; end;
 if not public.bilah_public_ai_reserve(req) or not public.bilah_public_ai_reserve(req) or public.bilah_public_ai_reserve(req) then raise exception 'Per-question AI limit failed'; end if;
 reply=jsonb_build_object('answer','Jawaban fiktif untuk uji perangkat lunak.','sources','[]'::jsonb,'decision','information','mode','guardrail','canEscalate',false);
 if not public.bilah_public_chat_finish(req,reply,500) then raise exception 'Persistence failed'; end if;
 if not public.bilah_public_chat_finish(req,reply,500) then raise exception 'Finish idempotency failed'; end if;
 select count(*) into n from public.messages m join bilah_private.public_chat_requests r on r.conversation_id=m.conversation_id where r.id=req;
 if n<>2 then raise exception 'Message pair duplicated'; end if;
 result=public.bilah_public_chat_begin(req,session_value,ip_value,question_value,'Uji integrasi perangkat lunak, bukan permohonan pelayanan.');
 if result->>'state'<>'complete' or result->'response'->>'recorded'<>'true' then raise exception 'Cached response missing'; end if;
 for n in 1..2 loop perform public.bilah_public_chat_begin(gen_random_uuid(),session_value,ip_value,question_value,'Uji pembatasan permintaan.'); end loop;
 result=public.bilah_public_chat_begin(gen_random_uuid(),session_value,ip_value,question_value,'Permintaan melewati batas.');
 if result->>'state'<>'limited' then raise exception 'Request limiter failed'; end if;
end $$;
reset role;
do $$ begin
 if has_function_privilege('anon','public.bilah_public_chat_begin(uuid,text,text,text,text)','EXECUTE')
 or has_function_privilege('authenticated','public.bilah_public_chat_finish(uuid,jsonb,integer)','EXECUTE')
 or has_function_privilege('anon','public.bilah_public_search_knowledge(text[])','EXECUTE')
 or has_function_privilege('authenticated','public.bilah_public_ai_reserve(uuid)','EXECUTE') then raise exception 'Backend RPC exposed to browsers'; end if;
end $$;
rollback;
select 'public chat integration passed; fixtures rolled back' as result;
