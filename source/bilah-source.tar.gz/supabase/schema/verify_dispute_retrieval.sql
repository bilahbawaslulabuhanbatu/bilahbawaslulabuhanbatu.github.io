begin;
select set_config('request.jwt.claim.sub',(select id::text from auth.users where lower(email)='rangkutiray3@gmail.com' and email_confirmed_at is not null),true);
set local role authenticated;
do $$
declare body text; top_body text; terms text[];
begin
 if not exists(select 1 from public.knowledge_documents where title='Peraturan Bawaslu Nomor 9 Tahun 2022' and status='active' and visibility='public') then raise exception 'Approved source for this regression is missing'; end if;
 foreach terms slice 1 in array array[array['mengajukan','permohonan','sengketa'],array['pengajuan','permohonan','sengketa']] loop
  select content into top_body from public.bilah_search_knowledge(terms) limit 1;
  if top_body is null or not (top_body like '%SIPS%' or top_body like '%loket penerimaan%') then raise exception 'Submission channels not ranked first'; end if;
  select string_agg(content,' ') into body from public.bilah_search_knowledge(terms);
  if body not like '%Pasal 26%' or body not like '%Pasal 29%' or body not like '%Pasal 30%' or body not like '%Pasal 32%' or body not like '%Pasal 38%' then raise exception 'Submission evidence incomplete'; end if;
  if lower(body) like '%berisi uraian%' then raise exception 'Template outranked submission instructions'; end if;
 end loop;
end $$;
rollback;
select 'dispute procedure retrieval verified' as result;
