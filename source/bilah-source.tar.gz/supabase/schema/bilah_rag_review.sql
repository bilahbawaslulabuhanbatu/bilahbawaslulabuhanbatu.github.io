alter table public.knowledge_documents add column if not exists rag_review_note text generated always as (case when source_filename='PAPARAN-LENGKAP_IKP-PEMILU-DAN-PEMILIHAN-SERENTAK-2024.pdf' and title='Peraturan Bawaslu Nomor 7 Tahun 2017' then 'Judul berbeda dari paparan IKP; koreksi judul dan verifikasi kembali.' else null end) stored;
create or replace function public.bilah_rag_search(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,section_reference text,content text,source_origin text,source_filename text,source_sha256 text,score real)
language plpgsql stable security invoker set search_path='' as $$
declare terms text[]; q tsquery; v extensions.vector; begin
if current_user <> 'service_role' and coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then raise insufficient_privilege;end if;
select array_agg(distinct lower(s)) into terms from unnest(search_terms[1:24]) s where s ~ '^[a-zA-Z0-9]{2,40}$';
if terms is null then return;end if;
select to_tsquery('pg_catalog.indonesian',string_agg(quote_literal(t),' | ')) into q from unnest(terms) t;
v=bilah_private.rag_vec(array_to_string(terms,' '));
return query with pool as materialized (
select d.id doc,c.id cid,c.chunk_index ix,d.title ttl,d.version ver,d.source_url url,c.section_reference sec,c.content body,d.source_origin org,d.source_filename fn,d.source_sha256 sha,
(case when exists(select from unnest(terms) num where num ~ '^[0-9]{1,3}$' and c.content ~* ('(?:^|[[:space:]])Pasal[[:space:]]+'||num||'[[:space:]]*[(]1[)]')) then 0.9 else 0 end)+ts_rank_cd(to_tsvector('pg_catalog.indonesian',coalesce(d.document_number,'')||' '||coalesce(d.year::text,'')||' '||d.title||' '||c.content),q,32) lex,
case when v is null or c.semantic_vector is null then 0 else greatest(0,1-(c.semantic_vector operator(extensions.<=>) v)) end sim
from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id and d.version=c.document_version
where d.status='active' and d.visibility='public' and (d.effective_date is null or d.effective_date<=current_date)
and (d.category_id is null or exists(select from public.categories k where k.id=d.category_id and k.is_active))
and d.rag_review_note is null and length(trim(c.content))>=20
), ranks as (select p.*,rank() over(order by lex desc) lr,rank() over(order by sim desc) sr from pool p),
hits as (select r.*, (case when lex>0 then 1.2/(16+lr)+0.15*lex else 0 end+case when sim>0.18 then 1.0/(16+sr) else 0 end) sc from ranks r where lex>0 or sim>0.18),
best as (select * from hits order by sc desc,cid limit 5),
neighbors as (select p.*,max(b.sc*(case when b.ix=p.ix then 1 else 0.87 end)) weight from best b join pool p on p.doc=b.doc and abs(p.ix-b.ix)<=1 group by p.doc,p.cid,p.ix,p.ttl,p.ver,p.url,p.sec,p.body,p.org,p.fn,p.sha,p.lex,p.sim)
select doc,cid,ttl,ver,url,sec,body,org,fn,sha,weight::real from neighbors order by weight desc,doc,ix limit 10;
end $$;
revoke all on function public.bilah_rag_search(text[]) from public,anon;
grant execute on function public.bilah_rag_search(text[]) to authenticated,service_role;
create or replace function public.bilah_index_status() returns table(document_id uuid,title text,stage text,chunks bigint,vectors bigint,weak bigint)
language sql stable security invoker set search_path='' as $$
select d.id,d.title,case when d.rag_review_note is not null then d.rag_review_note when count(c.id)=0 then 'Belum terindeks' when count(c.semantic_vector)<count(c.id) then 'Periksa teks tanpa vektor' when d.status<>'active' or d.visibility<>'public' then 'Terindeks, tidak untuk publik' else 'Terindeks' end,count(c.id),count(c.semantic_vector),count(c.id) filter(where length(trim(c.content))<20) from public.knowledge_documents d left join public.knowledge_chunks c on c.document_id=d.id and c.document_version=d.version where bilah_private.current_role() in ('admin','superadmin') group by d.id order by d.title
$$;
revoke all on function public.bilah_index_status() from public,anon;
grant execute on function public.bilah_index_status() to authenticated;
