-- Hosted migration: bilah_knowledge. Internal curation and retrieval only.
alter table public.knowledge_documents add column visibility text not null default 'internal'
  check (visibility in ('internal','public'));

create or replace function bilah_private.guard_document_revision() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin
  if new.id <> old.id or new.created_by is distinct from old.created_by or
     new.created_at is distinct from old.created_at then
    raise insufficient_privilege using message='Identitas dokumen tidak dapat diubah';
  end if;
  if row(new.content,new.source_url,new.document_number,new.title,new.summary,
         new.category_id,new.source_type,new.year,new.effective_date,new.visibility)
     is distinct from
     row(old.content,old.source_url,old.document_number,old.title,old.summary,
         old.category_id,old.source_type,old.year,old.effective_date,old.visibility) then
    new.version=old.version+1;
    new.status='inactive'; new.verified_by=null; new.verified_at=null;
  else new.version=old.version; end if;
  if new.status='active' then
    if new.source_url !~* '^https://([a-z0-9-]+\.)*(bawaslu\.go\.id|kpu\.go\.id|bpk\.go\.id|dpr\.go\.id|setneg\.go\.id|peraturan\.go\.id)(/|$)' or
       length(trim(new.content))<40 then
      raise check_violation using message='Dokumen aktif memerlukan isi dan tautan resmi';
    end if;
    if new.status is distinct from old.status or new.verified_by is distinct from old.verified_by or new.verified_at is distinct from old.verified_at then
      if auth.uid() is null or new.verified_by is distinct from auth.uid() then
        raise insufficient_privilege using message='Verifikasi harus dilakukan oleh admin yang sedang masuk';
      end if;
      new.verified_at=now();
    end if;
  else new.verified_by=null; new.verified_at=null;
  end if;
  return new;
end $$;

-- Definer needed only for trigger-owned chunk writes, never callable as an RPC.
-- Identity and role are checked explicitly in addition to parent-table RLS.
create function bilah_private.refresh_knowledge_chunks() returns trigger
language plpgsql security definer set search_path = '' as $$
declare start_at integer; part integer:=0;
begin
  if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
    raise insufficient_privilege using message='Pengelolaan sumber hanya untuk admin aktif';
  end if;
  if tg_op='UPDATE' and new.version=old.version then return new; end if;
  delete from public.knowledge_chunks where document_id=new.id;
  if length(trim(new.content))=0 then return new; end if;
  -- Fixed-size overlapping chunks. No embedding service or external AI cost.
  start_at:=1;
  while start_at<=length(new.content) loop
    insert into public.knowledge_chunks(document_id,document_version,chunk_index,content,section_reference)
    values(new.id,new.version,part,substring(new.content from start_at for 2400),'Bagian '||(part+1)::text);
    start_at:=start_at+2200; part:=part+1;
  end loop;
  return new;
end $$;
revoke all on function bilah_private.refresh_knowledge_chunks() from public,anon,authenticated;
create trigger bilah_refresh_knowledge_chunks after insert or update on public.knowledge_documents
for each row execute function bilah_private.refresh_knowledge_chunks();

-- Preview returns only approved material explicitly marked for public use.
-- SECURITY INVOKER preserves users/roles RLS. No grants for anonymous visitors.
create function public.bilah_search_knowledge(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,
              section_reference text,content text,score real)
language plpgsql stable security invoker set search_path = '' as $$
declare query_value tsquery;
begin
  if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
    raise insufficient_privilege using message='Akses dibatasi';
  end if;
  if coalesce(cardinality(search_terms),0)=0 or cardinality(search_terms)>24 then return; end if;
  select to_tsquery('simple'::regconfig,string_agg(quote_literal(t),' | ')) into query_value
  from (select distinct lower(v) as t from unnest(search_terms) as v
        where v ~ '^[a-zA-Z0-9]{2,40}$') terms;
  if query_value is null then return; end if;
  return query
  select d.id,c.id,d.title,d.version,d.source_url,c.section_reference,c.content,
    ts_rank_cd(setweight(to_tsvector('simple'::regconfig,d.title),'A')||c.search_vector,query_value) as rank_value
  from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id
  where d.status='active' and d.visibility='public' and c.document_version=d.version
    and (d.effective_date is null or d.effective_date<=((now() at time zone 'Asia/Jakarta')::date))
    and (d.category_id is null or exists(select 1 from public.categories cat where cat.id=d.category_id and cat.is_active))
    and (to_tsvector('simple'::regconfig,d.title)||c.search_vector) @@ query_value
  order by rank_value desc,d.id,c.chunk_index limit 5;
end $$;
revoke all on function public.bilah_search_knowledge(text[]) from public,anon;
grant execute on function public.bilah_search_knowledge(text[]) to authenticated;
