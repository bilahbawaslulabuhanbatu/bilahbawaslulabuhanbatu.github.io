-- Prefer application instructions over templates when asking how to submit an election dispute.
create or replace function public.bilah_search_knowledge(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,section_reference text,content text,score real,source_origin text,source_filename text,source_sha256 text)
language plpgsql stable security invoker set search_path='' as $$
declare query_value tsquery; report_intent boolean; dispute_intent boolean;
begin
 if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
  raise insufficient_privilege using message='Akses dibatasi';
 end if;
 if coalesce(cardinality(search_terms),0)=0 or cardinality(search_terms)>24 then return; end if;
 select to_tsquery('simple'::regconfig,string_agg(quote_literal(t),' | ')),
  bool_or(t in ('lapor','melapor','melaporkan','laporkan','pelaporan')),
  bool_or(t='sengketa') and bool_or(t in ('permohonan','mengajukan','pengajuan','ajukan','mengajukannya','daftar','mendaftar'))
 into query_value,report_intent,dispute_intent
 from (select distinct lower(v) as t from unnest(search_terms) as v where v ~ '^[a-zA-Z0-9]{2,40}$') terms;
 if query_value is null then return; end if;
 return query
 with candidates as (
  select d.id as doc_id,c.id as cid,d.title as doc_title,d.version as doc_version,d.source_url as url,
   c.section_reference as section,c.content as body,d.source_origin as origin,d.source_filename as filename,d.source_sha256 as sha,
   c.chunk_index,
   ts_rank_cd(setweight(to_tsvector('simple'::regconfig,d.title),'A')||c.search_vector,query_value) as base_rank,
   lower(regexp_replace(c.content,'\s+',' ','g')) as flat_body
  from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id
  where d.status='active' and d.visibility='public' and c.document_version=d.version
   and (d.effective_date is null or d.effective_date<=((now() at time zone 'Asia/Jakarta')::date))
   and (d.category_id is null or exists(select 1 from public.categories cat where cat.id=d.category_id and cat.is_active))
   and (to_tsvector('simple'::regconfig,d.title)||c.search_vector) @@ query_value
 ), ranked as (
  select candidates.*,
   case when dispute_intent then
    base_rank/(1+base_rank)
    + case when flat_body ~ 'permohonan.{0,100}disampaikan oleh pemohon dengan cara' then 8 else 0 end
    + case when flat_body ~ 'paragraf [[:digit:]]+ permohonan secara (tidak )?langsung' then 7 else 0 end
    + case when flat_body ~ 'penyampaian permohonan secara (tidak )?langsung.{0,180}(loket|sips)' then 5 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}disampaikan secara tertulis' then 4 else 0 end
    + case when flat_body ~ 'permohonan.{0,100}harus dilampiri' then 5 else 0 end
    + case when flat_body ~ 'pemohon menyampaikan permohonan' then 2 else 0 end
    - case when flat_body like '%pihak terkait%' and not ('terkait'=any(search_terms)) then 3 else 0 end
    - case when flat_body ~ 'dalam hal ini mengajukan|berisi uraian|nama pemohon[[:space:]]*:' then 12 else 0 end
   when report_intent then
    -- Bound repetition's influence; prefer instructions over internal recaps/templates.
    base_rank/(1+base_rank)
    + case when flat_body ~ 'laporan.{0,100}disampaikan dengan cara' then 4 else 0 end
    + case when flat_body ~ 'penyampaian laporan.{0,100}dilakukan dengan cara' then 3 else 0 end
    + case when flat_body ~ 'pelapor (menyampaikan|mengisi|menyerahkan)' then 1.5 else 0 end
    + case when flat_body ~ 'pelapor.{0,120}terdiri atas|laporan.{0,100}disampaikan paling lama' then 1 else 0 end
    - case when flat_body like '%kop pengawas pemilu%' then 2 else 0 end
   else base_rank end as relevance
  from candidates
 )
 select doc_id,cid,doc_title,doc_version,url,section,body,relevance::real,origin,filename,sha
 from ranked order by relevance desc,doc_id,chunk_index limit 5;
end $$;
revoke all on function public.bilah_search_knowledge(text[]) from public,anon;
grant execute on function public.bilah_search_knowledge(text[]) to authenticated;
