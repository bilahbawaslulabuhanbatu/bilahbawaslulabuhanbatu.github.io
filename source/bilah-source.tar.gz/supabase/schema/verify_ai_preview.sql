begin;
select set_config('request.jwt.claim.sub',(select id::text from auth.users where lower(email)='rangkutiray3@gmail.com' and email_confirmed_at is not null),true);
set local role authenticated;
do $$ begin
 if not public.bilah_reserve_ai_preview_call() or not public.bilah_reserve_ai_preview_call() or not public.bilah_reserve_ai_preview_call() then raise exception 'Allowed trial was blocked';end if;
 if public.bilah_reserve_ai_preview_call() then raise exception 'Rate limit not enforced';end if;
end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000001',true);
set local role authenticated;
do $$ begin
 begin perform public.bilah_reserve_ai_preview_call();raise exception 'Unprovisioned identity accepted';exception when insufficient_privilege then null;end;
end $$;
reset role;
set local role anon;
do $$ begin
 begin perform public.bilah_reserve_ai_preview_call();raise exception 'Anonymous accepted';exception when insufficient_privilege then null;end;
end $$;
reset role;
rollback;
select 'AI preview quota and access passed; fixtures rolled back' as result;
