CREATE OR REPLACE FUNCTION public.bilah_public_chat_begin(p_request_id uuid, p_session_hash text, p_ip_hash text, p_question_hash text, p_question text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare existing bilah_private.public_chat_requests; conversation uuid; message uuid;
begin
 if current_user <> 'service_role' then raise insufficient_privilege; end if;
 if p_session_hash !~ '^[a-f0-9]{64}$' or p_ip_hash !~ '^[a-f0-9]{64}$' or p_question_hash !~ '^[a-f0-9]{64}$' or char_length(trim(p_question)) not between 1 and 2000 then raise check_violation; end if;
 perform pg_advisory_xact_lock(720061101);
 select * into existing from bilah_private.public_chat_requests where id=p_request_id;
 if found then
  if existing.session_hash<>p_session_hash or existing.question_hash<>p_question_hash then raise insufficient_privilege; end if;
  return jsonb_build_object('state',case when existing.response is null then 'pending' else 'complete' end,'response',existing.response);
 end if;
 if (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '24 hours')>=100
  or (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '1 minute' and (session_hash=p_session_hash or ip_hash=p_ip_hash))>=3
  or (select count(*) from bilah_private.public_chat_requests where created_at>now()-interval '24 hours' and (session_hash=p_session_hash or ip_hash=p_ip_hash))>=30 then return jsonb_build_object('state','limited'); end if;
 select id into conversation from public.conversations where session_token_hash=p_session_hash and expires_at>now() and not is_demo order by created_at desc limit 1;
 if conversation is null then insert into public.conversations(session_token_hash) values(p_session_hash) returning id into conversation; end if;
 insert into public.messages(conversation_id,role,content,guardrail_status) values(conversation,'user',p_question,'pending') returning id into message;
 insert into bilah_private.public_chat_requests(id,session_hash,ip_hash,question_hash,conversation_id,user_message_id) values(p_request_id,p_session_hash,p_ip_hash,p_question_hash,conversation,message);
 update public.conversations set last_activity_at=now() where id=conversation;
 return jsonb_build_object('state','new','previousQuestions',coalesce((
 select jsonb_agg(recent.content order by recent.created_at desc)
 from (select m.content,m.created_at from public.messages m
 where m.conversation_id=conversation and m.role='user' and m.id<>message
 and m.created_at > now()-interval '30 minutes'
 order by m.created_at desc limit 8) recent
 ),'[]'::jsonb));
end $function$;
