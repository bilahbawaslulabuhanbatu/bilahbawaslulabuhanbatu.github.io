-- Hosted migration: bilah_pdf_import. Approved uploads retain file provenance.
alter table public.knowledge_documents
 add column source_origin text not null default 'official_url' check(source_origin in ('official_url','uploaded_pdf')),
 add column source_filename text check(char_length(source_filename) between 1 and 255),
 add column source_sha256 text check(source_sha256 ~ '^[a-f0-9]{64}$'),
 add column source_page_count integer check(source_page_count between 1 and 300),
 add constraint uploaded_pdf_provenance check(source_origin <> 'uploaded_pdf' or (source_filename is not null and source_sha256 is not null and source_page_count is not null));
create unique index knowledge_pdf_hash_unique on public.knowledge_documents(source_sha256) where source_sha256 is not null;
alter table public.knowledge_documents drop constraint active_document_verified;
alter table public.knowledge_documents add constraint active_document_verified check(status <> 'active' or
 (verified_by is not null and verified_at is not null and length(trim(content)) >= 40 and
  (source_origin='uploaded_pdf' or source_url is not null)));

create or replace function bilah_private.guard_document_revision() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin
  if new.id <> old.id or new.created_by is distinct from old.created_by or
     new.created_at is distinct from old.created_at then
    raise insufficient_privilege using message='Identitas dokumen tidak dapat diubah';
  end if;
  if row(new.content,new.source_url,new.document_number,new.title,new.summary,
         new.category_id,new.source_type,new.year,new.effective_date,new.visibility,new.source_origin,new.source_filename,new.source_sha256,new.source_page_count)
     is distinct from
     row(old.content,old.source_url,old.document_number,old.title,old.summary,
         old.category_id,old.source_type,old.year,old.effective_date,old.visibility,old.source_origin,old.source_filename,old.source_sha256,old.source_page_count) then
    new.version=old.version+1;
    new.status='inactive'; new.verified_by=null; new.verified_at=null;
  else new.version=old.version; end if;
  if new.status='active' then
    if (new.source_origin='official_url' and new.source_url !~* '^https://([a-z0-9-]+\.)*(bawaslu\.go\.id|kpu\.go\.id|bpk\.go\.id|dpr\.go\.id|setneg\.go\.id|peraturan\.go\.id)(/|$)') or
       length(trim(new.content))<40 then
      raise check_violation using message='Dokumen aktif memerlukan isi dan tautan resmi';
    end if;
    if new.status is distinct from old.status or new.verified_by is distinct from old.verified_by or new.verified_at is distinct from old.verified_at then
      if auth.uid() is null or new.verified_by is distinct from auth.uid() then
        raise insufficient_privilege using message='Verifikasi harus dilakukan oleh admin yang sedang masuk';
      end if;
      new.verified_at=now();
    end if;
  else new.verified_by=null; new.verified_at=null;
  end if;
  return new;
end $$;


create or replace function bilah_private.refresh_knowledge_chunks() returns trigger
language plpgsql security definer set search_path = '' as $$
declare start_at integer; part integer:=0; local_part integer; segment text; page_text text; page_number text;
begin
 if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
   raise insufficient_privilege using message='Pengelolaan sumber hanya untuk admin aktif';
 end if;
 if tg_op='UPDATE' and new.version=old.version then return new; end if;
 delete from public.knowledge_chunks where document_id=new.id;
 if length(trim(new.content))=0 then return new; end if;
 if new.source_origin='uploaded_pdf' and new.content like '[[HALAMAN PDF %' then
   foreach segment in array string_to_array(new.content,'[[HALAMAN PDF ') loop
     if segment !~ '^[1-9][0-9]{0,2}\]\]' then continue; end if;
     page_number=split_part(segment,']]',1);
     page_text=trim(substring(segment from strpos(segment,']]')+2));
     if length(page_text)=0 or page_number::integer>new.source_page_count then continue; end if;
     start_at=1;local_part=1;
     while start_at<=length(page_text) loop
       insert into public.knowledge_chunks(document_id,document_version,chunk_index,content,section_reference)
       values(new.id,new.version,part,substring(page_text from start_at for 2400),'Halaman PDF '||page_number||' · bagian '||local_part::text);
       start_at=start_at+2200;part=part+1;local_part=local_part+1;
     end loop;
   end loop;
 else
   start_at=1;
   while start_at<=length(new.content) loop
     insert into public.knowledge_chunks(document_id,document_version,chunk_index,content,section_reference)
     values(new.id,new.version,part,substring(new.content from start_at for 2400),'Bagian '||(part+1)::text);
     start_at=start_at+2200;part=part+1;
   end loop;
 end if;
 return new;
end $$;
revoke all on function bilah_private.refresh_knowledge_chunks() from public,anon,authenticated;
drop function public.bilah_search_knowledge(text[]);

create function public.bilah_search_knowledge(search_terms text[])
returns table(document_id uuid,chunk_id uuid,title text,version integer,source_url text,
              section_reference text,content text,score real,source_origin text,source_filename text,source_sha256 text)
language plpgsql stable security invoker set search_path = '' as $$
declare query_value tsquery;
begin
  if auth.uid() is null or coalesce(bilah_private.current_role(),'') not in ('admin','superadmin') then
    raise insufficient_privilege using message='Akses dibatasi';
  end if;
  if coalesce(cardinality(search_terms),0)=0 or cardinality(search_terms)>24 then return; end if;
  select to_tsquery('simple'::regconfig,string_agg(quote_literal(t),' | ')) into query_value
  from (select distinct lower(v) as t from unnest(search_terms) as v
        where v ~ '^[a-zA-Z0-9]{2,40}$') terms;
  if query_value is null then return; end if;
  return query
  select d.id,c.id,d.title,d.version,d.source_url,c.section_reference,c.content,
    ts_rank_cd(setweight(to_tsvector('simple'::regconfig,d.title),'A')||c.search_vector,query_value) as rank_value,d.source_origin,d.source_filename,d.source_sha256
  from public.knowledge_chunks c join public.knowledge_documents d on d.id=c.document_id
  where d.status='active' and d.visibility='public' and c.document_version=d.version
    and (d.effective_date is null or d.effective_date<=((now() at time zone 'Asia/Jakarta')::date))
    and (d.category_id is null or exists(select 1 from public.categories cat where cat.id=d.category_id and cat.is_active))
    and (to_tsvector('simple'::regconfig,d.title)||c.search_vector) @@ query_value
  order by rank_value desc,d.id,c.chunk_index limit 5;
end $$;
revoke all on function public.bilah_search_knowledge(text[]) from public,anon;
grant execute on function public.bilah_search_knowledge(text[]) to authenticated;
