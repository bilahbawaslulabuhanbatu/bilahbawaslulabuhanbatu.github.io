-- Integration fixture: chat -> ticket -> officer reply -> public lookup. Everything rolls back.
begin;
set local role service_role;
do $$
declare req uuid:=gen_random_uuid(); other_req uuid:=gen_random_uuid(); receipt jsonb; ticket uuid;
begin
 perform public.bilah_public_chat_begin(req,repeat('a',64),repeat('b',64),repeat('c',64),'Uji tiket konsultasi perangkat lunak, bukan permohonan layanan.');
 perform public.bilah_public_chat_finish(req,'{"answer":"Uji bantuan petugas.","sources":[],"decision":"human","mode":"guardrail","canEscalate":true}'::jsonb,1);
 if public.bilah_ticket_create(req,repeat('d',64),repeat('e',64),'pelayanan-ppid') is not null then raise exception 'Cross-session access accepted'; end if;
 receipt=public.bilah_ticket_create(req,repeat('a',64),repeat('e',64),'pelayanan-ppid');
 if receipt->>'ticketNumber' is null then raise exception 'Ticket creation failed'; end if;
 if (public.bilah_ticket_create(req,repeat('a',64),repeat('e',64),'pelayanan-ppid'))->>'ticketNumber'<>receipt->>'ticketNumber' then raise exception 'Ticket creation not idempotent'; end if;
 if public.bilah_ticket_create(req,repeat('a',64),repeat('f',64),'pelayanan-ppid') is not null then raise exception 'New code replaced original code'; end if;
 select id into ticket from public.tickets where idempotency_key=req;
 perform set_config('bilah.test_ticket',ticket::text,true);
 perform set_config('bilah.test_number',receipt->>'ticketNumber',true);
 if public.bilah_ticket_lookup(receipt->>'ticketNumber',repeat('f',64)) is not null then raise exception 'Wrong code accepted'; end if;
 if (public.bilah_ticket_lookup(receipt->>'ticketNumber',repeat('e',64)))->>'status'<>'baru' then raise exception 'New status missing'; end if;
 perform public.bilah_public_chat_begin(other_req,repeat('a',64),repeat('b',64),repeat('c',64),'Uji pertanyaan luar cakupan.');
 perform public.bilah_public_chat_finish(other_req,'{"answer":"Di luar cakupan.","sources":[],"decision":"out_of_domain","mode":"guardrail","canEscalate":false}'::jsonb,1);
 if public.bilah_ticket_create(other_req,repeat('a',64),repeat('e',64),'pelayanan-ppid') is not null then raise exception 'Out-of-domain ticket accepted'; end if;
 for i in 1..3 loop if not public.bilah_ticket_rate(repeat('9',64),'create') then raise exception 'Premature rate rejection'; end if; end loop;
 if public.bilah_ticket_rate(repeat('9',64),'create') then raise exception 'Create limiter missing'; end if;
end $$;
reset role;
select set_config('request.jwt.claim.sub',(select id::text from auth.users where lower(email)='rangkutiray3@gmail.com' and email_confirmed_at is not null),true);
set local role authenticated;
do $$
declare item public.tickets; old_time timestamptz;
begin
 select * into item from public.tickets where id=current_setting('bilah.test_ticket')::uuid;
 if item.id is null then raise exception 'Admin cannot see ticket'; end if;
 old_time=item.updated_at;
 begin
  perform public.bilah_ticket_update(item.id,'','public','selesai',auth.uid(),item.updated_at);
  raise exception 'Resolved without public response';
 exception when check_violation then null; end;
 perform public.bilah_ticket_update(item.id,'Catatan fiktif khusus internal.','internal','dalam_proses',auth.uid(),item.updated_at);
 select * into item from public.tickets where id=item.id;
 perform public.bilah_ticket_update(item.id,'Tanggapan fiktif untuk uji perangkat lunak.','public','selesai',auth.uid(),item.updated_at);
 if not exists(select 1 from public.tickets where id=item.id and status='selesai' and resolved_at is not null) then raise exception 'Resolution not stored'; end if;
 -- Deliberately stale timestamp, not a blind overwrite.
 begin
  perform public.bilah_ticket_update(item.id,'stale','public','dalam_proses',auth.uid(),old_time-interval '1 second');
  raise exception 'Stale write accepted';
 exception when serialization_failure then null; end;
end $$;
reset role;
set local role service_role;
do $$
declare result jsonb;
begin
 result=public.bilah_ticket_lookup(current_setting('bilah.test_number'),repeat('e',64));
 if result->>'status'<>'selesai' or jsonb_array_length(result->'replies')<>1 or result::text like '%khusus internal%' then raise exception 'Public response leaked internal content'; end if;
 if result ? 'access_token_hash' or result ? 'assigned_to' or result ? 'resolution_note' then raise exception 'Private ticket fields exposed'; end if;
end $$;
reset role;
-- Temporarily change the existing internal profile only inside this rolled-back transaction.
-- Auth identities/passwords/sessions are never created or changed.
select set_config('request.jwt.claim.sub','',true);
update public.users set role_id=(select id from public.roles where name='petugas') where id=(select author_id from public.ticket_messages where ticket_id=current_setting('bilah.test_ticket')::uuid limit 1);
select set_config('request.jwt.claim.sub',(select author_id::text from public.ticket_messages where ticket_id=current_setting('bilah.test_ticket')::uuid limit 1),true);
set local role authenticated;
do $$
declare item public.tickets;
begin
 select * into item from public.tickets where id=current_setting('bilah.test_ticket')::uuid;
 if item.id is null then raise exception 'Assigned officer cannot read ticket'; end if;
 begin perform public.bilah_ticket_update(item.id,'','public','selesai',null,item.updated_at);raise exception 'Officer reassigned ticket';exception when insufficient_privilege then null;end;
end $$;
reset role;
select set_config('request.jwt.claim.sub','',true);
update public.tickets set assigned_to=null where id=current_setting('bilah.test_ticket')::uuid;
select set_config('request.jwt.claim.sub',(select author_id::text from public.ticket_messages where ticket_id=current_setting('bilah.test_ticket')::uuid limit 1),true);
set local role authenticated;
do $$ begin
 if exists(select 1 from public.tickets where id=current_setting('bilah.test_ticket')::uuid) then raise exception 'Unassigned officer can read ticket'; end if;
 begin perform public.bilah_ticket_update(current_setting('bilah.test_ticket')::uuid,'forbidden','public','baru',null,now());raise exception 'Unassigned officer can update ticket';exception when insufficient_privilege then null;end;
end $$;
reset role;
select set_config('request.jwt.claim.sub','',true);
update public.users set role_id=(select id from public.roles where name='pimpinan') where id=(select author_id from public.ticket_messages where ticket_id=current_setting('bilah.test_ticket')::uuid limit 1);
select set_config('request.jwt.claim.sub',(select author_id::text from public.ticket_messages where ticket_id=current_setting('bilah.test_ticket')::uuid limit 1),true);
set local role authenticated;
do $$ begin
 if exists(select 1 from public.tickets where id=current_setting('bilah.test_ticket')::uuid) then raise exception 'Pimpinan read raw ticket'; end if;
 begin perform public.bilah_ticket_update(current_setting('bilah.test_ticket')::uuid,'forbidden','public','baru',null,now());raise exception 'Pimpinan modified ticket';exception when insufficient_privilege then null;end;
end $$;
reset role;
do $$ begin
 if has_function_privilege('anon','public.bilah_ticket_lookup(text,text)','EXECUTE') or has_function_privilege('authenticated','public.bilah_ticket_create(uuid,text,text,text)','EXECUTE') or has_function_privilege('anon','public.bilah_ticket_update(uuid,text,text,text,uuid,timestamptz)','EXECUTE') then raise exception 'Guest backend RPC leaked'; end if;
end $$;
rollback;
select 'ticket workflow and access tests passed; fixtures rolled back' as result;
