-- Backend-only guest access; authenticated officers keep existing row-level access.
insert into public.categories(name,slug) values ('Konsultasi Dugaan Pelanggaran','konsultasi-pelanggaran'),('Konsultasi Sengketa','konsultasi-sengketa') on conflict do nothing;
create sequence bilah_private.ticket_number_seq;
grant usage on sequence bilah_private.ticket_number_seq to service_role;
create table bilah_private.ticket_access_attempts (
 id bigint generated always as identity primary key,
 ip_hash text not null check(ip_hash ~ '^[a-f0-9]{64}$'),
 kind text not null check(kind in ('create','lookup')),
 created_at timestamptz not null default now()
);
alter table bilah_private.ticket_access_attempts enable row level security;
create policy ticket_attempts_backend on bilah_private.ticket_access_attempts for all to service_role using(true) with check(true);
revoke all on bilah_private.ticket_access_attempts from public,anon,authenticated;
grant select,insert on bilah_private.ticket_access_attempts to service_role;
grant usage on sequence bilah_private.ticket_access_attempts_id_seq to service_role;
create index ticket_access_ip_time on bilah_private.ticket_access_attempts(ip_hash,created_at);
create index ticket_access_time on bilah_private.ticket_access_attempts(created_at);

create function public.bilah_ticket_rate(p_ip_hash text,p_kind text) returns boolean
language plpgsql security invoker set search_path='' as $$
begin
 if current_user<>'service_role' then raise insufficient_privilege; end if;
 if p_ip_hash !~ '^[a-f0-9]{64}$' or p_kind not in ('create','lookup') then return false; end if;
 perform pg_advisory_xact_lock(720061103);
 if (select count(*) from bilah_private.ticket_access_attempts where created_at>now()-interval '24 hours')>=1000
 or (select count(*) from bilah_private.ticket_access_attempts where ip_hash=p_ip_hash and kind=p_kind and created_at>now()-interval '1 minute')>=(case when p_kind='create' then 3 else 10 end)
 or (select count(*) from bilah_private.ticket_access_attempts where ip_hash=p_ip_hash and kind=p_kind and created_at>now()-interval '24 hours')>=(case when p_kind='create' then 10 else 100 end) then return false; end if;
 insert into bilah_private.ticket_access_attempts(ip_hash,kind) values(p_ip_hash,p_kind);
 return true;
end $$;

create function public.bilah_ticket_create(p_request_id uuid,p_session_hash text,p_access_hash text,p_category text) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare request bilah_private.public_chat_requests; existing public.tickets; question_text text; cat uuid; number_value bigint; ticket_number_value text; new_id uuid;
begin
 if current_user<>'service_role' then raise insufficient_privilege; end if;
 if p_session_hash !~ '^[a-f0-9]{64}$' or p_access_hash !~ '^[a-f0-9]{64}$' then raise check_violation; end if;
 perform pg_advisory_xact_lock(720061104);
 select * into request from bilah_private.public_chat_requests where id=p_request_id and session_hash=p_session_hash and response is not null;
 if not found or not exists(select 1 from public.conversations where id=request.conversation_id and expires_at>now()) then return null; end if;
 if request.response->>'decision' in ('out_of_domain','political','sensitive','injection') then return null; end if;
 select * into existing from public.tickets where idempotency_key=p_request_id;
 if found then
  if existing.access_token_hash<>p_access_hash or existing.conversation_id<>request.conversation_id then return null; end if;
  return jsonb_build_object('ticketNumber',existing.ticket_number,'status',existing.status,'createdAt',existing.created_at);
 end if;
 select id into cat from public.categories where slug=p_category and is_active;
 if cat is null then raise check_violation using message='Kategori tidak tersedia'; end if;
 if (select count(*) from public.tickets where created_at>now()-interval '24 hours')>=100 then return null; end if;
 select content into question_text from public.messages where id=request.user_message_id and conversation_id=request.conversation_id and role='user';
 if question_text is null then return null; end if;
 number_value=nextval('bilah_private.ticket_number_seq');
 ticket_number_value='BILAH-'||to_char(now() at time zone 'Asia/Jakarta','YYYY')||'-'||lpad(number_value::text,greatest(6,length(number_value::text)),'0');
 insert into public.tickets(ticket_number,conversation_id,origin_message_id,category_id,question,summary,access_token_hash,idempotency_key)
 values(ticket_number_value,request.conversation_id,request.user_message_id,cat,question_text,question_text,p_access_hash,p_request_id) returning id into new_id;
 update public.messages set escalated=true where id=request.user_message_id or reply_to_id=request.user_message_id;
 insert into public.system_logs(action,entity_type,entity_id,metadata) values('public_ticket_created','tickets',new_id::text,'{"consultation_only":true}'::jsonb);
 return jsonb_build_object('ticketNumber',ticket_number_value,'status','baru','createdAt',now());
end $$;

create function public.bilah_ticket_lookup(p_number text,p_access_hash text) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare item public.tickets; replies jsonb;
begin
 if current_user<>'service_role' then raise insufficient_privilege; end if;
 select * into item from public.tickets where ticket_number=p_number and access_token_hash=p_access_hash;
 if not found then return null; end if;
 select coalesce(jsonb_agg(jsonb_build_object('message',m.message,'createdAt',m.created_at) order by m.created_at,m.id),'[]'::jsonb) into replies
 from (select id,message,created_at from public.ticket_messages where ticket_id=item.id and visibility='public' order by created_at desc,id desc limit 50) m;
 return jsonb_build_object('ticketNumber',item.ticket_number,'status',item.status,'question',item.question,'createdAt',item.created_at,'updatedAt',item.updated_at,'resolvedAt',item.resolved_at,'replies',replies);
end $$;
revoke all on function public.bilah_ticket_rate(text,text),public.bilah_ticket_create(uuid,text,text,text),public.bilah_ticket_lookup(text,text) from public,anon,authenticated;
grant execute on function public.bilah_ticket_rate(text,text),public.bilah_ticket_create(uuid,text,text,text),public.bilah_ticket_lookup(text,text) to service_role;

create function public.bilah_ticket_update(p_ticket_id uuid,p_message text,p_visibility text,p_status text,p_assigned_to uuid,p_expected_updated_at timestamptz)
returns boolean language plpgsql security invoker set search_path='' as $$
declare item public.tickets; officer_role text; final_reply text;
begin
 officer_role=bilah_private.current_role();
 if auth.uid() is null or coalesce(officer_role,'') not in ('petugas','admin','superadmin') then raise insufficient_privilege; end if;
 select * into item from public.tickets where id=p_ticket_id for update;
 if not found then raise insufficient_privilege; end if;
 if item.updated_at is distinct from p_expected_updated_at then raise serialization_failure using message='Tiket telah berubah. Muat ulang sebelum menyimpan.'; end if;
 if p_status not in ('baru','dalam_proses','menunggu_informasi','selesai') or p_visibility not in ('public','internal') or p_message is null or char_length(p_message)>10000 then raise check_violation; end if;
 if p_message ~ '(\m[0-9]{16}\M)' or p_message ~* '(password|kata sandi|nik)[[:space:]]*[:=]' then raise check_violation using message='Jangan menulis data sensitif'; end if;
 if officer_role='petugas' and (p_assigned_to is distinct from item.assigned_to or (item.status='selesai' and p_status<>'selesai')) then raise insufficient_privilege; end if;
 if length(trim(p_message))>0 then
  insert into public.ticket_messages(ticket_id,author_id,message,visibility) values(item.id,auth.uid(),trim(p_message),p_visibility);
 end if;
 if p_status='selesai' then
  select message into final_reply from public.ticket_messages where ticket_id=item.id and visibility='public' order by created_at desc,id desc limit 1;
  if final_reply is null then raise check_violation using message='Berikan tanggapan untuk pemohon sebelum menyelesaikan tiket'; end if;
 end if;
 update public.tickets set status=p_status,assigned_to=p_assigned_to,
  resolution_note=case when p_status='selesai' then final_reply else null end,
  resolved_at=case when p_status='selesai' then coalesce(item.resolved_at,now()) else null end
 where id=item.id;
 return true;
end $$;
revoke all on function public.bilah_ticket_update(uuid,text,text,text,uuid,timestamptz) from public,anon;
grant execute on function public.bilah_ticket_update(uuid,text,text,text,uuid,timestamptz) to authenticated;
