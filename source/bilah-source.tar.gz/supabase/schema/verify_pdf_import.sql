begin;
select set_config('request.jwt.claim.sub',(select id::text from auth.users where lower(email)='rangkutiray3@gmail.com' and email_confirmed_at is not null),true);
set local role authenticated;
do $$
declare doc uuid; found_count integer; found_filename text; chunk_count integer;
begin
 insert into public.knowledge_documents(title,source_type,content,visibility,source_origin,source_filename,source_sha256,source_page_count,created_by)
 values('Fixture zqxpdf','regulasi',E'[[HALAMAN PDF 1]]\nzqxpdf Teks fiktif untuk pengujian perangkat lunak halaman pertama.\n\n[[HALAMAN PDF 2]]\nzqxpdf Teks fiktif untuk pengujian perangkat lunak halaman kedua.','public','uploaded_pdf','fixture.pdf',repeat('b',64),2,auth.uid()) returning id into doc;
 select count(*) into chunk_count from public.knowledge_chunks where document_id=doc and section_reference like 'Halaman PDF %';
 if chunk_count<>2 then raise exception 'Page provenance missing';end if;
 select count(*) into found_count from public.bilah_search_knowledge(array['zqxpdf']);
 if found_count<>0 then raise exception 'Draft leaked';end if;
 begin
  update public.knowledge_documents set status='active' where id=doc;
  raise exception 'Unverified upload activated';
 exception when insufficient_privilege or check_violation then null;end;
 update public.knowledge_documents set status='active',verified_by=auth.uid(),verified_at=now() where id=doc;
 select count(*),min(source_filename) into found_count,found_filename from public.bilah_search_knowledge(array['zqxpdf']);
 if found_count<>2 or found_filename<>'fixture.pdf' then raise exception 'Approved upload unavailable';end if;
 begin
  insert into public.knowledge_documents(title,source_type,content,source_origin,source_filename,source_sha256,source_page_count,created_by)
  values('Duplicate fixture','regulasi','Teks fiktif untuk uji duplikasi dokumen perangkat lunak.','uploaded_pdf','copy.pdf',repeat('b',64),1,auth.uid());
  raise exception 'Duplicate accepted';
 exception when unique_violation then null;end;
 update public.knowledge_documents set source_filename='revised-fixture.pdf' where id=doc;
 if not exists(select 1 from public.knowledge_documents where id=doc and status='inactive' and verified_by is null and version=2) then raise exception 'Revision did not reset approval';end if;
end $$;
reset role;
rollback;
select 'PDF import verification passed; fixtures rolled back' as result;
