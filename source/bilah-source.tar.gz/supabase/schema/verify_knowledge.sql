-- Execute as postgres in one transaction. All fixture records are rolled back.
begin;
select set_config('request.jwt.claim.sub',(select id::text from auth.users where lower(email)='rangkutiray3@gmail.com' and email_confirmed_at is not null),'true');
set local role authenticated;
do $$
declare doc_id uuid; matches integer; chunk_count integer; current_version integer;
begin
  insert into public.knowledge_documents(title,source_type,content,source_url,visibility,created_by)
  values('BILAH fixture zqxktest','informasi_kelembagaan',repeat('zqxktest: fiktif untuk uji perangkat lunak, bukan informasi pelayanan. ',80),
    'https://labuhanbatu.bawaslu.go.id/','public',auth.uid()) returning id into doc_id;
  select count(*) into chunk_count from public.knowledge_chunks where document_id=doc_id;
  if chunk_count<2 then raise exception 'Chunk creation failed'; end if;
  select count(*) into matches from public.bilah_search_knowledge(array['zqxktest']);
  if matches<>0 then raise exception 'Draft leaked'; end if;
  update public.knowledge_documents set status='active',verified_by=auth.uid(),verified_at=now() where id=doc_id;
  select count(*) into matches from public.bilah_search_knowledge(array['zqxktest']);
  if matches=0 then raise exception 'Active public source missing'; end if;
  update public.knowledge_documents set summary='Revised fixture' where id=doc_id;
  select version into current_version from public.knowledge_documents where id=doc_id and status='inactive' and verified_by is null;
  if current_version is distinct from 2 then raise exception 'Metadata change did not reset approval'; end if;
  select count(*) into matches from public.bilah_search_knowledge(array['zqxktest']);
  if matches<>0 then raise exception 'Unverified revision leaked'; end if;
  update public.knowledge_documents set visibility='internal' where id=doc_id;
  update public.knowledge_documents set status='active',verified_by=auth.uid(),verified_at=now() where id=doc_id;
  select count(*) into matches from public.bilah_search_knowledge(array['zqxktest']);
  if matches<>0 then raise exception 'Internal source leaked'; end if;
  update public.knowledge_documents set visibility='public',effective_date='2199-01-01' where id=doc_id;
  update public.knowledge_documents set status='active',verified_by=auth.uid(),verified_at=now() where id=doc_id;
  select count(*) into matches from public.bilah_search_knowledge(array['zqxktest']);
  if matches<>0 then raise exception 'Future source leaked'; end if;
  update public.knowledge_documents set effective_date=null where id=doc_id;
  update public.knowledge_documents set status='active',verified_by=auth.uid(),verified_at=now() where id=doc_id;
  update public.knowledge_documents set status='outdated' where id=doc_id;
  select count(*) into matches from public.bilah_search_knowledge(array['zqxktest']);
  if matches<>0 then raise exception 'Outdated source leaked'; end if;
  update public.knowledge_documents set source_url='https://bawaslu.go.id.evil.test/' where id=doc_id;
  begin
    update public.knowledge_documents set status='active',verified_by=auth.uid(),verified_at=now() where id=doc_id;
    raise exception 'Lookalike URL accepted';
  exception when check_violation then null; end;
end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000001',true);
set local role authenticated;
do $$ begin
  begin perform * from public.bilah_search_knowledge(array['zqxktest']);
    raise exception 'Unprovisioned account received retrieval access';
  exception when insufficient_privilege then null; end;
end $$;
reset role;
set local role anon;
do $$ begin
  begin perform * from public.bilah_search_knowledge(array['zqxktest']);
    raise exception 'Anonymous caller received retrieval access';
  exception when insufficient_privilege then null; end;
end $$;
reset role;
rollback;
select 'knowledge verification passed; fixtures rolled back' as result;
