Migrasi schema dan RLS dibuat pada fase 4. Belum ada SQL yang dijalankan.
