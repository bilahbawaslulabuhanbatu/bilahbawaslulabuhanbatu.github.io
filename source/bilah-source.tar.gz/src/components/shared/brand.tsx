import Link from 'next/link';

export function BilahMark({ className = 'mini-mark' }: { className?: string }) {
  return <span className={className} aria-hidden="true"><img src="/brand/bilah-logo.png" alt="" width="1254" height="1254" /></span>;
}

export function Brand() {
  return <Link href="/" className="brand" aria-label="BILAH — Beranda"><img className="bilah-brand-logo" src="/brand/bilah-logo.png" alt="Logo BILAH bermotif Melayu pesisir" width="1254" height="1254" /><span><strong>BILAH</strong><small>Bot Informasi, Layanan,<br />Aspirasi, dan Hukum</small></span></Link>;
}

export function BawasluIdentity() {
  return <div className="bawaslu-identity" aria-label="Bawaslu Kabupaten Labuhanbatu"><img src="/brand/bawaslu-symbol.png" width="150" height="150" alt="Lambang Bawaslu" /><span><strong>BAWASLU</strong><small>KABUPATEN LABUHANBATU</small></span></div>;
}
