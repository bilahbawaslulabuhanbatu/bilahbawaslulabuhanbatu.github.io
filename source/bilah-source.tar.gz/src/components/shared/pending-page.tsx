export function PendingPage({ title, description, phase }: { title: string; description: string; phase: number }) {
  return <section className="panel"><span className="eyebrow">FASE {phase} · BELUM AKTIF</span><h1>{title}</h1><p>{description}</p><div className="notice">Halaman ini adalah kerangka. Belum ada data pelayanan yang ditampilkan atau diubah.</div></section>;
}
