import { serviceDisclaimer } from '@/lib/guardrails/messages';
export function Disclaimer() { return <aside className="disclaimer"><span aria-hidden="true">ⓘ</span><p>{serviceDisclaimer}</p></aside>; }
