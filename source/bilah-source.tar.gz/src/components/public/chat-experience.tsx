'use client';
import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import Link from 'next/link';
import { Icon } from '@/components/shared/icon';

import { containsSensitivePattern, quickQuestions, type Scenario } from '@/lib/demo/scenarios';
import {askPublicBilah,newPublicConversation,type PublicChatAnswer} from '@/lib/chat/public-client';
import {TicketRequest} from './ticket-request';

type Message = { id: number; role: 'user' | 'assistant'; text: string; scenario?: Scenario; answer?:PublicChatAnswer };
const initial: Message[] = [{ id: 0, role: 'assistant', text: 'Halo, saya BILAH 👋 Apa yang ingin Anda ketahui tentang Pemilu atau layanan Bawaslu?' }];
export function ChatExperience() {
  const [messages, setMessages] = useState<Message[]>(initial);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [modal, setModal] = useState<'reset' | 'escalation' | null>(null);
  const [ticketRequestId,setTicketRequestId]=useState<string|null>(null);
  const [ticketQuestion,setTicketQuestion]=useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const request = useRef<AbortController|null>(null);
  const generation=useRef(0);
  const sequence = useRef(1);
  const busyRef = useRef(false);
  const returnFocus = useRef<HTMLElement | null>(null);
  useEffect(() => () => { request.current?.abort(); generation.current++; }, []);
  useEffect(() => {
    const view=window.visualViewport;
    const update=()=>document.documentElement.style.setProperty('--chat-height',(view?.height??window.innerHeight)+'px');
    update();view?.addEventListener('resize',update);window.addEventListener('resize',update);
    return ()=>{view?.removeEventListener('resize',update);window.removeEventListener('resize',update);document.documentElement.style.removeProperty('--chat-height');};
  }, []);

  useEffect(() => { if (messages.length > 1) endRef.current?.scrollIntoView({ behavior: 'auto', block: 'nearest' }); }, [messages, busy]);
  useEffect(() => {
    if (modal) { returnFocus.current = document.activeElement as HTMLElement; dialogRef.current?.showModal(); }
    else { dialogRef.current?.close(); returnFocus.current?.focus(); }
  }, [modal]);
  useEffect(() => {
    const topic = new URLSearchParams(window.location.search).get('topik');
    const question = quickQuestions.find(q => q.id === topic);
    if (question) { setDraft(question.title); inputRef.current?.focus(); }
  }, []);
  async function send(text = draft) {
    if (busyRef.current) return;
    const question = text.trim();
    if (!question) { setError('Tuliskan pertanyaan terlebih dahulu.'); inputRef.current?.focus(); return; }
    if (question.length > 1000) { setError('Maksimal 1.000 karakter. Silakan persingkat pertanyaan.'); return; }
    if (containsSensitivePattern(question)) { setError('Hapus NIK, password, atau data pribadi sebelum mencoba. Gunakan pertanyaan contoh.'); return; }
    busyRef.current = true;
    setError(''); setDraft(''); setBusy(true);
    setMessages(current => [...current, { id: sequence.current++, role: 'user', text: question }]);
    const attempt=++generation.current;
    const controller=new AbortController();request.current=controller;
    try {
      const answer=await askPublicBilah(question,AbortSignal.any([controller.signal,AbortSignal.timeout(85000)]));
      if(attempt!==generation.current)return;
      setMessages(current=>[...current,{id:sequence.current++,role:'assistant',text:answer.answer,answer}]);
    } catch(e) {
      if(attempt!==generation.current)return;
      setError(e instanceof Error&&e.name!=='AbortError'&&e.name!=='TimeoutError'?e.message:'Jawaban belum selesai. Silakan mencoba kembali nanti.');
      setDraft(question);
    } finally {
      if(attempt===generation.current){setBusy(false);busyRef.current=false;request.current=null;inputRef.current?.focus();}
    }
  }

  function reset() {
    request.current?.abort(); generation.current++;
    try{newPublicConversation();}catch{} busyRef.current = false; setBusy(false); setMessages(initial); setDraft(''); setError(''); setModal(null);
  }
  function openEscalation(requestId?:string) {
    const selected=requestId?messages.find(m=>m.answer?.requestId===requestId):[...messages].reverse().find(m=>m.answer?.requestId);
    if(!selected?.answer?.requestId){setError('Ajukan pertanyaan melalui chat terlebih dahulu, lalu pilih bantuan petugas.');return;}
    if(['out_of_domain','political','sensitive','injection'].includes(selected.answer.decision)){setError('Tiket konsultasi tersedia untuk pertanyaan tentang kepemiluan dan layanan Bawaslu.');return;}
    const index=messages.indexOf(selected);setTicketQuestion(messages[index-1]?.role==='user'?messages[index-1].text:'Pertanyaan dari chat BILAH');
    setTicketRequestId(selected.answer.requestId);setModal('escalation');
  }
  function onKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); send(); }
  }
  return <div className="conversation-shell simple-chat">
    <section className="conversation-card" aria-label="Percakapan BILAH">
      <header className="conversation-header">
        <img className="chat-bawaslu-logo" src="/brand/bawaslu-symbol.png" alt="Bawaslu Kabupaten Labuhanbatu" width="48" height="48" />
        <img className="chat-mascot" src="/brand/bilah-mascot.png" alt="BILAH, asisten informasi Bawaslu Labuhanbatu" width="64" height="64" />
        <details className="chat-menu"><summary aria-label="BILAH — buka menu percakapan"><img src="/brand/bilah-logo.png" alt="Logo BILAH" width="48" height="48" /><span aria-hidden="true">⌄</span></summary><nav aria-label="Menu chat">
          <button onClick={() => messages.length > 1 ? setModal('reset') : inputRef.current?.focus()}>Percakapan baru</button>
          <Link href="/tiket">Lacak tiket</Link>
          <Link href="/">Tentang BILAH</Link>
          <p>Informasi awal oleh AI, bukan keputusan resmi. Percakapan dicatat untuk evaluasi. Jangan kirim data pribadi.</p>
        </nav></details>
      </header>
      <div className="message-scroll" role="log" aria-label="Riwayat percakapan" aria-live="polite" aria-relevant="additions">
        {messages.map(message => <div key={message.id} className={`message-row ${message.role}`}>

          <div className="message-content">
          <div className="message-bubble">{message.text.split('\n\n').map((paragraph,i) => <p key={i}>{paragraph}</p>)}</div>
          {message.scenario?.sourcePending && <details className="message-sources"><summary><Icon name="book" size={15} /> Sumber informasi <span>Belum terhubung</span></summary><p>Saat layanan lengkap tersedia, judul dokumen, bagian rujukan, dan tautan resmi tampil di sini. Pratinjau ini tidak mencantumkan sumber atau nomor pasal yang belum diverifikasi.</p></details>}
          {message.answer?.basis&&<small className="answer-basis">{message.answer.delivery==='excerpt'?'Cuplikan dokumen saat AI lambat':message.answer.basis==='general'?'Penjelasan umum AI — belum diverifikasi melalui dokumen':message.answer.basis==='web'?'Panduan dari situs resmi':'Berdasarkan dokumen BILAH'}</small>}
          {message.answer?.sources.some(s=>s.url==='https://cekdptonline.kpu.go.id/')&&<p><a href="https://cekdptonline.kpu.go.id/" target="_blank" rel="noopener noreferrer">Buka Cek DPT Online KPU ↗</a></p>}
          {message.answer&&message.answer.sources.length>0&&<details className="message-sources"><summary><Icon name="book" size={15}/> Sumber jawaban <span>{message.answer.sources.length} rujukan</span></summary>{message.answer.sources.map(source=><p key={source.chunkId}>{source.url?<a href={source.url} target="_blank" rel="noopener noreferrer">{source.title} ↗</a>:<strong>{source.title}</strong>}<br/><small>{source.section}{source.filename?' · '+source.filename:''}</small></p>)}</details>}
          {message.answer&&!['out_of_domain','political','sensitive','injection'].includes(message.answer.decision) && <button className="escalate-inline" onClick={()=>openEscalation(message.answer?.requestId)}><Icon name="people" size={15} /> Butuh bantuan petugas? <span>↗</span></button>}

          </div></div>)}
        {busy && <div className="typing-state" role="status"><span></span><span></span><span></span> BILAH sedang mengetik…</div>}
        <div ref={endRef} />
      </div>
      <form className="chat-compose" onSubmit={event => { event.preventDefault(); send(); }}>
        <label htmlFor="bilah-question">Pertanyaan Anda</label><div className="input-box"><textarea ref={inputRef} id="bilah-question" value={draft} onChange={event => {setDraft(event.target.value); setError('');}} onKeyDown={onKeyDown} maxLength={1000} rows={1} placeholder="Tulis pesan…" aria-describedby="input-error" /><button type="submit" disabled={busy || !draft.trim()} aria-label="Kirim pertanyaan"><Icon name="send" /></button></div>
        {error && <p id="input-error" className="input-error" role="alert">{error}</p>}
        <p className="chat-short-note">Informasi awal AI · Jangan kirim data pribadi</p>
      </form>
    </section>
    <dialog ref={dialogRef} className="bilah-dialog" aria-label={modal === 'reset' ? 'Mulai percakapan baru' : 'Buat tiket konsultasi'} onCancel={event => {event.preventDefault();setModal(null);}} onClick={event => {if(event.target===dialogRef.current)setModal(null);}}>
      <div className="dialog-content"><button className="dialog-close" aria-label="Tutup" onClick={() => setModal(null)}><Icon name="close" /></button>
      {modal === 'reset' ? <><span className="dialog-icon"><Icon name="message" size={28} /></span><h2>Mulai percakapan baru?</h2><p>Percakapan akan dibersihkan dari layar dan sesi baru dimulai. Catatan pelayanan yang sudah tersimpan tetap dikelola oleh Bawaslu.</p><div className="dialog-actions"><button className="button secondary" onClick={() => setModal(null)}>Kembali</button><button className="button primary" onClick={reset}>Mulai baru</button></div></> : ticketRequestId ? <TicketRequest key={ticketRequestId} requestId={ticketRequestId} question={ticketQuestion}/> : null}
      </div>
    </dialog>
  </div>;
}
