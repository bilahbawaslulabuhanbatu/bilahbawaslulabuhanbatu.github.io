'use client';
import {useEffect,useState} from 'react';
import {getBrowserDatabase} from '@/lib/db/browser';
import {useInternalProfile} from './internal-app-shell';
import {ticketStatuses,ticketStatusLabels,ticketDisclaimer,type TicketStatus} from '@/lib/tickets/contracts';
type Ticket={id:string;ticket_number:string;question:string;status:TicketStatus;assigned_to:string|null;created_at:string;updated_at:string};
type Reply={id:string;message:string;visibility:string;created_at:string};
type Officer={id:string;label:string};
export function TicketManager(){
 const profile=useInternalProfile(),admin=profile?.role==='admin'||profile?.role==='superadmin';
 const [tickets,setTickets]=useState<Ticket[]>([]),[officers,setOfficers]=useState<Officer[]>([]),[selected,setSelected]=useState(''),[replies,setReplies]=useState<Reply[]>([]),[status,setStatus]=useState<TicketStatus>('baru'),[assigned,setAssigned]=useState(''),[message,setMessage]=useState(''),[visibility,setVisibility]=useState('public'),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState(''),[notice,setNotice]=useState(''),[filter,setFilter]=useState('');
 const ticket=tickets.find(t=>t.id===selected);
 async function load(){
  setLoading(true);setError('');const db=getBrowserDatabase();if(!db){setError('Sambungan data belum tersedia.');setLoading(false);return;}
  const result=await db.from('tickets').select('id,ticket_number,question,status,assigned_to,created_at,updated_at,conversations!inner(is_demo)').eq('conversations.is_demo',false).order('created_at',{ascending:false}).limit(50);
  if(result.error)setError('Tiket belum dapat dimuat.');else setTickets((result.data??[]) as Ticket[]);
  if(admin){const users=await db.from('users').select('id,display_name,roles(name)').eq('is_active',true);if(!users.error)setOfficers((users.data??[]).flatMap(u=>{const relation=u.roles as unknown as {name:string}|{name:string}[];const role=Array.isArray(relation)?relation[0]?.name:relation?.name;return ['admin','superadmin','petugas'].includes(role)?[{id:u.id,label:u.display_name||role+' · '+u.id.slice(0,8)}]:[];}));}
  setLoading(false);
 }
 useEffect(()=>{void load();},[admin]);
 useEffect(()=>{
  setReplies([]);setMessage('');setVisibility('public');setNotice('');if(!ticket)return;
  setStatus(ticket.status);setAssigned(ticket.assigned_to||'');let cancelled=false;
  const db=getBrowserDatabase();if(db)void db.from('ticket_messages').select('id,message,visibility,created_at').eq('ticket_id',ticket.id).order('created_at',{ascending:true}).limit(100).then(({data,error})=>{if(cancelled)return;if(error)setError('Tanggapan tiket belum dapat dimuat.');else setReplies((data??[]) as Reply[]);});
  return()=>{cancelled=true;};
 },[ticket?.id,ticket?.updated_at]);
 async function save(){
  if(!ticket||busy)return;setBusy(true);setError('');setNotice('');const db=getBrowserDatabase();
  try{
   if(!db)throw Error();
   const result=await db.rpc('bilah_ticket_update',{p_ticket_id:ticket.id,p_message:message,p_visibility:visibility,p_status:status,p_assigned_to:assigned||null,p_expected_updated_at:ticket.updated_at});
   if(result.error){setError(result.error.code==='40001'?'Tiket sudah berubah. Klik Muat ulang sebelum menyimpan kembali.':result.error.code==='23514'?'Periksa tanggapan: jangan masukkan data sensitif. Untuk menyelesaikan tiket, harus sudah ada tanggapan bagi pemohon.':result.error.code==='42501'?'Akses tiket tidak tersedia atau penugasan tidak diizinkan.':'Perubahan tiket belum dapat disimpan.');return;}
   await load();setMessage('');setNotice('Perubahan tersimpan. Tanggapan untuk pemohon dapat dilihat melalui pelacakan tiket.');
  }catch{setError('Perubahan tiket belum dapat disimpan.');}finally{setBusy(false);}
 }
 return <section><div className="internal-intro"><span className="eyebrow">TINDAK LANJUT MANUSIA</span><h1>Tiket konsultasi</h1><p>{ticketDisclaimer}</p><button className="button secondary" disabled={busy||loading} onClick={()=>void load()}>Muat ulang</button></div>{error&&<p className="notice" role="alert">{error}</p>}{notice&&<p className="notice" role="status">{notice}</p>}<div className="ticket-workspace"><div className="panel"><label htmlFor="ticket-filter">Filter status</label><select id="ticket-filter" value={filter} onChange={e=>setFilter(e.target.value)}><option value="">Semua status</option>{ticketStatuses.map(s=><option key={s} value={s}>{ticketStatusLabels[s]}</option>)}</select>{loading?<p role="status">Memuat tiket…</p>:!tickets.length?<p>{admin?'Belum ada tiket konsultasi.':'Belum ada tiket yang ditugaskan kepada Anda.'}</p>:tickets.filter(t=>!filter||t.status===filter).map(t=><button className="ticket-list-item" key={t.id} disabled={busy} aria-pressed={selected===t.id} onClick={()=>{setSelected(t.id);setError('');}}><strong>{t.ticket_number}</strong><span>{ticketStatusLabels[t.status]}</span><small>{t.question.slice(0,130)}</small></button>)}</div><div className="panel">{!ticket?<p>Pilih tiket untuk membaca pertanyaan dan menindaklanjutinya.</p>:<><span className="eyebrow">{ticket.ticket_number}</span><h2>Pertanyaan pemohon</h2><p style={{whiteSpace:'pre-wrap'}}>{ticket.question}</p><small>Dibuat {new Date(ticket.created_at).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})} WIB</small><h3>Riwayat tanggapan</h3>{!replies.length?<p>Belum ada tanggapan.</p>:replies.map(r=><article className="notice" key={r.id}><strong>{r.visibility==='public'?'Untuk pemohon':'Catatan internal'}</strong><small> · {new Date(r.created_at).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})} WIB</small><p style={{whiteSpace:'pre-wrap'}}>{r.message}</p></article>)}<form className="ticket-form" onSubmit={e=>{e.preventDefault();void save();}}><label htmlFor="ticket-status">Status</label><select id="ticket-status" value={status} disabled={busy} onChange={e=>setStatus(e.target.value as TicketStatus)}>{ticketStatuses.map(s=><option key={s} value={s}>{ticketStatusLabels[s]}</option>)}</select>{admin&&<><label htmlFor="ticket-assignee">Petugas penanggung jawab</label><select id="ticket-assignee" value={assigned} disabled={busy} onChange={e=>setAssigned(e.target.value)}><option value="">Belum ditugaskan</option>{officers.map(o=><option value={o.id} key={o.id}>{o.label}</option>)}</select></>}<label htmlFor="ticket-visibility">Tujuan catatan</label><select id="ticket-visibility" value={visibility} disabled={busy} onChange={e=>setVisibility(e.target.value)}><option value="public">Tanggapan untuk pemohon</option><option value="internal">Catatan internal — tidak dilihat pemohon</option></select><label htmlFor="ticket-reply">Tanggapan / catatan</label><textarea id="ticket-reply" rows={5} maxLength={10000} disabled={busy} value={message} onChange={e=>setMessage(e.target.value)} placeholder="Berikan informasi awal atau tindak lanjut sesuai kewenangan. Jangan menulis NIK, password, atau data pribadi."/><button className="button primary" type="submit" disabled={busy}>{busy?'Menyimpan…':'Simpan tindak lanjut'}</button></form></>}</div></div></section>;
}
