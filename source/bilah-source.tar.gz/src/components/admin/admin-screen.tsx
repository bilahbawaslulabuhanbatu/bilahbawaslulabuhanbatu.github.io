'use client';
import { useEffect,useState } from 'react';
import { useRouter } from 'next/navigation';
import { useInternalProfile } from './internal-app-shell';
import { getBrowserDatabase } from '@/lib/db/browser';
import { can } from '@/lib/auth/permissions';
import { Icon } from '@/components/shared/icon';
import {TicketManager} from './ticket-manager';
import {ConversationLog} from './conversation-log';
import { KnowledgeManager } from './knowledge-manager';
type Statistics={total_questions:number;today_questions:number;total_escalations:number;active_tickets:number;helpful_responses:number;feedback_count:number};
export function AdminScreen({section='dashboard'}:{section?:string}) {
 const profile=useInternalProfile(),router=useRouter();
 const [statistics,setStatistics]=useState<Statistics|null>(null),[error,setError]=useState('');
 useEffect(()=>{
  let cancelled=false;
  setStatistics(null);setError('');
  if(profile?.role==='petugas'&&section==='dashboard'){router.replace('/admin/tickets');return;}
  if(!profile||!['dashboard','analytics'].includes(section)||!can(profile.role,'dashboard:read'))return;
  const db=getBrowserDatabase();
  if(!db){setError('Koneksi database belum tersedia.');return;}
  void db.rpc('bilah_service_statistics').then(({data,error}:{data:unknown;error:unknown})=>{
   if(cancelled)return;
   if(error){setError('Statistik belum dapat dimuat. Silakan coba kembali.');return;}
   setStatistics(data as Statistics);
  });
  return()=>{cancelled=true;};
 },[profile,section,router]);
 if(['dashboard','analytics'].includes(section))return <><div className="internal-intro"><span className="eyebrow">MONITORING PELAYANAN</span><h1>{section==='analytics'?'Ringkasan statistik':'Dashboard BILAH'}</h1><p>Data aktual dari database. Pertanyaan melalui chat BILAH tercatat dalam perhitungan. Uji internal knowledge base tidak dihitung.</p></div>{error?<div className="notice" role="alert">{error}</div>:!statistics?<div className="panel" role="status">Memuat statistik…</div>:<><div className="stat-grid">{[['Total pertanyaan',statistics.total_questions,'message'],['Pertanyaan hari ini',statistics.today_questions,'document'],['Eskalasi',statistics.total_escalations,'people'],['Tiket aktif',statistics.active_tickets,'shield']].map(([title,value,icon])=><article className="stat-box" key={title}><span className="stat-icon"><Icon name={String(icon)}/></span><span>{title}</span><strong>{Number(value).toLocaleString('id-ID')}</strong></article>)}</div><div className="panel dashboard-note"><h2>Fondasi layanan sudah terhubung.</h2><p>{statistics.total_questions===0?'Belum ada pertanyaan pelayanan yang tersimpan. Angka akan berubah setelah pertanyaan dikirim melalui halaman chat BILAH.':'Ringkasan ini dihitung dari interaksi pelayanan yang tersimpan.'}</p><div className="helpful-summary"><strong>{statistics.feedback_count?`${Math.round(100*statistics.helpful_responses/statistics.feedback_count)}%`:'Belum ada penilaian'}</strong><span>Jawaban membantu · {statistics.feedback_count} penilaian</span></div></div></>}</>;
 if(section==='conversations'&&profile&&can(profile.role,'conversations:read'))return <ConversationLog/>;
 if(section==='tickets'&&profile&&(can(profile.role,'tickets:all')||can(profile.role,'tickets:assigned')))return <TicketManager/>;
 if(section==='knowledge')return <KnowledgeManager/>;
 const titles:Record<string,string>={conversations:'Percakapan',tickets:'Tiket eskalasi',knowledge:'Knowledge base',users:'User/Admin',settings:'Pengaturan layanan',forbidden:'Akses dibatasi'};
 return <section className="panel"><span className="eyebrow">AREA INTERNAL BILAH</span><h1>{titles[section]??'Layanan internal'}</h1><p>{section==='forbidden'?'Akun Anda tidak memiliki hak akses ke halaman tersebut.':'Akses akun dan database sudah disiapkan. Pengelolaan pada halaman ini akan diaktifkan sesuai tahap pembangunan berikutnya.'}</p>{section==='knowledge'&&<div className="notice">Belum ada dokumen resmi yang dimasukkan atau diaktifkan sebagai sumber jawaban.</div>}</section>;
}
