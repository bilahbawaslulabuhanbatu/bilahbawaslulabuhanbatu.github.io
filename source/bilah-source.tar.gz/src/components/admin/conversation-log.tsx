'use client';
import {useEffect,useState} from 'react';
import {getBrowserDatabase} from '@/lib/db/browser';
type Row={id:string;role:string;content:string;created_at:string;guardrail_status:string|null;reply_to_id:string|null};
export function ConversationLog(){
 const [rows,setRows]=useState<Row[]>([]),[busy,setBusy]=useState(true),[error,setError]=useState('');
 async function refresh(){
  setBusy(true);setError('');
  const db=getBrowserDatabase();if(!db){setError('Sambungan data belum tersedia.');setBusy(false);return;}
  const {data,error}=await db.from('messages').select('id,role,content,created_at,guardrail_status,reply_to_id,conversations!inner(is_demo)').eq('conversations.is_demo',false).order('created_at',{ascending:false}).limit(60);
  if(error)setError('Catatan percakapan belum dapat dimuat.');else setRows((data??[]) as Row[]);
  setBusy(false);
 }
 useEffect(()=>{void refresh();},[]);
 const questions=rows.filter(r=>r.role==='user');
 return <section><div className="internal-intro"><span className="eyebrow">CATATAN PELAYANAN</span><h1>Percakapan masyarakat</h1><p>Pertanyaan dan jawaban terbaru dari chat BILAH. Uji internal knowledge base tidak dicatat di sini.</p><button className="button secondary" disabled={busy} onClick={()=>void refresh()}>Muat ulang</button></div>{error&&<div className="notice" role="alert">{error}</div>}{busy?<div className="panel" role="status">Memuat percakapan…</div>:!questions.length?<div className="panel">Belum ada pertanyaan melalui chat BILAH.</div>:questions.map(q=>{const answer=rows.find(r=>r.reply_to_id===q.id&&r.role==='assistant');return <article className="panel" key={q.id} style={{marginBottom:16}}><small>{new Date(q.created_at).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})} WIB · {q.guardrail_status||'diproses'}</small><h2 style={{fontSize:'1.1rem'}}>{q.content}</h2><p style={{whiteSpace:'pre-wrap'}}>{answer?.content||'Jawaban belum selesai atau belum tercatat.'}</p></article>;})}</section>;
}
