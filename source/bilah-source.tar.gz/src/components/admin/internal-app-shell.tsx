'use client';
import type { AuthChangeEvent } from '@supabase/supabase-js';
import { createContext,useCallback,useContext,useEffect,useRef,useState } from 'react';
import Link from 'next/link';
import { usePathname,useRouter } from 'next/navigation';
import { Brand } from '@/components/shared/brand';
import { Icon } from '@/components/shared/icon';
import { getBrowserDatabase } from '@/lib/db/browser';
import { parseInternalProfile,type InternalProfile } from '@/lib/auth/profile';
import { can,type Permission } from '@/lib/auth/permissions';
export const internalMenu:{title:string;href:string;permission:Permission}[]=[
 {title:'Dashboard',href:'/admin',permission:'dashboard:read'},
 {title:'Percakapan',href:'/admin/conversations',permission:'conversations:read'},
 {title:'Tiket eskalasi',href:'/admin/tickets',permission:'tickets:all'},
 {title:'Knowledge base',href:'/admin/knowledge',permission:'knowledge:write'},
 {title:'Analytics',href:'/admin/analytics',permission:'analytics:read'},
 {title:'User/Admin',href:'/admin/users',permission:'users:manage'},
 {title:'Settings',href:'/admin/settings',permission:'settings:write'},
];
const Context=createContext<InternalProfile|null>(null);
export function useInternalProfile(){return useContext(Context);}
export function InternalAppShell({children}:{children:React.ReactNode}) {
 const router=useRouter(),pathname=usePathname();
 const [profile,setProfile]=useState<InternalProfile|null>(null);
 const [checking,setChecking]=useState(true);
 const [failure,setFailure]=useState('');
 const [leaving,setLeaving]=useState(false);
 const version=useRef(0);
 const verify=useCallback(async()=>{
  const attempt=++version.current;
  const db=getBrowserDatabase();
  if(!db){setFailure('Koneksi layanan internal belum tersedia.');setChecking(false);return;}
  try {
   const {data:identity,error}=await db.auth.getUser();
   if(attempt!==version.current)return;
   if(error||!identity.user){setProfile(null);router.replace('/admin/login');return;}
   const {data,error:profileError}=await db.from('users').select('id,display_name,is_active,roles(name)').eq('id',identity.user.id).single();
   if(attempt!==version.current)return;
   const current=profileError?null:parseInternalProfile(data);
   if(!current){setProfile(null);setFailure('Akun belum aktif atau hak aksesnya telah berubah. Silakan hubungi pengelola.');return;}
   setFailure('');setProfile(current);
  } catch {if(attempt===version.current){setProfile(null);setFailure('Layanan verifikasi belum dapat dihubungi.');}}
  finally {if(attempt===version.current)setChecking(false);}
 },[router]);
 useEffect(()=>{
  const db=getBrowserDatabase();let alive=true;
  void verify();
  const {data:listener}=db?.auth.onAuthStateChange((event:AuthChangeEvent)=>{
   if(event==='SIGNED_OUT'){version.current++;setProfile(null);router.replace('/admin/login');}
   if(event==='TOKEN_REFRESHED'||event==='SIGNED_IN')setTimeout(()=>{if(alive)void verify();},0);
  })??{data:null};
  const interval=setInterval(()=>{if(document.visibilityState==='visible')void verify();},60000);
  const onFocus=()=>{void verify();};window.addEventListener('focus',onFocus);
  return()=>{alive=false;version.current++;listener?.subscription.unsubscribe();clearInterval(interval);window.removeEventListener('focus',onFocus);};
 },[verify,router]);
 async function logout(){setLeaving(true);version.current++;setProfile(null);try{await getBrowserDatabase()?.auth.signOut();}finally{router.replace('/admin/login');router.refresh();}}
 if(checking||leaving)return <main id="main" className="auth-loading" role="status"><Icon name="shield" size={30}/><p>{leaving?'Mengakhiri sesi…':'Memverifikasi akses BILAH…'}</p></main>;
 if(!profile)return <main id="main" className="auth-loading"><Icon name="lock" size={30}/><p>{failure||'Mengalihkan ke halaman login…'}</p><Link href="/admin/login" className="button primary">Kembali ke login</Link></main>;
 const activeItem=internalMenu.find(item=>item.href===pathname);
 const allowed=!activeItem||can(profile.role,activeItem.permission)||(pathname==='/admin/tickets'&&can(profile.role,'tickets:assigned'));
 return <Context.Provider value={profile}><div className="admin-shell"><aside className="admin-sidebar"><Brand/><p className="badge">{profile.role}</p><nav aria-label="Menu internal">{internalMenu.filter(item=>can(profile.role,item.permission)||(item.href==='/admin/tickets'&&can(profile.role,'tickets:assigned'))).map(item=><Link key={item.href} href={item.href} aria-current={pathname===item.href?'page':undefined}>{item.title}</Link>)}</nav><button className="admin-logout" onClick={logout}>Keluar dari BILAH <span>↗</span></button><Link href="/">Kembali ke beranda</Link></aside><main id="main" className="admin-content"><header className="internal-topbar"><div><span className="eyebrow">BAWASLU KABUPATEN LABUHANBATU</span><strong>{activeItem?.title??'Area internal'}</strong></div><span>{profile.name||'Pengguna BILAH'}<small>{profile.role}</small></span></header>{allowed?children:<section className="panel"><h1>Akses dibatasi</h1><p>Halaman ini berada di luar hak akses akun Anda.</p></section>}</main></div></Context.Provider>;
}
