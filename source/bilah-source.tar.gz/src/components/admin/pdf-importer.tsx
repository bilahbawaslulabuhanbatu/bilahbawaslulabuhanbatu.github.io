'use client';
import {useEffect,useRef,useState} from 'react';
import {getBrowserDatabase} from '@/lib/db/browser';
import {useInternalProfile} from './internal-app-shell';
import {pdfLimits} from '@/lib/knowledge/pdf-metadata';
import type {ParsedPdf} from '@/lib/knowledge/read-pdf';
import {Icon} from '@/components/shared/icon';
import {containsSensitivePattern} from '@/lib/demo/scenarios';
type Category={id:string;name:string;is_active:boolean};
type Item={file?:File;key:string;name:string;parsed?:ParsedPdf;title:string;category_id:string;state:'reading'|'ready'|'error'|'duplicate'|'saved'|'active';message:string;selected:boolean;documentId?:string;updated_at?:string};
export function PdfImporter({open,onClose,onImported,categories}:{open:boolean;onClose:()=>void;onImported:()=>void;categories:Category[]}){
 const profile=useInternalProfile(),dialog=useRef<HTMLDialogElement>(null),abort=useRef<AbortController|null>(null);
 const [items,setItems]=useState<Item[]>([]),[reading,setReading]=useState(false),[saving,setSaving]=useState(false),[error,setError]=useState(''),[ack,setAck]=useState(false),[publicUse,setPublicUse]=useState(false),[progress,setProgress]=useState('');
 const input=useRef<HTMLInputElement>(null),busy=reading||saving;
 const isMounted=useRef(true);
 useEffect(()=>{isMounted.current=true;return()=>{isMounted.current=false;abort.current?.abort();};},[]);
 useEffect(()=>{if(open&&!dialog.current?.open)dialog.current?.showModal();else if(!open&&dialog.current?.open)dialog.current.close();},[open]);
 function close(){if(saving)return;abort.current?.abort();setReading(false);setItems([]);setError('');setAck(false);setPublicUse(false);setProgress('');onClose();}
 function patch(key:string,change:Partial<Item>){if(isMounted.current)setItems(all=>all.map(item=>item.key===key?{...item,...change}:item));}
 async function choose(files:File[]){
  if(busy)return;
  setError('');setAck(false);
  if(files.length===0)return;
  if(files.length>pdfLimits.files){setError('Pilih maksimal 5 PDF sekaligus.');return;}
  const batch:Item[]=files.map(file=>({file,key:crypto.randomUUID(),name:file.name,title:'',category_id:categories.find(c=>c.is_active&&/hukum/i.test(c.name))?.id??'',state:'reading' as const,message:'Menunggu pembacaan…',selected:true}));
  setItems(batch);setReading(true);const controller=new AbortController();abort.current=controller;
  try{
   const {readPdf}=await import('@/lib/knowledge/read-pdf');
   for(let index=0;index<files.length;index++){
    const item=batch[index],file=files[index];if(controller.signal.aborted)break;
    try{
     const parsed=await readPdf(file,(page,total)=>{if(isMounted.current&&!controller.signal.aborted)setProgress(`${index+1}/${files.length} berkas · ${file.name} · halaman ${page}/${total}`);},controller.signal);
     if(controller.signal.aborted)break;
     const db=getBrowserDatabase();if(!db)throw new Error('Koneksi database belum tersedia.');
     const {data,error}=await db.from('knowledge_documents').select('id').eq('source_sha256',parsed.sha256).maybeSingle();
     if(error)throw new Error('Pemeriksaan dokumen belum berhasil. Coba kembali.');
     if(data){const archived=await db.storage.from('bilah-sumber').upload(parsed.sha256+'.pdf',file,{upsert:false,contentType:'application/pdf'});
      if(archived.error&&!/duplicate|already exists/i.test(archived.error.message))throw Error('Teks sudah ada, tetapi pengarsipan berkas asli gagal.');}
     if(data||batch.slice(0,index).some(previous=>previous.parsed?.sha256===parsed.sha256))patch(item.key,{state:'duplicate',selected:false,message:'PDF ini sudah ada. Gunakan dokumen yang tersimpan.'});
     else{batch[index].parsed=parsed;patch(item.key,{parsed,title:parsed.title,state:'ready',message:`${parsed.pages} halaman dibaca · ${parsed.content.length.toLocaleString('id-ID')} karakter${parsed.emptyPages.length?' · Periksa halaman yang teksnya tidak terbaca':''}`});}
    }catch(e){if(!controller.signal.aborted){const message=e instanceof Error?e.message:'Berkas belum dapat dibaca.';patch(item.key,{state:'error',selected:false,message});await getBrowserDatabase()?.from('bilah_import_errors').insert({filename:item.name.slice(0,255),message:message.slice(0,400)});}}
   }
  }catch{if(!controller.signal.aborted)setError('Pembaca PDF belum dapat dimuat. Muat ulang halaman dan coba kembali.');}
  finally{if(isMounted.current&&!controller.signal.aborted){setReading(false);setProgress('Pembacaan selesai. Periksa hasil di bawah.');}}
 }
 async function save(activate:boolean){
  if(!profile||busy||activate&&!ack)return;
  const chosen=items.filter(i=>i.selected&&(i.state==='ready'||i.state==='saved'));
  if(!chosen.length){setError('Pilih dokumen yang ingin disimpan.');return;}
  if(chosen.some(i=>i.title.trim().length<4)){setError('Periksa judul dokumen; minimal 4 karakter.');return;}
  setSaving(true);setError('');let changed=false;
  try{
   const db=getBrowserDatabase();if(!db)throw new Error();
   for(const item of chosen){
    const parsed=item.parsed;if(!parsed)continue;
    if(containsSensitivePattern(parsed.content)){patch(item.key,{message:'Terdeteksi pola NIK/password. Periksa dan hilangkan data pribadi sebelum memasukkan dokumen.'});continue;}
    let persisted=!!item.documentId;
    try{
     let id=item.documentId,stamp=item.updated_at;
     if(!id){
      const documentId=crypto.randomUUID();
      const {data,error}=await db.from('knowledge_documents').insert({id:documentId,title:item.title.trim(),category_id:item.category_id||null,source_type:'regulasi',document_number:parsed.document_number||null,year:parsed.year?Number(parsed.year):null,content:parsed.content,summary:`Hasil baca otomatis ${parsed.filename}; ${parsed.pages} halaman. Judul/nomor/tahun adalah usulan dan perlu diperiksa.${parsed.emptyPages.length?' Halaman tanpa teks yang memadai: '+parsed.emptyPages.join(', ')+'. Gambar, bagan, tanda tangan dan hasil pindai tidak ditafsirkan.':''}`,source_url:null,source_origin:'uploaded_pdf',source_filename:parsed.filename,source_sha256:parsed.sha256,source_page_count:parsed.pages,visibility:publicUse?'public':'internal',status:'inactive',created_by:profile.id}).select('id,updated_at').single();
      if(error||!data){if(error?.code==='23505'){patch(item.key,{state:'duplicate',selected:false,message:'PDF sudah tersimpan. Tidak dibuat duplikat.'});continue;}throw new Error();}
      id=data.id;stamp=data.updated_at;changed=true;persisted=true;patch(item.key,{documentId:id,updated_at:stamp,state:'saved',message:'Draf tersimpan.'});
     }
     if(item.file){
      const object=parsed.sha256+'.pdf';
      const {error:archiveError}=await db.storage.from('bilah-sumber').upload(object,item.file,{upsert:false,contentType:'application/pdf'});
      if(archiveError&&!/already exists|duplicate/i.test(archiveError.message)){patch(item.key,{message:'Teks tersimpan, tetapi pengarsipan PDF gagal. Coba simpan kembali.'});continue;}
     }
     if(activate){
      const {data,error}=await db.from('knowledge_documents').update({status:'active',verified_by:profile.id,verified_at:new Date().toISOString()}).eq('id',id).eq('updated_at',stamp).select('id,status,updated_at').maybeSingle();
      // Approval uses the exact saved revision; concurrent edits require review again.
      if(error||!data||data.status!=='active')throw new Error();
      changed=true;patch(item.key,{state:'active',selected:false,updated_at:data.updated_at,message:publicUse?'Aktif untuk uji jawaban publik.':'Aktif untuk internal.'});
     }
    }catch{patch(item.key,{message:persisted?'Draf tersimpan; aktivasi belum berhasil. Buka dari daftar dokumen untuk memeriksa.':'Penyimpanan belum selesai. Coba Simpan draf lagi; PDF yang sama tidak akan digandakan.'});}
   }
  }catch{setError('Penyimpanan belum berhasil. Periksa koneksi dan coba kembali.');}
  finally{if(isMounted.current){setSaving(false);if(changed)onImported();}}
 }
 const chosen=items.filter(i=>i.selected&&(i.state==='ready'||i.state==='saved')).length;
 return <dialog ref={dialog} className="kb-dialog kb-import-dialog" aria-labelledby="pdf-import-title" onCancel={e=>{e.preventDefault();close();}} onClose={()=>{if(open)close();}}><div className="kb-editor"><header><div><span className="eyebrow">DARI DOKUMEN MENJADI SUMBER JAWABAN</span><h2 id="pdf-import-title">Unggah dokumen peraturan</h2></div><button className="kb-close" disabled={saving} onClick={close} aria-label="Tutup unggahan">×</button></header><p className="kb-form-note">Pilih PDF. BILAH membaca teks, menyiapkan judul, nomor dan tahun bila dikenali, lalu membagi isi menjadi rujukan per halaman. Tidak perlu menyalin pasal satu per satu.</p>
 <input ref={input} type="file" accept="application/pdf,.pdf" multiple hidden onChange={e=>{void choose(Array.from(e.target.files??[]));e.target.value='';}}/>
 {items.length===0?<button className="kb-upload-zone" disabled={busy} onClick={()=>input.current?.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();void choose(Array.from(e.dataTransfer.files));}}><Icon name="document" size={34}/><strong>Pilih atau letakkan PDF di sini</strong><span>Maksimal 5 berkas · 15 MB per berkas · 300 halaman</span></button>:<button className="text-link kb-reselect" disabled={busy} onClick={()=>input.current?.click()}>Pilih berkas lain</button>}
 <p className="kb-import-note">PDF dibaca di perangkat Anda. Teks hasil baca dan identitas berkas disimpan sebagai sumber BILAH; berkas PDF asli belum diarsipkan di aplikasi. PDF gambar memerlukan OCR yang belum tersedia.</p>
 {error&&<div className="kb-alert error" role="alert">{error}</div>}{progress&&<p className="kb-import-progress" role="status">{progress}</p>}
 <div className="kb-import-list">{items.map(item=><article key={item.key} className="kb-import-item"><header><input type="checkbox" aria-label={`Pilih ${item.name}`} checked={item.selected} disabled={busy||!['ready','saved'].includes(item.state)} onChange={e=>{patch(item.key,{selected:e.target.checked});setAck(false);}}/><div><strong>{item.name}</strong><span>{item.message}</span></div><span className={'kb-status '+(item.state==='active'?'active':item.state==='error'?'outdated':'inactive')}>{({reading:'Membaca',ready:'Siap diperiksa',error:'Perlu diperbaiki',duplicate:'Sudah ada',saved:'Draf tersimpan',active:'Aktif'})[item.state]}</span></header>{item.parsed&&<><div className="kb-form-grid"><label>Judul yang dikenali<input maxLength={300} disabled={busy||item.state!=='ready'} value={item.title} onChange={e=>{patch(item.key,{title:e.target.value});setAck(false);}}/></label><label>Kategori<select disabled={busy||item.state!=='ready'} value={item.category_id} onChange={e=>patch(item.key,{category_id:e.target.value})}><option value="">Belum dikategorikan</option>{categories.filter(c=>c.is_active).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label></div>{item.parsed.emptyPages.length>0&&<div className="kb-alert">Periksa halaman {item.parsed.emptyPages.join(', ')}: teksnya kosong atau sangat sedikit. Informasi dalam gambar/bagan tidak dibaca otomatis.</div>}<details className="kb-extra"><summary>Periksa teks hasil baca · {item.parsed.pages} halaman</summary><div className="kb-source-text">{item.parsed.content}</div><small>Nomor halaman PDF dapat berbeda dari nomor halaman tercetak.</small></details></>}</article>)}</div>
 {items.some(i=>i.parsed)&&<><label className="kb-check"><input type="checkbox" disabled={busy||items.some(i=>i.state==='saved'||i.state==='active')} checked={publicUse} onChange={e=>{setPublicUse(e.target.checked);setAck(false);}}/><span><strong>Dokumen terpilih boleh digunakan untuk informasi masyarakat.</strong><small>Biarkan tidak dicentang untuk bahan khusus internal.</small></span></label><label className="kb-check"><input type="checkbox" disabled={busy} checked={ack} onChange={e=>setAck(e.target.checked)}/><span>Saya telah memeriksa hasil baca dan memastikan dokumen yang dipilih resmi, masih berlaku, serta tidak mengandung informasi yang dikecualikan atau data pribadi.</span></label><footer className="kb-form-actions"><button className="button secondary" disabled={busy||!chosen} onClick={()=>void save(false)}>Simpan draf ({chosen})</button><button className="button primary" disabled={busy||!chosen||!ack} onClick={()=>void save(true)}>{saving?'Menyimpan…':`Setujui & simpan (${chosen})`}</button></footer></>}
 </div></dialog>;
}
