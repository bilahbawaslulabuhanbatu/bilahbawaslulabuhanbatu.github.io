'use client';
import Link from 'next/link';
import { useEffect,useRef,useState } from 'react';
import { getBrowserDatabase } from '@/lib/db/browser';
import { Icon } from '@/components/shared/icon';

type Invitation={id:string;email:string};
async function consumeInvitation():Promise<Invitation>{
 const fragment=new URLSearchParams(window.location.hash.slice(1));
 const type=fragment.get('type');
 const accessToken=fragment.get('access_token');
 const refreshToken=fragment.get('refresh_token');
 // Tokens must never remain in browser history or be sent to application logs.
 window.history.replaceState(null,'',window.location.pathname);
 if(type!=='invite'||!accessToken||!refreshToken)throw new Error('INVITATION_REQUIRED');
 const db=getBrowserDatabase();
 if(!db)throw new Error('AUTH_UNAVAILABLE');
 const {error}=await db.auth.setSession({access_token:accessToken,refresh_token:refreshToken});
 if(error)throw new Error('INVITATION_INVALID');
 const {data:identity,error:identityError}=await db.auth.getUser();
 if(identityError||!identity.user||!identity.user.email||!identity.user.email_confirmed_at)throw new Error('INVITATION_INVALID');
 return {id:identity.user.id,email:identity.user.email};
}
export function InviteActivation(){
 const setup=useRef<Promise<Invitation>|null>(null);
 const [identity,setIdentity]=useState<Invitation|null>(null);
 const [loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[done,setDone]=useState(false);
 const [password,setPassword]=useState(''),[confirmation,setConfirmation]=useState(''),[error,setError]=useState('');
 useEffect(()=>{
  let alive=true;
  setup.current??=consumeInvitation();
  void setup.current.then(result=>{if(alive)setIdentity(result);}).catch(()=>{if(alive)setError('Tautan undangan tidak tersedia atau sudah kedaluwarsa. Minta undangan baru dari pengelola BILAH.');}).finally(()=>{if(alive)setLoading(false);});
  return()=>{alive=false;};
 },[]);
 async function savePassword(event:React.FormEvent<HTMLFormElement>){
  event.preventDefault();if(busy||!identity)return;
  if(password.length<12){setError('Gunakan password setidaknya 12 karakter.');return;}
  if(password!==confirmation){setError('Konfirmasi password belum sama.');return;}
  setError('');setBusy(true);
  try{
   const db=getBrowserDatabase();if(!db)throw new Error('AUTH_UNAVAILABLE');
   const {data:verified,error:verificationError}=await db.auth.getUser();
   if(verificationError||verified.user?.id!==identity.id)throw new Error('SESSION_CHANGED');
   const {error:updateError}=await db.auth.updateUser({password});
   if(updateError)throw new Error('PASSWORD_UPDATE_FAILED');
   setPassword('');setConfirmation('');setDone(true);
   await db.auth.signOut({scope:'local'});
  }catch{setError('Password belum dapat disimpan. Periksa koneksi atau minta undangan baru dari pengelola.');}
  finally{setBusy(false);}
 }
 if(loading)return <p className="notice" role="status">Memverifikasi undangan Supabase…</p>;
 if(done)return <div className="activation-success" role="status"><Icon name="check" size={28}/><h2>Password berhasil disimpan.</h2><p>Beri tahu pengelola bahwa aktivasi undangan sudah selesai. Akses admin akan diberikan setelah akun ini diperiksa.</p><Link href="/admin/login" className="button primary">Ke halaman login</Link></div>;
 if(!identity)return <><p className="notice" role="alert">{error}</p><Link href="/admin/login" className="text-link">Kembali ke login</Link></>;
 return <form className="internal-login-form" onSubmit={savePassword}><div className="connection-note"><Icon name="shield" size={18}/><span>Undangan terverifikasi untuk {identity.email}</span></div><p className="microcopy">Buat password BILAH Anda sendiri. Password dikirim langsung ke Supabase dan tidak dicatat oleh aplikasi.</p><label htmlFor="new-password">Password baru</label><input id="new-password" type="password" autoComplete="new-password" minLength={12} maxLength={256} value={password} onChange={event=>setPassword(event.target.value)} required disabled={busy}/><label htmlFor="confirm-password">Ulangi password</label><input id="confirm-password" type="password" autoComplete="new-password" minLength={12} maxLength={256} value={confirmation} onChange={event=>setConfirmation(event.target.value)} required disabled={busy}/><p className="input-error" role="alert">{error}</p><button type="submit" className="button primary" disabled={busy}>{busy?'Menyimpan password…':'Simpan password BILAH'}</button><p className="microcopy">Halaman ini menyelesaikan undangan akun. Hak akses ditetapkan oleh pengelola secara terpisah.</p></form>;
}
