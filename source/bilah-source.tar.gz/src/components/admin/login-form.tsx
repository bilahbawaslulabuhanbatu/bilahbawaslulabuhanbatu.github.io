'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { getBrowserDatabase } from '@/lib/db/browser';
import { parseInternalProfile } from '@/lib/auth/profile';
import { Icon } from '@/components/shared/icon';
export function LoginForm() {
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState('');
  const router=useRouter();
  const configured=Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && (process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY));
  async function login(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (busy) return;
    setError('');setBusy(true);
    const db=getBrowserDatabase();
    if(!db){setError('Koneksi layanan belum tersedia. Silakan hubungi pengelola.');setBusy(false);return;}
    try {
      const {error:authError}=await db.auth.signInWithPassword({email:email.trim(),password});
      if(authError){setError('Belum dapat masuk. Periksa email dan password atau hubungi pengelola akun.');return;}
      const {data:identity,error:identityError}=await db.auth.getUser();
      if(identityError||!identity.user){await db.auth.signOut();setError('Sesi belum dapat diverifikasi. Silakan masuk kembali.');return;}
      const {data,error:profileError}=await db.from('users').select('id,display_name,is_active,roles(name)').eq('id',identity.user.id).single();
      const profile=profileError?null:parseInternalProfile(data);
      if(!profile){await db.auth.signOut();setError('Akun belum diaktifkan sebagai pengguna internal BILAH. Hubungi pengelola.');return;}
      setPassword('');router.replace(profile.role==='petugas'?'/admin/tickets':'/admin');router.refresh();
    } catch {setError('Layanan login sedang tidak dapat dihubungi. Silakan coba kembali.');}
    finally {setBusy(false);}
  }
  return <form onSubmit={login} className="internal-login-form"><div className="connection-note"><Icon name="shield" size={17}/><span>{configured?'Terhubung ke Supabase · akses sesuai peran':'Koneksi login belum dikonfigurasi'}</span></div><label htmlFor="email">Email akun BILAH</label><input id="email" name="email" type="email" autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email akun petugas" maxLength={254} required disabled={busy||!configured}/><label htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password akun BILAH" maxLength={256} required disabled={busy||!configured}/><p className="input-error" role="alert">{error}</p><button className="button primary" type="submit" disabled={busy||!configured}>{busy?'Memverifikasi akun…':'Masuk ke BILAH'} <Icon name="arrow" size={17}/></button><p className="microcopy">Akun petugas BILAH dibuat oleh pengelola. Akun ini terpisah dari akun ChatGPT dan akun dashboard Supabase.</p></form>;
}
