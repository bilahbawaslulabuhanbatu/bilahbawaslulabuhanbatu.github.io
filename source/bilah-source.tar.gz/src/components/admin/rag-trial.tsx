'use client';
import {useEffect,useRef,useState} from 'react';
import cases from '../../lib/knowledge/audit-cases.json';
import {askAI} from '@/lib/ai/preview-client';
import {contextualQuestion} from '@/lib/chat/question-context';
type Result={pertanyaan:string;hasil:string;jawaban:string;bukti:string};
const pause=(ms:number)=>new Promise(r=>setTimeout(r,ms));
export function RagTrial(){
 const [rows,set]=useState<Result[]>([]),[running,run]=useState(false),active=useRef(false);
 useEffect(()=>()=>{active.current=false},[]);
 async function start(){if(active.current)return;active.current=true;run(true);set([]);
  try{for(let i=0;i<cases.length&&active.current;i++){const [q]=cases[i];let row:Result;
   try{const a=await askAI(i===1?contextualQuestion(q,[cases[0][0]]):q);
    const cited=a.sources.filter(s=>s.quote&&a.trace?.retrieved.includes(s.chunkId));
    row={pertanyaan:q,hasil:a.mode==='gemini'&&a.basis==='knowledge'&&cited.length?'Kutipan cocok; periksa substansi':a.decision,jawaban:a.answer,bukti:cited.map(s=>s.title+' | '+s.section+' | '+s.chunkId+' | '+s.quote).join('\n')};
   }catch(e){row={pertanyaan:q,hasil:'Belum teruji',jawaban:e instanceof Error?e.message:'Gangguan layanan',bukti:''};}
   if(!active.current)break;set(prev=>[...prev,row]);if(row.hasil==='Belum teruji'&&/kuota|batas/i.test(row.jawaban))break;
   if(i+1<cases.length)for(let t=0;t<41&&active.current;t++)await pause(1000);
  }}finally{active.current=false;run(false)}
 }
 function download(){const b=new Blob([JSON.stringify(rows,null,2)],{type:'application/json'});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download='BILAH-bukti-uji.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
 return <details><summary>Uji 20 pertanyaan dengan Gemini</summary><p>Uji internal menggunakan kuota AI. Biarkan halaman terbuka. Hasil mencantumkan teks jawaban, sumber dan kutipan asli. Kecocokan kutipan belum membuktikan kesimpulan hukum benar.</p><button disabled={running} onClick={()=>void start()}>Mulai uji 20 pertanyaan</button>{running&&<button onClick={()=>{active.current=false}}>Hentikan</button>}{rows.length>0&&<button onClick={download}>Unduh bukti ({rows.length})</button>}{rows.map(r=><details key={r.pertanyaan}><summary>{r.pertanyaan} · {r.hasil}</summary><p>{r.jawaban}</p><pre style={{whiteSpace:'pre-wrap'}}>{r.bukti}</pre></details>)}</details>
}
