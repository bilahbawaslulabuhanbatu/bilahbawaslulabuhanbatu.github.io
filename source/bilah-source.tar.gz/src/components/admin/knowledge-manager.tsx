'use client';
import {useCallback,useEffect,useRef,useState,type FormEvent} from 'react';
import {getBrowserDatabase} from '@/lib/db/browser';
import {useInternalProfile} from './internal-app-shell';
import {can} from '@/lib/auth/permissions';
import {Icon} from '@/components/shared/icon';
import {documentSchema,documentFields,emptyDocument,sourceTypes,statusLabels,isOfficialSource,hasSourceProvenance,type DocumentForm,type KnowledgeDocument} from '@/lib/knowledge/contracts';
import {containsSensitivePattern} from '@/lib/demo/scenarios';
import {IndexMonitor} from './index-monitor';
import {AnswerTester} from './knowledge-tester';
import {PdfImporter} from './pdf-importer';
type Category={id:string;name:string;is_active:boolean};
type Overview=Omit<KnowledgeDocument,'content'|'summary'>;
type Editor={id:string|null;updated_at:string|null;form:DocumentForm};
const pageSize=12;
const overviewFields=documentFields.split(',').filter(f=>!['content','summary'].includes(f)).join(',');
function formatDate(value:string){return new Date(value).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Jakarta'})+' WIB';}
function toForm(row:KnowledgeDocument):DocumentForm{return {...row,category_id:row.category_id??'',document_number:row.document_number??'',year:row.year?.toString()??'',source_url:row.source_url??'',effective_date:row.effective_date??''};}
export function KnowledgeManager(){
 const profile=useInternalProfile();
 const [tab,setTab]=useState<'documents'|'test'|'index'>('documents');
 const [importing,setImporting]=useState(false);
 const [rows,setRows]=useState<Overview[]>([]),[categories,setCategories]=useState<Category[]>([]);
 const [query,setQuery]=useState(''),[search,setSearch]=useState(''),[category,setCategory]=useState(''),[status,setStatus]=useState(''),[page,setPage]=useState(0),[total,setTotal]=useState(0);
 const [loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [editor,setEditor]=useState<Editor|null>(null),[approval,setApproval]=useState<KnowledgeDocument|null>(null),[ack,setAck]=useState(false),[revision,setRevision]=useState(0);
 const editorDialog=useRef<HTMLDialogElement>(null),approvalDialog=useRef<HTMLDialogElement>(null),request=useRef(0);
 const allowed=!!profile&&can(profile.role,'knowledge:write');
 const load=useCallback(async()=>{
  if(!allowed)return;
  const seq=++request.current;setLoading(true);setError('');
  try{
   const db=getBrowserDatabase();if(!db)throw new Error();
   let q=db.from('knowledge_documents').select(overviewFields,{count:'exact'}).order('updated_at',{ascending:false}).order('id').range(page*pageSize,(page+1)*pageSize-1);
   if(search)q=q.ilike('title','%'+search.replace(/[\\%_]/g,'\\$&')+'%');
   if(category)q=q.eq('category_id',category);
   if(status)q=q.eq('status',status);
   const [docs,cats]=await Promise.all([q,db.from('categories').select('id,name,is_active').order('name')]);
   if(seq!==request.current)return;
   if(docs.error||cats.error)throw new Error();
   setRows(docs.data as unknown as Overview[]);setTotal(docs.count??0);setCategories(cats.data??[]);
  }catch{if(seq===request.current){setRows([]);setError('Dokumen belum dapat dimuat. Periksa koneksi, lalu tekan Muat ulang.');}}
  finally{if(seq===request.current)setLoading(false);}
 },[allowed,page,search,category,status]);
 useEffect(()=>{void load();return()=>{request.current++;};},[load]);
 useEffect(()=>{const dialog=editorDialog.current;if(editor&&!dialog?.open)dialog?.showModal();else if(!editor&&dialog?.open)dialog.close();},[editor]);
 useEffect(()=>{const dialog=approvalDialog.current;if(approval&&!dialog?.open)dialog?.showModal();else if(!approval&&dialog?.open)dialog.close();},[approval]);
 async function openDocument(id:string,kind:'edit'|'approve'){
  if(busy)return;setBusy(true);setError('');setNotice('');
  try{const db=getBrowserDatabase();if(!db)throw new Error();const {data,error}=await db.from('knowledge_documents').select(documentFields).eq('id',id).single();if(error||!data)throw new Error();const row=data as KnowledgeDocument;if(kind==='edit')setEditor({id:row.id,updated_at:row.updated_at,form:toForm(row)});else{setApproval(row);setAck(false);}}
  catch{setError('Dokumen tidak dapat dibuka. Muat ulang halaman dan coba kembali.');}finally{setBusy(false);}
 }
 function change<K extends keyof DocumentForm>(key:K,value:DocumentForm[K]){setEditor(current=>current?{...current,form:{...current.form,[key]:value}}:null);}
 async function save(event:FormEvent){
  event.preventDefault();if(!editor||!profile||busy)return;setError('');setNotice('');
  const parsed=documentSchema.safeParse(editor.form);
  if(!parsed.success){setError(parsed.error.issues[0]?.message??'Periksa data dokumen.');return;}
  const form=parsed.data;
  if(containsSensitivePattern(form.content+' '+form.summary)){setError('Hapus NIK, password, atau data pribadi dari isi sumber.');return;}
  const payload={...form,category_id:form.category_id||null,year:form.year?Number(form.year):null,document_number:form.document_number||null,source_url:form.source_url||null,effective_date:form.effective_date||null,status:'inactive',verified_by:null,verified_at:null};
  setBusy(true);
  try{
   const db=getBrowserDatabase();if(!db)throw new Error();
   const result=editor.id?await db.from('knowledge_documents').update(payload).eq('id',editor.id).eq('updated_at',editor.updated_at).select('id').maybeSingle():await db.from('knowledge_documents').insert({...payload,created_by:profile.id}).select('id').single();
   if(result.error)throw new Error();
   if(!result.data){setError('Dokumen sudah diubah di tempat lain. Tutup formulir, lalu buka ulang agar perubahan tidak tertimpa.');return;}
   setEditor(null);setNotice('Draf tersimpan. Baca kembali isinya, lalu gunakan Verifikasi & aktifkan jika sudah benar.');setRevision(v=>v+1);await load();
  }catch{setError('Draf belum tersimpan. Pastikan akun masih aktif dan coba kembali.');}finally{setBusy(false);}
 }
 async function changeStatus(row:Overview,newStatus:'active'|'inactive'|'outdated'){
  if(!profile||busy||(newStatus==='active'&&(!ack||!approval)))return;
  setBusy(true);setError('');setNotice('');
  try{
   const db=getBrowserDatabase();if(!db)throw new Error();
   const {data,error}=await db.from('knowledge_documents').update({status:newStatus,verified_by:newStatus==='active'?profile.id:null,verified_at:newStatus==='active'?new Date().toISOString():null}).eq('id',row.id).eq('updated_at',row.updated_at).select('id,status').maybeSingle();
   if(error)throw new Error();
   if(!data){setError('Dokumen sudah berubah. Tutup pemeriksaan lalu buka ulang versi terbaru.');return;}
   if(data.status!==newStatus)throw new Error();
   setApproval(null);setNotice(newStatus==='active'?'Dokumen telah diverifikasi dan diaktifkan. Coba pertanyaan pada tab Uji jawaban.':newStatus==='outdated'?'Dokumen ditandai tidak berlaku dan dikeluarkan dari sumber jawaban.':'Dokumen dinonaktifkan dan dikeluarkan dari sumber jawaban.');setRevision(v=>v+1);await load();
  }catch{setError('Status belum berubah. Untuk aktivasi, pastikan isi lengkap dan tautan berasal dari situs resmi.');}finally{setBusy(false);}
 }
 if(!allowed)return <section className="panel"><h1>Akses dibatasi</h1><p>Pengelolaan sumber hanya tersedia bagi admin.</p></section>;
 const sharedError=error&&<div className="kb-alert error" role="alert">{error}</div>;
 return <>
  <div className="internal-intro kb-intro"><div><span className="eyebrow">SUMBER YANG DAPAT DIPERIKSA</span><h1>Knowledge Base BILAH</h1><p>Kelola bahan rujukan. Periksa dulu, setujui, lalu uji jawabannya.</p></div><span className="kb-connection"><span/> {loading?'Memuat database…':error?'Periksa koneksi layanan':'Data dari Supabase'}</span></div>
  <div className="kb-tabs" role="group" aria-label="Bagian basis pengetahuan"><button aria-pressed={tab==='documents'} onClick={()=>setTab('documents')}><Icon name="document" size={17}/> Dokumen sumber</button><button aria-pressed={tab==='test'} onClick={()=>setTab('test')}><Icon name="message" size={17}/> Uji jawaban</button><button aria-pressed={tab==='index'} onClick={()=>setTab('index')}>Status indeks</button></div>
  {notice&&<div className="kb-alert success" role="status">{notice}</div>}{!editor&&!approval&&sharedError}
  {tab==='index'?<IndexMonitor/>:tab==='test'?<AnswerTester key={revision}/>:<>
   <div className="kb-workflow"><div><b>1</b><span><strong>Masukkan sumber</strong><small>Unggah PDF peraturan</small></span></div><div><b>2</b><span><strong>Periksa & setujui</strong><small>Pastikan berlaku dan aman</small></span></div><div><b>3</b><span><strong>Uji jawabannya</strong><small>Lihat kutipan dan rujukan</small></span></div></div>
   <section className="kb-upload-banner"><div><Icon name="document" size={26}/><span><strong>Masukkan peraturan langsung dari PDF</strong><small>Unggah beberapa berkas, baca otomatis, lalu setujui sekaligus.</small></span></div><button className="button primary" disabled={busy} onClick={()=>setImporting(true)}>Unggah PDF</button></section>
   <section className="panel kb-library"><header className="kb-library-header"><div><h2>Dokumen sumber</h2><p>{total} dokumen sesuai filter</p></div><button className="button primary" disabled={busy} onClick={()=>{setError('');setNotice('');setEditor({id:null,updated_at:null,form:{...emptyDocument}});}}>Tulis manual</button></header>
    <form className="kb-filters" onSubmit={e=>{e.preventDefault();setPage(0);setSearch(query.trim());}}><label><span>Cari judul</span><div className="kb-search"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Ketik judul dokumen…" maxLength={100}/><button type="submit" aria-label="Cari dokumen"><Icon name="arrow" size={18}/></button></div></label><label><span>Kategori</span><select value={category} onChange={e=>{setCategory(e.target.value);setPage(0);}}><option value="">Semua kategori</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}{!c.is_active?' (nonaktif)':''}</option>)}</select></label><label><span>Status</span><select value={status} onChange={e=>{setStatus(e.target.value);setPage(0);}}><option value="">Semua status</option>{Object.entries(statusLabels).map(([key,label])=><option value={key} key={key}>{label}</option>)}</select></label></form>
    {loading?<div className="kb-empty" role="status">Memuat dokumen…</div>:rows.length===0?<div className="kb-empty"><Icon name="document" size={36}/><h3>{search||category||status?'Dokumen tidak ditemukan':'Mari siapkan sumber pertama'}</h3><p>{search||category||status?'Ubah kata pencarian atau filter untuk melihat dokumen lain.':'Gunakan Unggah PDF agar isi dokumen dibaca otomatis. Periksa hasilnya sebelum disetujui.'}</p></div>:<div className="kb-table-wrap"><table className="kb-table"><thead><tr><th>Dokumen</th><th>Kategori</th><th>Status</th><th>Tindakan</th></tr></thead><tbody>{rows.map(row=><tr key={row.id}><td><strong>{row.title}</strong><small>{sourceTypes[row.source_type]} · {row.year??'Tanpa tahun'} · v{row.version}</small><small>{row.visibility==='public'?'Diizinkan untuk chat publik':'Khusus internal'} · {formatDate(row.updated_at)}</small></td><td>{categories.find(c=>c.id===row.category_id)?.name??'Belum dikategorikan'}</td><td><span className={'kb-status '+row.status}>{statusLabels[row.status]}</span></td><td><div className="kb-row-actions"><button disabled={busy} onClick={()=>void openDocument(row.id,'edit')}>Lihat / edit</button>{row.status!=='active'&&<button disabled={busy} onClick={()=>void openDocument(row.id,'approve')}>Verifikasi & aktifkan</button>}{row.status==='active'&&<button disabled={busy} onClick={()=>void changeStatus(row,'inactive')}>Nonaktifkan</button>}{row.status!=='outdated'&&<button disabled={busy} onClick={()=>void changeStatus(row,'outdated')}>Tandai tidak berlaku</button>}</div></td></tr>)}</tbody></table></div>}
    <footer className="kb-pagination"><button className="text-link" onClick={()=>void load()} disabled={busy||loading}>Muat ulang</button><span>Halaman {page+1} dari {Math.max(1,Math.ceil(total/pageSize))}</span><div><button disabled={page===0||loading} onClick={()=>setPage(p=>p-1)} aria-label="Halaman sebelumnya">←</button><button disabled={(page+1)*pageSize>=total||loading} onClick={()=>setPage(p=>p+1)} aria-label="Halaman berikutnya">→</button></div></footer>
   </section><p className="kb-footnote"><Icon name="shield" size={15}/> Sumber yang diaktifkan admin dapat digunakan oleh chat BILAH. Uji jawaban internal tidak mencatat pelayanan atau membuat tiket.</p>
  </>}
  <dialog ref={editorDialog} className="kb-dialog" aria-labelledby="kb-editor-title" onCancel={e=>{e.preventDefault();if(!busy)setEditor(null);}} onClose={()=>{if(!busy)setEditor(null);}}>{editor&&<form onSubmit={save} className="kb-editor"><header><div><span className="eyebrow">KURASI SUMBER RESMI</span><h2 id="kb-editor-title">{editor.id?'Periksa / edit dokumen':'Tambah dokumen'}</h2></div><button className="kb-close" type="button" disabled={busy} onClick={()=>setEditor(null)} aria-label="Tutup formulir">×</button></header><p className="kb-form-note">Salin teks dari sumber resmi. Menyimpan perubahan akan menjadikan dokumen draf dan meminta verifikasi ulang.</p>{sharedError}<fieldset disabled={busy}>
    <label>Judul dokumen *<input required maxLength={300} value={editor.form.title} onChange={e=>change('title',e.target.value)} placeholder="Contoh: Tugas dan kewenangan Bawaslu Kabupaten" autoFocus/></label>
    <div className="kb-form-grid"><label>Kategori<select value={editor.form.category_id} onChange={e=>change('category_id',e.target.value)}><option value="">Pilih kategori</option>{categories.filter(c=>c.is_active||c.id===editor.form.category_id).map(c=><option key={c.id} value={c.id}>{c.name}{!c.is_active?' (nonaktif)':''}</option>)}</select></label><label>Jenis sumber<select value={editor.form.source_type} onChange={e=>change('source_type',e.target.value as DocumentForm['source_type'])}>{Object.entries(sourceTypes).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></label></div>
    <label>Tautan sumber resmi<input type="url" maxLength={2048} value={editor.form.source_url} onChange={e=>change('source_url',e.target.value)} placeholder="https://…bawaslu.go.id/…"/><small>Wajib untuk sumber manual. Dokumen PDF unggahan dapat memakai identitas berkas sebagai rujukan.</small></label>
    <label>Isi sumber *<textarea required minLength={40} maxLength={500000} rows={10} value={editor.form.content} onChange={e=>change('content',e.target.value)} placeholder="Salin informasi yang relevan, termasuk rujukan pasal jika ada. Jangan masukkan dokumen pribadi atau data pelapor."/><small>{editor.form.content.length.toLocaleString('id-ID')} / 500.000 karakter</small></label>
    <label>Ringkasan untuk pengelola<textarea maxLength={3000} rows={3} value={editor.form.summary} onChange={e=>change('summary',e.target.value)} placeholder="Catatan pengelola. Jawaban uji mengambil isi sumber, bukan catatan ini."/></label>
    <details className="kb-extra"><summary>Nomor, tahun, dan tanggal berlaku (opsional)</summary><div className="kb-form-grid"><label>Nomor dokumen<input maxLength={100} value={editor.form.document_number} onChange={e=>change('document_number',e.target.value)}/></label><label>Tahun<input type="number" min={1900} max={2200} value={editor.form.year} onChange={e=>change('year',e.target.value)}/></label></div><label>Tanggal mulai berlaku<input type="date" value={editor.form.effective_date} onChange={e=>change('effective_date',e.target.value)}/></label></details>
    <label className="kb-check"><input type="checkbox" checked={editor.form.visibility==='public'} onChange={e=>change('visibility',e.target.checked?'public':'internal')}/><span><strong>Isi sumber ini boleh ditampilkan kepada masyarakat.</strong><small>Centang hanya untuk informasi terbuka. Sumber internal tetap dikelola, tetapi tidak dipakai dalam uji jawaban publik.</small></span></label>
   </fieldset><footer className="kb-form-actions"><button type="button" className="button secondary" disabled={busy} onClick={()=>setEditor(null)}>Batal</button><button type="submit" className="button primary" disabled={busy}>{busy?'Menyimpan…':'Simpan sebagai draf'}</button></footer></form>}</dialog>
  <dialog ref={approvalDialog} className="kb-dialog" aria-labelledby="kb-approval-title" onCancel={e=>{e.preventDefault();if(!busy)setApproval(null);}} onClose={()=>{if(!busy)setApproval(null);}}>{approval&&<div className="kb-editor"><header><div><span className="eyebrow">PERSETUJUAN MANUSIA</span><h2 id="kb-approval-title">Verifikasi sumber</h2></div><button className="kb-close" disabled={busy} onClick={()=>setApproval(null)} aria-label="Tutup pemeriksaan">×</button></header>{sharedError}<h3>{approval.title}</h3><p className="kb-form-note">Versi {approval.version} · {approval.visibility==='public'?'Diizinkan untuk masyarakat':'Khusus internal — tidak masuk uji jawaban publik'}</p>{approval.source_url&&isOfficialSource(approval.source_url)?<a className="kb-source-link" href={approval.source_url} target="_blank" rel="noopener noreferrer">Buka sumber resmi ↗</a>:<div className={hasSourceProvenance(approval)?"kb-alert":"kb-alert error"}>{hasSourceProvenance(approval)?`Sumber PDF unggahan: ${approval.source_filename}. Periksa kesesuaian teks dengan berkas asli.`:"Tautan resmi belum tersedia. Lengkapi melalui Lihat / edit sebelum aktivasi."}</div>}<div className="kb-source-text">{approval.content}</div><label className="kb-check"><input type="checkbox" checked={ack} onChange={e=>setAck(e.target.checked)} disabled={busy}/><span>Saya telah memeriksa kesesuaian isi dengan sumber, status keberlakuan, dan izin tampilnya. Isi tidak memuat data pribadi atau informasi yang dikecualikan.</span></label><footer className="kb-form-actions"><button className="button secondary" disabled={busy} onClick={()=>setApproval(null)}>Kembali</button><button className="button primary" disabled={busy||!ack||!hasSourceProvenance(approval)||approval.content.trim().length<40} onClick={()=>void changeStatus(approval,'active')}>{busy?'Mengaktifkan…':'Setujui & aktifkan'}</button></footer></div>}</dialog>
  <PdfImporter open={importing} onClose={()=>setImporting(false)} onImported={()=>{setRevision(v=>v+1);void load();}} categories={categories}/>
 </>;
}
