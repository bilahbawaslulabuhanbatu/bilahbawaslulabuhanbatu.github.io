'use client';
import {useState,useEffect} from 'react';
import {getBrowserDatabase} from '@/lib/db/browser';
import {retrievalTerms} from '@/lib/guardrails/classify';
import {RagTrial} from './rag-trial';
type Row={document_id:string;title:string;stage:string;chunks:number;vectors:number;weak:number};
export function IndexMonitor(){
 const [errors,setErrors]=useState<{id:string;filename:string;message:string}[]>([]);
 const [rows,set]=useState<Row[]>([]),[msg,note]=useState(''),[busy,lock]=useState(false),[q,edit]=useState(''),[hits,show]=useState<{title:string;section_reference:string;content:string;chunk_id:string}[]>([]);
 async function load(){const r=await getBrowserDatabase()?.rpc('bilah_index_status');if(!r||r.error)note('Status tidak dapat dimuat.');else set(r.data);const e=await getBrowserDatabase()?.from('bilah_import_errors').select('id,filename,message').order('created_at',{ascending:false}).limit(25);setErrors(e?.data??[]);}
 useEffect(()=>{void load()},[]);
 async function rebuild(id:string){lock(true);try{const r=await getBrowserDatabase()?.rpc('bilah_reindex_document',{target:id});note(r&&!r.error?'Indeks diperbarui dari teks tersimpan.':'Gagal mengindeks ulang. Periksa teks dan hak akses admin.');await load()}finally{lock(false)}}
 async function search(){lock(true);try{const r=await getBrowserDatabase()?.rpc('bilah_rag_search',{search_terms:retrievalTerms(q)});show(r?.data??[]);note(r&&!r.error?(r.data?.length??0)+' potongan ditemukan.':'Pencarian gagal.')}finally{lock(false)}}
 return <section className="panel kb-library"><h2>Status indeks sumber</h2><RagTrial/><details><summary>Kegagalan impor terbaru ({errors.length})</summary>{errors.map(e=><p key={e.id}>{e.filename}: {e.message}</p>)}<p>Jika teks belum pernah tersimpan, pilih kembali PDF di Unggah PDF. Indeks ulang menggunakan teks yang sudah tersimpan.</p></details><p>{rows.length} dokumen · {rows.reduce((n,r)=>n+r.chunks,0)} potongan. Teks sangat pendek dapat berasal dari halaman kosong atau pindai.</p><p role="status">{msg}</p><div className="kb-table-wrap"><table className="kb-table"><thead><tr><th>Dokumen</th><th>Status</th><th>Potongan / vektor</th><th>Teks pendek</th><th>Tindakan</th></tr></thead><tbody>{rows.map(r=><tr key={r.document_id}><td>{r.title}</td><td>{r.stage}</td><td>{r.chunks} / {r.vectors}</td><td>{r.weak}</td><td><button disabled={busy} onClick={()=>void rebuild(r.document_id)}>Indeks ulang</button></td></tr>)}</tbody></table></div><h3>Uji pencarian tanpa menggunakan kuota Gemini</h3><input aria-label="Pertanyaan uji pencarian" maxLength={1200} value={q} onChange={e=>edit(e.target.value)}/><button disabled={busy||!q.trim()} onClick={()=>void search()}>Cari potongan</button>{hits.map(h=><details key={h.chunk_id}><summary>{h.title} · {h.section_reference}</summary><p>{h.content}</p></details>)}</section>
}
