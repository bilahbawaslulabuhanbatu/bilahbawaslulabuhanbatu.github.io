'use client';
export default function ErrorPage({ reset }: { reset: () => void }) { return <main id="main" className="wrap page-space"><h1>Layanan belum dapat ditampilkan</h1><p>Silakan mencoba kembali. Jika masih terjadi, hubungi pengelola BILAH.</p><button className="button primary" onClick={reset}>Coba kembali</button></main>; }
