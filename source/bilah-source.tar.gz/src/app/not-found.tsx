import Link from 'next/link';
export default function NotFound() { return <main id="main" className="wrap page-space"><h1>Halaman tidak ditemukan</h1><Link href="/" className="button primary">Kembali ke beranda</Link></main>; }
