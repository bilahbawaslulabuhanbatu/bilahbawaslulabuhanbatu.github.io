import type { Metadata } from 'next';
import { ChatExperience } from '@/components/public/chat-experience';
export const metadata: Metadata = { title: 'Ruang tanya' };
export default function ChatPage() { return <main id="main"><ChatExperience /></main>; }
