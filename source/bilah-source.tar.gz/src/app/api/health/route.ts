import { NextResponse } from 'next/server';
import { isSupabaseConfigured } from '@/lib/config/server';
export function GET() {
 return NextResponse.json({application:'BILAH',phase:4,status:'account_activation_pending',chatEnabled:false,loginEnabled:isSupabaseConfigured()},{headers:{'Cache-Control':'no-store'}});
}
