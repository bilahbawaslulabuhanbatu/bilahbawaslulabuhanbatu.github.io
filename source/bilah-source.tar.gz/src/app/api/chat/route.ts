import { pendingResponse } from '@/lib/security/pending-response';
export async function POST() { return pendingResponse(); }
