import { NextResponse } from 'next/server';
import { getInternalUser } from '@/lib/auth/server';
import { can } from '@/lib/auth/permissions';
import { createUserDatabaseClient } from '@/lib/db/server';
export const dynamic='force-dynamic';
const headers={'Cache-Control':'private, no-store'};
export async function GET(){
 const user=await getInternalUser();
 if(!user)return NextResponse.json({message:'Autentikasi diperlukan.'},{status:401,headers});
 if(!can(user.role,'dashboard:read'))return NextResponse.json({message:'Akses dibatasi.'},{status:403,headers});
 const db=await createUserDatabaseClient();
 if(!db)return NextResponse.json({message:'Layanan belum dapat dihubungi.'},{status:503,headers});
 const {data,error}=await db.rpc('bilah_service_statistics');
 if(error)return NextResponse.json({message:'Statistik belum dapat dimuat.'},{status:503,headers});
 return NextResponse.json(data,{headers});
}
