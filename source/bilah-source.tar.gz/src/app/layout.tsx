import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: { default: 'BILAH — Bawaslu Labuhanbatu', template: '%s | BILAH' }, description: 'Bot Informasi, Layanan, Aspirasi, dan Hukum — Prototipe Bawaslu Kabupaten Labuhanbatu.', robots: { index: false, follow: false } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body><a className="skip-link" href="#main">Lewati ke konten</a><div className="prototype-bar">PROTOTIPE PKP <span>•</span> Pratinjau BILAH — chat publik masih simulasi; akses petugas menggunakan akun BILAH</div>{children}</body></html>;
}
