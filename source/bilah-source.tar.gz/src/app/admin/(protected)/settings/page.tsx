import { requirePermission } from '@/lib/auth/server';
import { PendingPage } from '@/components/shared/pending-page';
export default async function Page() { await requirePermission('settings:write'); return <PendingPage title="Pengaturan layanan" description="Pengaturan operasional layanan tanpa menampilkan secret." phase={4} />; }
