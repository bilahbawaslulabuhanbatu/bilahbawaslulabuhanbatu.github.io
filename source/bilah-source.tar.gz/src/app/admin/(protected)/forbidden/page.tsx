export default function Forbidden() { return <section className="panel"><h1>Akses dibatasi</h1><p>Akun Anda tidak memiliki kewenangan untuk membuka halaman ini.</p></section>; }
