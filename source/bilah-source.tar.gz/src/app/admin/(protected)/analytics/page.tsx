import { requirePermission } from '@/lib/auth/server';
import { AdminScreen } from '@/components/admin/admin-screen';
export default async function Analytics() { await requirePermission('analytics:read'); return <AdminScreen section="analytics"/>; }
