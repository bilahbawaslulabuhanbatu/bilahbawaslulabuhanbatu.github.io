import { requirePermission } from '@/lib/auth/server';
import { PendingPage } from '@/components/shared/pending-page';
export default async function Page() { await requirePermission('conversations:read'); return <PendingPage title="Log percakapan" description="Pertanyaan dan jawaban beserta sumber akan tersedia di sini." phase={6} />; }
