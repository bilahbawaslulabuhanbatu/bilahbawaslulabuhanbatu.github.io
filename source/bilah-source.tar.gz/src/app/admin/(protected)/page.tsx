import { requireInternalUser } from '@/lib/auth/server';
import { redirect } from 'next/navigation';
import { AdminScreen } from '@/components/admin/admin-screen';
export default async function Dashboard() { const user = await requireInternalUser(); if(user.role==='petugas') redirect('/admin/tickets'); return <AdminScreen/>; }
