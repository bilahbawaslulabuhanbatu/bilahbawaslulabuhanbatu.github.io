import { requirePermission } from '@/lib/auth/server';
import { PendingPage } from '@/components/shared/pending-page';
export default async function Page() { await requirePermission('users:manage'); return <PendingPage title="User/Admin" description="Pengelolaan akun internal oleh superadmin akan tersedia pada fase autentikasi." phase={4} />; }
