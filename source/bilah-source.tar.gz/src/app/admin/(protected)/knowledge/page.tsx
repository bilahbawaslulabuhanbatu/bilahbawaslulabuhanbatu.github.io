import { requirePermission } from '@/lib/auth/server';
import { KnowledgeManager } from '@/components/admin/knowledge-manager';
export default async function Page() { await requirePermission('knowledge:write'); return <KnowledgeManager/>; }
