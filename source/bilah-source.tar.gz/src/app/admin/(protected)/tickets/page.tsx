import { requireInternalUser } from '@/lib/auth/server';
import { can } from '@/lib/auth/permissions';
import { redirect } from 'next/navigation';
import { PendingPage } from '@/components/shared/pending-page';
export default async function Page() { const user = await requireInternalUser(); if (!can(user.role, 'tickets:all') && !can(user.role, 'tickets:assigned')) redirect('/admin/forbidden'); return <PendingPage title="Tiket eskalasi" description="Tiket konsultasi akan tersedia sesuai penugasan dan hak akses." phase={6} />; }
