import { requireInternalUser } from '@/lib/auth/server';
import { InternalAppShell } from '@/components/admin/internal-app-shell';
export const dynamic = 'force-dynamic';
export default async function Layout({children}:{children:React.ReactNode}) { await requireInternalUser(); return <InternalAppShell>{children}</InternalAppShell>; }
