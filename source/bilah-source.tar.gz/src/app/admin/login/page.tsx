import Link from 'next/link';
import { Brand, BawasluIdentity } from '@/components/shared/brand';
import { LoginForm } from '@/components/admin/login-form';
export default function LoginPage() {
 return <main id="main" className="login-page"><section className="login-card"><Brand/><span className="eyebrow">AKSES INTERNAL</span><h1>Selamat datang,<br/>petugas BILAH.</h1><p>Masuk menggunakan akun BILAH untuk mengakses layanan internal sesuai kewenangan.</p><LoginForm/><div className="login-institution"><BawasluIdentity/></div><Link className="text-link" href="/">← Kembali ke beranda</Link></section></main>;
}
