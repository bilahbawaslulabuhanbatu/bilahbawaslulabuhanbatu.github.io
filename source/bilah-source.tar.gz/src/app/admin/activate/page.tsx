import type {Metadata} from 'next';
import {Brand} from '@/components/shared/brand';
import {InviteActivation} from '@/components/admin/invite-activation';
export const metadata:Metadata={title:'Aktivasi undangan',referrer:'no-referrer',robots:{index:false,follow:false}};
export default function ActivationPage(){return <main id="main" className="login-page"><section className="login-card"><Brand/><span className="eyebrow">UNDANGAN AKUN BILAH</span><h1>Siapkan akun<br/>BILAH Anda.</h1><p>Halaman ini hanya dapat digunakan melalui tautan undangan resmi Supabase.</p><InviteActivation/></section></main>;}
