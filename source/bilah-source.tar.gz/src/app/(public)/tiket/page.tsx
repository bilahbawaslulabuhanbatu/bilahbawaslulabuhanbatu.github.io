import {TicketTracker} from '@/components/public/ticket-tracker';
export default function TicketPage(){return <TicketTracker/>;}
