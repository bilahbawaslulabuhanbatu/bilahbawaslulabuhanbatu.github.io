import Link from 'next/link';
import { Brand, BawasluIdentity } from '@/components/shared/brand';
export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return <><header className="site-header wrap"><Brand /><BawasluIdentity /><nav aria-label="Navigasi utama"><Link href="/#cakupan">Cakupan layanan</Link><Link href="/chat">Ruang tanya</Link><Link href="/admin/login" className="staff-link">Akses petugas ↗</Link></nav></header><main id="main">{children}</main><footer className="wrap footer"><Brand /><p>Informasi awal oleh BILAH.<br />Verifikasi dan keputusan oleh petugas berwenang.</p><span>Prototipe Aksi Perubahan PKP · Tahap 4</span></footer></>;
}
