import {voterGuidance} from './voter-guidance.ts';
import type {AnswerRequest,Source} from './contracts.ts';
import {classifyQuestion,retrievalTerms,isPublicInformationQuestion} from '../guardrails/classify.ts';
import {guardrailMessages} from '../guardrails/messages.ts';
import {hasSourceProvenance} from '../knowledge/source-provenance.ts';
import {requiresOfficialSource,type Supplement} from './supplement.ts';
import {relevantExcerpt} from './excerpt.ts';
export type RetrievedChunk={document_id:string;chunk_id:string;title:string;version:number;source_url:string|null;section_reference:string|null;content:string;source_origin?:string;source_filename?:string|null;source_sha256?:string|null};
export type GroundedAnswer={answer:string;sources:Source[];decision:string;canEscalate:boolean;mode:'gemini'|'guardrail';basis?:'knowledge'|'web'|'general';searchSuggestions?:string;trace?:{retrieved:string[];rounds:number;validation?:string};delivery?:'excerpt'};
export interface GroundedProvider {educate?:(q:string)=>Promise<Supplement|null>;refineEmpty?:boolean;generate(input:AnswerRequest):Promise<unknown>;navigate?:(question:string)=>Promise<string|null>;search?:(question:string)=>Promise<Supplement|null>;general?:(question:string)=>Promise<Supplement|null>}
export type PreviewErrorCode='quota'|'configuration'|'provider'|'busy'|'output_limit'|'output_format'|'timeout';
export class PreviewServiceError extends Error {code:PreviewErrorCode;constructor(code:PreviewErrorCode){super(code);this.code=code;}}
function normalize(value:string){return value.replace(/\s+/g,' ').trim().toLocaleLowerCase('id-ID');}
export function validateGroundedOutput(value:unknown,context:AnswerRequest['context']):{answer:string;sources:Source[]}|null {
 if(!value||typeof value!=='object'||!('status' in value)||value.status!=='answered'||!('paragraphs' in value)||!Array.isArray(value.paragraphs)||value.paragraphs.length<1||value.paragraphs.length>3)return null;
 const texts:string[]=[],used=new Map<string,Source>();
 for(const p of value.paragraphs){
  if(!p||typeof p!=='object'||typeof p.text!=='string'||p.text.trim().length<10||p.text.length>1200||!Array.isArray(p.citations)||p.citations.length<1||p.citations.length>3)return null;
  if(/https?:\/\/|\b(?:pasti|terbukti|diputuskan|dinyatakan|jelas)\b.{0,90}\b(?:melanggar|pelanggaran|bersalah)\b|\b(?:pilihlah|dukunglah)\b/i.test(p.text))return null;
  if(['sensitive','injection','political'].includes(classifyQuestion(p.text)))return null;
  const cited:AnswerRequest['context']=[];
  for(const citation of p.citations){
   if(!citation||typeof citation.sourceId!=='string'||typeof citation.quote!=='string'||citation.quote.trim().length<20||citation.quote.length>800)return null;
   const source=context.find(c=>c.source.chunkId===citation.sourceId);
   if(!source||!normalize(source.content).includes(normalize(citation.quote)))return null;
   cited.push(source);used.set(source.source.chunkId,{...source.source,quote:citation.quote.trim()});
  }
  // Reject invented article numbers, years and quantities as well as invented citations.
  const evidence=p.citations.map((r:{quote:string})=>r.quote).concat(cited.map(c=>c.source.title)).join(' ');
  if((p.text.replace(/^\s*\d+[.)]\s+/gm,'').match(/\b\d+\b/g)??[]).some((n:string)=>!new RegExp('\\b'+n+'\\b').test(evidence)))return null;
  texts.push(p.text.trim());
 }
 return {answer:texts.join('\n\n'),sources:[...used.values()]};
}
export async function groundedAnswer(question:string,retrieve:(terms:string[])=>Promise<RetrievedChunk[]>,provider:GroundedProvider):Promise<GroundedAnswer>{
 const decision=classifyQuestion(question);
 const result=(answer:string,canEscalate=false,d:string=decision,sources:Source[]=[],mode:GroundedAnswer['mode']='guardrail'):GroundedAnswer=>({answer,sources,decision:d,canEscalate:canEscalate||decision==='legal',mode});
 if(!question.trim()||question.length>2000)return result('Tulis pertanyaan antara 1 dan 2.000 karakter.',false,'ambiguous');
 if(decision==='sensitive')return result('Jangan masukkan NIK, password, atau data pribadi. Gunakan pertanyaan umum.');
 if(decision==='injection')return result('Silakan ajukan pertanyaan tentang kepemiluan atau layanan Bawaslu. BILAH tetap menggunakan sumber yang telah disetujui.');
 if(decision==='political')return result(guardrailMessages.political);
 if(decision==='out_of_domain')return result(guardrailMessages.outOfDomain);
 if(decision==='human')return result('Anda dapat meminta bantuan petugas melalui tiket konsultasi. Uji internal ini belum mengirim permintaan atau membuat tiket.',true);
 if(decision==='ambiguous')return result(/\bpermohonan\b/i.test(question)?'Permohonan apa yang ingin Anda ajukan?':/\b(syarat|persyaratan)\b/i.test(question)?'Persyaratan untuk layanan atau kegiatan apa yang ingin Anda ketahui?':'Apa topik atau hal yang ingin Anda ketahui?',true);
 // Legal assessment requests may receive sourced general rules, never a verdict.
 const voterAnswer=decision==='information'?voterGuidance(question):null;
 if(voterAnswer)return {...result(voterAnswer.answer,true,decision,voterAnswer.sources),basis:'web'};
 // Official guidance for a general rule, including colloquial descriptions of the actor.
 const cq=normalize(question.split('\n\nPertanyaan sebelumnya:')[0]);
 const child=/\b(anak kecil|anak-anak|anak anak|bocah|balita|anak sd|murid sd|siswa sd|di bawah umur|dibawah umur)\b/;
 const campaign=/\b(kampanye|berkampanye|dikampanyekan)\b/;
 const basicParticipation=/\b(boleh(?:kah)?|bisa(?:kah)?|diizinkan|dilarang|boleh ga|boleh tidak)\b/;
 if(decision==='information'&&child.test(cq)&&campaign.test(cq)&&basicParticipation.test(cq)&&! /\b(pilkada|pemilihan gubernur|pemilihan bupati|pemilihan wali|sanksi|pidana|denda|hukumannya|meliput|pendidikan|simulasi|debat|menonton|nonton|lewat|sekolah boleh|merekam|mencegah|melarang)\b/.test(cq)){
  return {...result('Tidak. Dalam kampanye Pemilu, pelaksana atau tim kampanye tidak boleh melibatkan anak kecil yang belum memiliki hak pilih. Misalnya, anak tidak boleh diajak membagikan bahan kampanye atau menyerukan dukungan kepada calon. Larangan ini ditujukan kepada pihak yang melibatkan anak.\n\nDasarnya Pasal 280 ayat (2) huruf k UU Nomor 7 Tahun 2017. Jika Anda melihat anak di lokasi kampanye, bedakan antara sekadar berada di sana dan diminta melakukan kegiatan kampanye. Jika ingin berkonsultasi, ceritakan kegiatannya tanpa mengirim nama atau foto anak.',true,decision,[{documentId:'bawaslu-perlindungan-anak',chunkId:'bawaslu-perlindungan-anak',title:'Bawaslu Kabupaten Kuningan · Pelibatan anak dalam kampanye Pemilu',section:'Pasal 280 ayat (2) huruf k UU Pemilu',url:'https://kuningankab.bawaslu.go.id/berita/pelibatan-anak-dalam-kampanye-pemilu-perspektif-hukum-dan-perlindungan-hak-anak',version:0}]),basis:'web'};
 }
 let generalAttempted=false;
 if(decision==='information' && provider.general && !requiresOfficialSource(question)){
  generalAttempted=true;
  const direct=await provider.general(question);
  if(direct)return {...result(direct.answer,false,decision,[],'gemini'),basis:'general'};
  // If general generation declines, try active documents before handing off.
 }
 const assumedDispute=/\bsengketa\b/i.test(question)&&!/\b(pemilu|pemilihan|pilkada)\b/i.test(question)&&!isPublicInformationQuestion(question);
 const prefix=decision==='legal'?guardrailMessages.legalAssessment+'\n\n':decision==='report'?'BILAH membantu informasi awal. Tiket konsultasi bukan tanda penerimaan laporan pelanggaran secara resmi.\n\n':assumedDispute?'Saya memahami pertanyaan ini dalam konteks sengketa proses Pemilu di Bawaslu. Jika yang dimaksud sengketa Pemilihan (Pilkada), silakan beri tahu saya.\n\n':'';
 const supplement=async():Promise<GroundedAnswer>=>{
  const web=await provider.search?.(question);
  if(web)return {...result(prefix+web.answer,decision==='report',decision,web.sources,'gemini'),basis:'web',searchSuggestions:web.searchSuggestions};
  const general=decision==='information'&&!generalAttempted&&!requiresOfficialSource(question)?await provider.general?.(question):null;
  if(general)return {...result(general.answer,false,decision,[],'gemini'),basis:'general'};
  const route=await provider.navigate?.(question);
  if(route)return result(prefix+route,true,'no_source');
  return result(isPublicInformationQuestion(question)?'Pertanyaan Anda termasuk layanan PPID. Saya belum menemukan rujukan yang cukup untuk menjelaskan prosedur permohonan informasi publik dengan pasti. Silakan menghubungi petugas PPID untuk panduan resmi.':prefix+'Saya belum menemukan sumber yang cukup untuk menjawab pertanyaan ini dengan pasti. Petugas dapat membantu memastikan informasi yang Anda butuhkan.',true,'no_source');
 };
 const qualified=(batch:RetrievedChunk[])=>batch.filter(r=>typeof r.content==='string'&&r.content.length<=12000&&typeof r.title==='string'&&typeof r.chunk_id==='string'&&hasSourceProvenance(r)&&!['injection','sensitive'].includes(classifyQuestion(r.content)))
  .filter(r=>!/\b(pilkada|pemilihan)\b/i.test(question)||/\bpemilihan umum\b/i.test(question)||/\b(pilkada|pemilihan|gubernur|bupati|walikota|wali kota)\b/i.test((r.title+' '+r.content).replace(/pemilihan\s+umum/gi,''))).slice(0,5);
 const rows=qualified(await retrieve(retrievalTerms(question)));
 if(!rows.length&&(!provider.refineEmpty||provider.search))return supplement();
 const context=rows.map(r=>({content:r.content,source:{documentId:r.document_id,chunkId:r.chunk_id,title:r.title,version:r.version,section:r.section_reference??undefined,url:r.source_url??undefined,filename:r.source_filename??undefined,sha256:r.source_sha256??undefined}}));
 // For simple ASN permission questions, answer directly only from both operative passages.
 if (/^(?:(?:apakah|bolehkah) )?(?:asn|aparatur sipil negara|pns) (?:boleh(?:kah)? |bisa |diperbolehkan )?(?:ikut |menjadi )?(?:berkampanye|kampanye|tim kampanye)(?: (?:di |dalam )?pemilu)?[?.! ]*$/i.test(normalize(question))) {
  const law=context.filter(c=>/(uu|undang).{0,20}7.{0,20}2017/i.test(c.source.title));
  const roles=law.find(c=>/f\. aparatur sipil negara/.test(normalize(c.content)) && /dilarang ikut serta sebagai pelaksana dan tim kampanye pemilu/.test(normalize(c.content)));
  const neutrality=law.find(c=>/pasal 283 .*aparatur sipil negara lainnya dilarang mengadakan kegiatan yang mengarah kepada keberpihakan/.test(normalize(c.content)));
  if(roles && neutrality && roles.source.documentId===neutrality.source.documentId) return {...result('Tidak. Dalam Pemilu, ASN tidak boleh menjadi pelaksana atau anggota tim kampanye. Pelaksana dan tim kampanye juga tidak boleh mengikutsertakan ASN dalam kegiatan kampanye (UU Nomor 7 Tahun 2017, Pasal 280 ayat (2) huruf f dan ayat (3)).\n\nPasal 283 juga melarang ASN mengadakan kegiatan yang menunjukkan keberpihakan kepada peserta Pemilu, baik sebelum, selama, maupun sesudah masa kampanye. Contohnya, mengajak rekan kerja mendukung peserta tertentu.\n\nApakah Anda melihat kegiatan seperti ini dan ingin berkonsultasi tentang cara melaporkannya? Pilih “Butuh bantuan petugas”.',true,decision,[roles.source,neutrality.source]),basis:'knowledge'};
 }
 // Explain this recurring conditional question only when both the rule and exception are present in approved sources.
 // Do not derive an automatic offence or penalty from the leave requirement.
 if (/\b(kepala daerah|gubernur|bupati|wali ?kota)\b/i.test(question) && /\b(berkampanye|kampanye)\b/i.test(question)
  && /\b(tanpa|tidak|belum)\b.{0,30}\bcuti\b/i.test(question) && !/\b(pilkada|pemilihan)\b/i.test(question)) {
  const law=context.filter(c=>/(uu|undang).{0,20}7.{0,20}2017/i.test(c.source.title));
  const rule=law.find(c=>/pasal 281/.test(normalize(c.content)) && /menjalani cuti di luar tanggungan negara/.test(normalize(c.content)));
  const exception=law.find(c=>/cuti bagi gubernur/.test(normalize(c.content)) && /hari libur adalah hari bebas untuk melakukan kampanye di luar ketentuan cuti/.test(normalize(c.content)));
  if(rule && exception) return {...result('Dalam konteks kampanye Pemilu, jika kepala daerah berkampanye pada hari kerja tanpa menjalani cuti yang dipersyaratkan, syarat cuti tersebut belum terpenuhi. Ini merupakan penjelasan berdasarkan ketentuan cuti dalam UU Pemilu, bukan keputusan bahwa seseorang telah melakukan pelanggaran.\n\nNamun, UU juga membedakan hari kerja dan hari libur: hari libur merupakan hari bebas berkampanye di luar ketentuan cuti tersebut. Karena itu, tidak adanya izin cuti saja belum cukup untuk menyimpulkan pelanggaran. Petugas perlu memeriksa waktu kegiatan, status cuti, dan fakta terkait sebelum menentukan tindak lanjut.\n\nApakah Anda melihat kepala daerah berkampanye dan ingin berkonsultasi atau melaporkan dugaan pelanggaran? Pilih Butuh bantuan petugas untuk membuat tiket konsultasi; tiket ini bukan tanda penerimaan laporan resmi.',true,decision,[rule.source,exception.source]),basis:'knowledge'};
 }
 // Use the complete approved list for this FAQ when its source can be parsed.
 if (/^(?:(?:apa saja|apa aja)(?: nama)? divisi(?:nya)?(?: (?:di|pada))?|divisi(?:nya)? (?:di|pada)) bawaslu(?: kabupaten)? labuhanbatu(?: apa (?:saja|aja))?[?!.\s]*$/i.test(normalize(question))) {
  for (const {content,source} of context) {
   if (!/^Peraturan Bawaslu Nomor 3 Tahun 2022$/i.test(source.title)) continue;
   const article=content.replace(/\s+/g,' ').match(/\bPasal 37\s+\(1\).*?\bb\.\s+Bawaslu Kabupaten\s*\/\s*Kota yang memiliki jumlah anggota sebanyak 5\s*\(\s*lima\s*\) orang terdiri atas\s*:\s*(.+?)\s*\(2\)/i)?.[1];
   const items=article?.match(/^1\.\s*d\s*ivisi (.+?)\s*;\s*2\.\s*d\s*ivisi (.+?)\s*;\s*3\.\s*d\s*ivisi (.+?)\s*;\s*(?:dan\s+)?4\.\s*d\s*ivisi (.+?)\s*\.$/i)?.slice(1);
   if (!items || items.some(x=>x.length>140||!/^[a-z ,]+$/i.test(x))) continue;
   const list=items.map((x,i)=>(i+1)+'. '+x[0].toUpperCase()+x.slice(1)+'.').join('\n');
   return {...result('Untuk Bawaslu kabupaten/kota dengan lima anggota, Pasal 37 ayat (1) huruf b Perbawaslu Nomor 3 Tahun 2022 membagi tugas ke empat divisi:\n\n'+list,false,decision,[source]),basis:'knowledge'};
  }
 }
 let output:unknown;
 try{output=await provider.generate({question,context});}
 catch(error){
  // Availability failures must not discard already retrieved approved text.
  // Do not present excerpts as a generated/legal answer or claim their relevance is verified.
  if(!(error instanceof PreviewServiceError)||!['timeout','busy','provider','output_limit','output_format'].includes(error.code))throw error;
  if(!context.length)return supplement();
  const selected=context.slice(0,2);
  const excerpts=selected.map((c,i)=>{
   const excerpt=relevantExcerpt(c.content,question);
   return '['+(i+1)+'] '+c.source.title+' — '+(c.source.section||'Potongan dokumen')+'\n\n'+excerpt;
  }).join('\n\n');
  return {...result(prefix+'AI sedang lambat. Berikut bagian singkat dari dokumen yang ditemukan. Ini masih cuplikan sumber, belum merupakan jawaban AI. Petugas dapat membantu memastikan penerapannya.\n\n'+excerpts,true,decision,selected.map(c=>c.source)),basis:'knowledge',delivery:'excerpt'};
 }
 // Search hints are never evidence. Retrieve again only on insufficient evidence and
 // only allow a second generation if it can see a new, approved document passage.
 if(output&&typeof output==='object'&&'status' in output&&output.status==='insufficient'&&'searchTerms' in output&&Array.isArray(output.searchTerms)){
  const terms=[...new Set<string>(output.searchTerms.filter((t:unknown):t is string=>typeof t==='string'&&/^[a-z0-9]{2,36}$/i.test(t)).map((t:string)=>t.toLowerCase()))].slice(0,6);
  if(terms.length){
   const fresh=qualified(await retrieve(terms)).filter(r=>!context.some(c=>c.source.chunkId===r.chunk_id));
   if(fresh.length){
    const extra=fresh.map(r=>({content:r.content,source:{documentId:r.document_id,chunkId:r.chunk_id,title:r.title,version:r.version,section:r.section_reference??undefined,url:r.source_url??undefined,filename:r.source_filename??undefined,sha256:r.source_sha256??undefined}}));
    context.splice(0,context.length,...[...extra,...context].slice(0,5));
    try{output=await provider.generate({question,context});}catch(err){if(!(err instanceof PreviewServiceError))throw err;return supplement();}
   }
  }
 }
 const validated=validateGroundedOutput(output,context);
 if(!validated)return supplement();
 const campaignFollowup=/\b(kepala daerah|gubernur|bupati|wali ?kota)\b/i.test(question)&&/\b(berkampanye|kampanye)\b/i.test(question)&&/\b(tanpa|tidak|belum)\b.{0,30}\bcuti\b/i.test(question);
 const followup=campaignFollowup?'\n\nApakah Anda melihat kepala daerah berkampanye dan ingin berkonsultasi atau melaporkan dugaan pelanggaran? Anda dapat memilih Butuh bantuan petugas. Tiket konsultasi bukan penerimaan laporan resmi.':'';
 return {...result(prefix+validated.answer+followup,decision==='report'||campaignFollowup,decision,validated.sources,'gemini'),basis:'knowledge'};
}
