import {classifyQuestion,normalizeQuestion} from '../guardrails/classify.ts';
import {isOfficialSource} from '../knowledge/source-provenance.ts';
import type {Source} from './contracts.ts';

export type Supplement={answer:string;sources:Source[];basis:'web'|'general';searchSuggestions?:string};
export function requiresOfficialSource(question:string):boolean {
 const q=normalizeQuestion(question);
 if(/\b(bolehkah|bolehkan|diperbolehkan|diizinkan|dibolehkan|larangan|terlarang)\b/.test(q))return true;
 if(/\b(apakah|kalau|jika)\b/.test(q)&&/\b(politik uang|sembako|calon|memfoto)\b/.test(q))return true;
 // Service eligibility, legal consequences, live institutional facts and personal cases
 // require evidence even when the citizen does not use formal legal vocabulary.
 if(/\b(berhak|hak pilih|ikut memilih|bisa memilih|boleh memilih|harus dibawa|mencoblos|ktp|tps|kpps|terlambat|pindah|luar kota|meninggal|dilaporkan|dihukum|ditindak|melanggar|pelanggaran|ancam|mengancam|dirahasiakan|anonim|biaya|berapa lama|ditindaklanjuti|mengajukan|membatalkan|menangkap|anggaran|diskualifikasi|didiskualifikasi|menggugat|perselisihan|sengketa|konsekuensi|hukumnya|berwenang|menyediakan|menerima|magang|kerja sama|ijazah palsu|tim sukses)\b/.test(q))return true;
 // Decide by the information needed, not the question word alone.
 if(/\b(tugas|fungsi|kewenangan|wewenang|tanggung jawab)\b/.test(q))return true;
 const specific=/\d|\b(pasal|peraturan|undang|perbawaslu|pkpu|sanksi|pidana|tenggat|batas waktu|jadwal|tanggal|kapan|alamat|telepon|kontak|email|ketua|komisioner|divisi|struktur|visi|misi|profil|terbaru|terkini|saat ini|sekarang|labuhanbatu|syarat|izin|permohonan|pengajuan|lapor|melapor|melaporkan|pelaporan|laporan|pendaftaran|terdaftar|dpt|pindah memilih|wajib|boleh|dilarang)\b/.test(q);
 const educational=/\b(apa itu|pengertian|makna|mengapa|kenapa|penting|manfaat|tujuan|tips|belajar|edukasi|memahami|mengenalkan|menjelaskan|membedakan|menghindari|menyikapi|menghadapi|berdiskusi|menjaga|mengecek|memeriksa)\b/.test(q);
 if(specific)return true;
 if(educational)return false;
 return /\d|\b(cara|bagaimana|prosedur|permohonan|pengajuan|lapor|melapor|melaporkan|pelaporan|syarat|tenggat|batas|hari|pasal|aturan|peraturan|undang|perbawaslu|pkpu|alamat|kontak|telepon|email|siapa|kapan|terbaru|sekarang|saat ini|divisi|struktur|anggota|ketua|jadwal|sanksi|pidana|hukum|wajib|boleh|dilarang)\b/i.test(normalizeQuestion(question));
}
export function safeSupplementText(text:string):boolean {
 return text.length>=20&&text.length<=3500&&!['injection','sensitive','political'].includes(classifyQuestion(text))&&!/\b(pasti|terbukti|diputuskan|dinyatakan|jelas)\b.{0,90}\b(melanggar|pelanggaran|bersalah)\b|\b(pilihlah|dukunglah)\b/i.test(text);
}
export function validateGeneral(value:unknown,question:string):Supplement|null {
 if(requiresOfficialSource(question)||!value||typeof value!=='object'||!('status' in value)||value.status!=='general'||!('answer' in value)||typeof value.answer!=='string')return null;
 const text=value.answer.trim();
 const factualText=text.replace(/^\s*\d+[.)]\s+/gm,'');
 // General mode is conceptual education only. No fabricated links, numbers or authority claims.
 if(!safeSupplementText(text)||/https?:|www\.|\d|\b(pasal|perbawaslu|undang-undang|wajib|dilarang|sanksi|pidana|hari|jam|terbaru|terkini|berdasarkan dokumen|hasil pencarian|saya telah mencari)\b/i.test(factualText))return null;
 return {answer:text,sources:[],basis:'general'};
}
export async function officialSearchURL(value:string,fetcher:typeof fetch):Promise<string|null>{
 if(isOfficialSource(value))return value;
 let url:URL;try{url=new URL(value);}catch{return null;}
 // Only resolve the specific Google grounding redirect service. Never fetch arbitrary model URLs.
 if(url.protocol!=='https:'||url.hostname!=='vertexaisearch.cloud.google.com'||url.port||url.username||url.password||!url.pathname.startsWith('/grounding-api-redirect/'))return null;
 try{
  const response=await fetcher(url.href,{redirect:'manual',signal:AbortSignal.timeout(5000)});
  await response.body?.cancel();
  const target=response.headers.get('location');
  if(![301,302,303,307,308].includes(response.status)||!target)return null;
  const resolved=new URL(target,url).href;
  return isOfficialSource(resolved)?resolved:null;
 }catch{return null;}
}
export async function validateSearch(candidate:unknown,fetcher:typeof fetch):Promise<Supplement|null>{
 const c=candidate as {finishReason?:string;content?:{parts?:{text?:string;thought?:boolean}[]};groundingMetadata?:{groundingChunks?:{web?:{uri?:string;title?:string}}[];groundingSupports?:{segment?:{text?:string};groundingChunkIndices?:number[]}[];searchEntryPoint?:{renderedContent?:string}}};
 if(c?.finishReason!=='STOP')return null;
 const full=(c.content?.parts??[]).filter(p=>!p.thought&&typeof p.text==='string').map(p=>p.text).join('');
 const meta=c.groundingMetadata,chunks=meta?.groundingChunks,supports=meta?.groundingSupports;
 if(full.length>16000||!chunks?.length||chunks.length>12||!supports?.length||supports.length>40)return null;
 const urls=await Promise.all(chunks.map(chunk=>typeof chunk.web?.uri==='string'?officialSearchURL(chunk.web.uri,fetcher):null));
 const accepted:string[]=[],sources=new Map<number,Source>();
 for(const support of supports){
  const text=support.segment?.text?.trim(),indices=support.groundingChunkIndices;
  if(!text||!safeSupplementText(text)||!full.includes(text)||/https?:\/\/|www\./i.test(text)||!Array.isArray(indices)||!indices.length||indices.length>8||indices.some(i=>!Number.isInteger(i)||!urls[i]))continue;
  if(accepted.includes(text))continue;
  accepted.push(text);
  for(const i of indices)sources.set(i,{documentId:'web-'+i,chunkId:'web-'+i,title:chunks[i].web?.title?.slice(0,250)||'Sumber resmi',version:0,url:urls[i]!,section:'Penelusuran web · '+new Date().toISOString().slice(0,10)});
  if(accepted.length===3)break;
 }
 if(!accepted.length||!sources.size)return null;
 const suggestions=meta?.searchEntryPoint?.renderedContent;
 // Google search suggestions must accompany grounded results; render only inside a sandboxed frame.
 if(typeof suggestions!=='string'||!suggestions.trim()||suggestions.length>40000)return null;
 return {answer:accepted.join('\n\n'),sources:[...sources.values()],basis:'web',searchSuggestions:suggestions};
}
