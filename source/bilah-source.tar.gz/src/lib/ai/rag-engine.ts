// The production path: retrieve before generation, even for a familiar question.
import {serviceGuide} from '../knowledge/service-directory.ts';
import {classifyQuestion,retrievalTerms} from '../guardrails/classify.ts';
import {guardrailMessages as messages} from '../guardrails/messages.ts';
import {requiresOfficialSource} from './supplement.ts';
import {hasSourceProvenance} from '../knowledge/source-provenance.ts';
import {validateGroundedOutput,PreviewServiceError,type GroundedAnswer,type RetrievedChunk,type GroundedProvider} from './grounded.ts';
export async function answerFromIndex(question:string,retrieve:(terms:string[])=>Promise<RetrievedChunk[]>,provider:GroundedProvider):Promise<GroundedAnswer>{
 const decision=classifyQuestion(question),base=(answer:string,d:string=decision,help=false):GroundedAnswer=>({answer,decision:d,sources:[],canEscalate:help,mode:'guardrail'});
 if(!question.trim()||question.length>2000)return base('Tulis pertanyaan antara 1 dan 2.000 karakter.','ambiguous');
 if(decision==='political')return base(messages.political);
 if(decision==='out_of_domain')return base(messages.outOfDomain);
 if(decision==='sensitive'||decision==='injection')return base('Ajukan pertanyaan kepemiluan tanpa menyertakan data pribadi.');
 if(decision==='human')return base('Anda dapat meminta konsultasi kepada petugas.',decision,true);
 if(decision==='ambiguous')return base('Apa yang ingin Anda ketahui tentang Pemilu atau layanan Bawaslu?');
 const pack=(rows:RetrievedChunk[])=>rows.filter(r=>r.content?.length>=20&&r.content.length<=12000&&hasSourceProvenance(r)&&!['sensitive','injection'].includes(classifyQuestion(r.content))).slice(0,14).map(r=>({content:r.content,source:{documentId:r.document_id,chunkId:r.chunk_id,title:r.title,version:r.version,section:r.section_reference??undefined,url:r.source_url??undefined,filename:r.source_filename??undefined,sha256:r.source_sha256??undefined}}));
 const terms=retrievalTerms(question); let context=pack(await retrieve(terms));
 // A request for the provision behind a previous answer should search the original
 // topic as well. Do not reuse a prior model answer as statutory evidence.
 const [latest,history]=question.split('\n\nPertanyaan sebelumnya: ');
 if(history&&/\b(pasal|dasar hukum|aturannya|rujukannya|sumbernya)\b/i.test(latest)){
  const anchor=pack(await retrieve(retrievalTerms(history.split(' → ')[0]))).slice(0,4);
  context=[...anchor,...context.filter(c=>!anchor.some(a=>a.source.chunkId===c.source.chunkId))].slice(0,14);
 }
 const guide=decision==='information'?serviceGuide(question):null;
 if(guide)context=[{content:guide.content,source:guide.source} as typeof context[number],...context].slice(0,14);
 const navigation=()=>({...base(guide!.content+' Jangan kirim NIK atau kode OTP ke chat BILAH.','information'),basis:'web' as const,sources:[guide!.entry,guide!.source],trace});
 const trace:{retrieved:string[];rounds:number;validation?:string}={retrieved:context.map(x=>x.source.chunkId),rounds:1};
 for(let i=0;i<2;i++){
  if(!context.length&&(i===1||provider.search))break;
  let raw:unknown;
  try{raw=await provider.generate({question,context});}
  catch(e){if(!(e instanceof PreviewServiceError))throw e;
   if(guide)return navigation();
   if(context.length&&['busy','timeout','output_limit','provider'].includes(e.code))return {...base('AI belum dapat merangkum dokumen. Berikut rujukan yang ditemukan; kesesuaiannya perlu diperiksa.\n\n'+context[0].content.slice(0,550), 'unavailable',true),sources:context.slice(0,2).map(x=>x.source),basis:'knowledge',delivery:'excerpt',trace};
   throw e;
  }
  const answer=validateGroundedOutput(raw,context);
  trace.validation=answer?'citations_verified':raw&&typeof raw==='object'&&'status' in raw&&raw.status==='insufficient'?'model_insufficient':'citation_rejected';
  if(guide && (!answer||!answer.sources.some(s=>s.chunkId===guide.source.chunkId)))return navigation();
  if(answer&&guide)return {...base(answer.answer+' Jangan kirim NIK atau kode OTP ke chat BILAH.','information'),sources:[guide.entry,...answer.sources],basis:'web',mode:'gemini',trace};
  if(answer){const prefix=decision==='legal'?messages.legalAssessment+'\n\n':decision==='report'?'Ini panduan awal, bukan penerimaan laporan resmi.\n\n':'';
   return {...base(prefix+answer.answer,decision,['report','legal'].includes(decision)),sources:answer.sources,basis:'knowledge',mode:'gemini',trace};
  }
  // An invalid citation is not evidence that the database lacks an answer.
  // Retry once with fewer passages. Keep the same evidence checks on the retry.
  if(i===0&&trace.validation==='citation_rejected'&&context.length>1){
   context=context.slice(0,4);trace.rounds++;continue;
  }
  if(i===1||!raw||typeof raw!=='object'||!('searchTerms' in raw)||!Array.isArray(raw.searchTerms))break;
  const hints=raw.searchTerms.filter((t:unknown):t is string=>typeof t==='string'&&/^[a-z0-9]{2,36}$/i.test(t)).slice(0,8);
  if(!hints.length)break;
  const fresh=pack(await retrieve(hints));if(!fresh.some(x=>!context.some(c=>c.source.chunkId===x.source.chunkId)))break;
  context=[...fresh,...context.filter(c=>!fresh.some(x=>x.source.chunkId===c.source.chunkId))].slice(0,14);trace.rounds++;trace.retrieved=[...new Set([...trace.retrieved,...context.map(c=>c.source.chunkId)])];
 }
 const web=await provider.search?.(question);
 if(web)return {...base(web.answer,decision,true),mode:'gemini',basis:'web',sources:web.sources,searchSuggestions:web.searchSuggestions,trace};
 if(trace.validation==='citation_rejected'&&context.length){return {...base('Saya menemukan dokumen terkait, tetapi belum dapat memverifikasi kutipan untuk jawaban ini. Anda dapat memeriksa sumber berikut atau berkonsultasi dengan petugas.','citation_unverified',true),sources:context.slice(0,2).map(c=>c.source),trace};}
 if(decision==='information'){
  let general=null;try{general=requiresOfficialSource(question)?await provider.educate?.(question):await provider.general?.(question);}catch(e){if(!(e instanceof PreviewServiceError))throw e;}if(general)return {...base(general.answer,decision,true),mode:'gemini',basis:'general',trace};
 }
 const nav=await provider.navigate?.(question);
 return {...base(nav??'Saya belum dapat memastikan ketentuan khususnya dari rujukan yang ditemukan. Jika ini kejadian nyata, ceritakan kegiatan dan jenis pemilihannya tanpa menyebut identitas pribadi, atau konsultasikan kepada petugas.', 'no_source',true),trace};
}
