export type Source = { documentId: string; chunkId: string; title: string; version: number; section?: string; url?: string; filename?:string; sha256?:string;quote?:string };
export type AnswerRequest = { question: string; context: { content: string; source: Source }[] };
export type AnswerResult = { answer: string; sourceIds: string[]; needsEscalation: boolean; reason?: string };
export interface AIProvider { generateAnswer(input: AnswerRequest): Promise<AnswerResult> }
// Internal preview uses an extractive mock. External adapters remain server-only future work.
