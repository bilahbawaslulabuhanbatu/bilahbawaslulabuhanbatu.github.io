'use client';
import {getBrowserDatabase} from '../db/browser';
import type {GroundedAnswer} from './grounded';
export type AIStatus={configured:boolean;provider:string;model:string;scope:string;limitPerMinute:number;limitPerDay:number;supplementMode?:string;searchEnabled?:boolean};
const errors:Record<string,string>={AI_BUSY:'Layanan model Gemini sedang tidak tersedia. Tunggu beberapa saat sebelum mencoba lagi.',AI_OUTPUT_LIMIT:'Jawaban Gemini terpotong sebelum selesai. Coba pertanyaan yang lebih singkat.',AI_OUTPUT_FORMAT:'Jawaban Gemini belum dapat diperiksa format dan sumbernya. Silakan coba kembali.',AI_TIMEOUT:'Gemini membutuhkan waktu terlalu lama. Silakan coba kembali nanti.',AI_PROVIDER_ERROR:'Gemini belum berhasil memproses jawaban. Silakan coba kembali nanti.',UNAVAILABLE:'Server BILAH belum dapat menyelesaikan permintaan. Silakan coba kembali nanti.',NOT_CONFIGURED:'Kunci AI belum disimpan di Secrets Supabase.',AI_CONFIGURATION:'Kunci atau model belum dapat digunakan. Periksa kunci dan status Free Tier di Google AI Studio.',QUOTA:'Batas percobaan atau kuota gratis tercapai. Tunggu sebentar dan coba lagi nanti.',UNAUTHORIZED:'Sesi berakhir. Silakan masuk kembali ke BILAH.',FORBIDDEN:'Uji AI hanya tersedia untuk admin aktif.',INVALID_INPUT:'Tulis pertanyaan antara 1 dan 2.000 karakter.'};
async function call(method:'GET'|'POST',question?:string){
 const db=getBrowserDatabase();if(!db)throw new Error('Koneksi BILAH belum tersedia.');
 const {data:session}=await db.auth.getSession();
 if(!session.session)throw new Error(errors.UNAUTHORIZED);
 const {data,error}=await db.functions.invoke('bilah-ai-preview',{method,timeout:100000,headers:{Authorization:'Bearer '+session.session.access_token},...(method==='POST'?{body:{question}}:{})});
 if(error){
  let code='';try{const body=await error.context?.json();code=body?.code??'';}catch{}
  throw new Error(errors[code]??'Sambungan AI belum dapat dihubungi. Coba kembali nanti.');
 }
 return data;
}
export async function getAIStatus():Promise<AIStatus>{
 const data=await call('GET');if(typeof data?.configured!=='boolean')throw new Error('Status AI belum dapat diperiksa.');return data;
}
export async function askAI(question:string):Promise<GroundedAnswer>{
 const data=await call('POST',question);
 if(typeof data?.answer!=='string'||!Array.isArray(data.sources)||!['gemini','guardrail'].includes(data.mode))throw new Error('Jawaban AI belum dapat diperiksa.');return data;
}
