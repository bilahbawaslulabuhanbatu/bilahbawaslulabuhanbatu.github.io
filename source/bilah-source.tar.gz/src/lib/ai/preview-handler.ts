import {answerFromIndex} from '../ai/rag-engine.ts';
import {PreviewServiceError,type RetrievedChunk} from './grounded.ts';
import {GeminiProvider} from './gemini-provider.ts';
import {SupplementProvider} from './supplement-provider.ts';
type Environment={get:(key:string)=>string|undefined};
const defaultOrigin='https://bilah-labuhanbatu-ray.rangkutiray3.chatgpt.site';
export function createPreviewHandler(env:Environment,fetcher:typeof fetch=fetch,diagnostic:(event:Record<string,string|number>)=>void=()=>{}){
 return async(req:Request):Promise<Response>=>{
  const allowedOrigin=env.get('ALLOWED_ORIGIN')||defaultOrigin,origin=req.headers.get('origin');
  const permitted=new Set([allowedOrigin,'https://rangkutiray3.github.io']);
  const responseOrigin=origin&&permitted.has(origin)?origin:allowedOrigin;
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':responseOrigin,'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Vary':'Origin','X-Content-Type-Options':'nosniff'};
  const response=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
  if(origin&&!permitted.has(origin))return response({code:'FORBIDDEN',message:'Akses dibatasi.'},403);
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(!['GET','POST'].includes(req.method))return response({code:'METHOD_NOT_ALLOWED',message:'Permintaan tidak didukung.'},405);
  const authorization=req.headers.get('authorization')??'';
  if(!/^Bearer \S+$/.test(authorization)||authorization.length>8192)return response({code:'UNAUTHORIZED',message:'Silakan masuk kembali ke BILAH.'},401);
  const url=env.get('SUPABASE_URL');let publicKey=env.get('SUPABASE_ANON_KEY');
  try{publicKey=JSON.parse(env.get('SUPABASE_PUBLISHABLE_KEYS')||'{}').default||publicKey;}catch{}
  if(!url||!publicKey)return response({code:'UNAVAILABLE',message:'Sambungan layanan belum siap.'},503);
  const dbHeaders={apikey:publicKey,Authorization:authorization,'Content-Type':'application/json'};
  try{
   const identity=await fetcher(url+'/auth/v1/user',{headers:dbHeaders,signal:AbortSignal.timeout(8000)});
   if(!identity.ok)return response({code:'UNAUTHORIZED',message:'Silakan masuk kembali ke BILAH.'},401);
   const user=await identity.json();
   if(typeof user.id!=='string'||!/^[a-f0-9-]{36}$/i.test(user.id))return response({code:'UNAUTHORIZED',message:'Sesi tidak valid.'},401);
   const profileResponse=await fetcher(url+'/rest/v1/users?id=eq.'+encodeURIComponent(user.id)+'&select=is_active,roles(name)',{headers:dbHeaders,signal:AbortSignal.timeout(8000)});
   if(!profileResponse.ok)return response({code:'FORBIDDEN',message:'Akses uji AI hanya untuk admin aktif.'},403);
   const profiles=await profileResponse.json(),profile=Array.isArray(profiles)?profiles[0]:null;
   const role=Array.isArray(profile?.roles)?profile.roles[0]?.name:profile?.roles?.name;
   if(profile?.is_active!==true||!['admin','superadmin'].includes(role))return response({code:'FORBIDDEN',message:'Akses uji AI hanya untuk admin aktif.'},403);
   const key=(env.get('AI_API_KEY')??env.get('GEMINI_API_KEY')??'').trim(),model=(env.get('AI_MODEL')||'gemini-3.5-flash-lite').trim(),provider=env.get('AI_PROVIDER')||'gemini',supplementMode=env.get('AI_SUPPLEMENT_MODE')||'general';
   if(req.method==='GET')return response({configured:!!key&&provider==='gemini',provider,model,scope:'admin_preview',supplementMode,searchEnabled:supplementMode==='web',limitPerMinute:3,limitPerDay:50});
   if(!key||provider!=='gemini')return response({code:'NOT_CONFIGURED',message:'Kunci AI belum tersimpan. Admin utama perlu menyimpannya di Secrets Supabase.'},503);
   if(!req.headers.get('content-type')?.includes('application/json'))return response({code:'INVALID_INPUT',message:'Format pertanyaan tidak valid.'},400);
   const reader=req.body?.getReader();if(!reader)return response({code:'INVALID_INPUT',message:'Tulis pertanyaan terlebih dahulu.'},400);
   const chunks:Uint8Array[]=[];let size=0;
   while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>8192){await reader.cancel();return response({code:'INVALID_INPUT',message:'Pertanyaan terlalu panjang.'},413);}chunks.push(part.value);}
   let data:unknown;try{const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}data=JSON.parse(new TextDecoder().decode(bytes));}catch{return response({code:'INVALID_INPUT',message:'Format pertanyaan tidak valid.'},400);}
   const question=data&&typeof data==='object'&&'question' in data?data.question:null;
   if(typeof question!=='string'||!question.trim()||question.length>2000)return response({code:'INVALID_INPUT',message:'Tulis pertanyaan antara 1 dan 2.000 karakter.'},400);
   const rpc=async(name:string,body:unknown)=>{
    const result=await fetcher(url+'/rest/v1/rpc/'+name,{method:'POST',headers:dbHeaders,body:JSON.stringify(body),signal:AbortSignal.timeout(10000)});
    if(!result.ok){diagnostic({event:'rpc_failed',rpc:name,status:result.status});throw new PreviewServiceError('provider');}return result.json();
   };
   const deadline=Date.now()+35000;
   const remaining=()=>deadline-Date.now();
   const supplement=new SupplementProvider(key,fetcher,diagnostic,model);
   const reserve=async()=>{if(await rpc('bilah_reserve_ai_preview_call',{})!==true)throw new PreviewServiceError('quota');};
   const answer=await answerFromIndex(question.trim(),async terms=>{
    const rows=await rpc('bilah_rag_search',{search_terms:terms});if(!Array.isArray(rows))throw new Error();return rows as RetrievedChunk[];
   },{refineEmpty:true,generate:async input=>{
     if(remaining()<1000)throw new PreviewServiceError('timeout');
     await reserve();if(remaining()<1000)throw new PreviewServiceError('timeout');
     return new GeminiProvider(key,model,fetcher,diagnostic,remaining()).generate(input);
    },
    ...(supplementMode!=='off'?{navigate:async(q:string)=>{if(remaining()<1500)return null;try{await reserve();return await supplement.navigate(q,Math.min(7000,remaining()));}catch{return null;}}}:{}),
     ...(supplementMode==='web'?{search:async(q:string)=>{if(remaining()<1000)return null;await reserve();return remaining()<1000?null:supplement.search(q,remaining());}}:{}),
    ...(['web','general'].includes(supplementMode)?{educate:async(q:string)=>{if(remaining()<1500)return null;try{await reserve();return await supplement.general(q,remaining(),true);}catch{return null;}},general:async(q:string)=>{if(remaining()<1000)return null;await reserve();return remaining()<1000?null:supplement.general(q,remaining());}}:{})
   });
   return response(answer);
  }catch(error){
   diagnostic({event:'request_failed',code:error instanceof PreviewServiceError?error.code:'internal'});
   if(error instanceof PreviewServiceError&&error.code==='busy')return response({code:'AI_BUSY',message:'Layanan model Gemini sedang tidak tersedia. Tunggu beberapa saat sebelum mencoba lagi.'},503);
   if(error instanceof PreviewServiceError&&error.code==='output_limit')return response({code:'AI_OUTPUT_LIMIT',message:'Gemini berhenti sebelum jawabannya selesai. Coba pertanyaan yang lebih singkat.'},502);
   if(error instanceof PreviewServiceError&&error.code==='output_format')return response({code:'AI_OUTPUT_FORMAT',message:'Jawaban Gemini belum dapat diperiksa format dan sumbernya. Silakan coba kembali.'},502);
   if(error instanceof PreviewServiceError&&error.code==='timeout')return response({code:'AI_TIMEOUT',message:'Gemini membutuhkan waktu terlalu lama. Silakan coba kembali nanti.'},504);
   if(error instanceof PreviewServiceError&&error.code==='provider')return response({code:'AI_PROVIDER_ERROR',message:'Pemrosesan AI belum berhasil. Silakan coba kembali nanti.'},503);
   if(error instanceof PreviewServiceError&&error.code==='quota')return response({code:'QUOTA',message:'Batas percobaan atau kuota gratis sedang tercapai. Tunggu sebentar dan coba lagi nanti.'},429);
   if(error instanceof PreviewServiceError&&error.code==='configuration')return response({code:'AI_CONFIGURATION',message:'Kunci atau model AI belum dapat digunakan. Periksa kunci, akses model, dan status Free Tier di Google AI Studio.'},503);
   return response({code:'UNAVAILABLE',message:'Maaf, BILAH sedang mengalami gangguan sementara. Silakan mencoba kembali.'},503);
  }
 };
}
