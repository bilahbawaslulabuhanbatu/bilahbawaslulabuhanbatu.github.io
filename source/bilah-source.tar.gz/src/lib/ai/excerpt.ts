import {retrievalTerms} from '../guardrails/classify.ts';

// Select an intact short article subsection, rather than cutting a PDF page arbitrarily.
// The result is always a contiguous excerpt of the retrieved source, never a generated procedure.
export function relevantExcerpt(content:string,question:string):string {
 const text=content.trim(),terms=retrievalTerms(question);
 const articles=[...text.matchAll(/(?:^|\n)\s*Pasal\s+\d+\s*\n/g)];
 const units=articles.length?articles.map((match,i)=>text.slice(match.index,articles[i+1]?.index??text.length).trim()):[text];
 const score=(unit:string)=>{
  const q=unit.replace(/\s+/g,' ').toLowerCase();
  return terms.reduce((sum,t)=>sum+(q.includes(t)?1:0),0)
   + (/\bsengketa\b/i.test(question)&&/penyampaian permohonan secara (tidak )?langsung.{0,180}(loket|sips)/.test(q)?10:0)
   + (/lapor/i.test(question)&&/laporan.{0,100}disampaikan dengan cara/.test(q)?10:0);
 };
 const selected=units.sort((a,b)=>score(b)-score(a))[0];
 const second=selected.search(/\(2\)/);
 const first=second>80?selected.slice(0,second).trim():selected;
 if(first.length<=1000)return first;
 const end=first.lastIndexOf('\n',1000);
 return first.slice(0,end>300?end:1000)+'\n[… lihat kelanjutan pada sumber …]';
}
