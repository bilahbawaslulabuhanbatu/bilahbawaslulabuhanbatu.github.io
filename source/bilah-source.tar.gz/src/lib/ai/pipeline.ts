import type {AIProvider,Source} from './contracts.ts';
import type {KnowledgeRow} from '../knowledge/contracts.ts';
import {hasSourceProvenance} from '../knowledge/contracts.ts';
import {classifyQuestion,retrievalTerms,type GuardrailDecision} from '../guardrails/classify.ts';
import {guardrailMessages} from '../guardrails/messages.ts';
import {ExtractiveMockProvider} from './mock-provider.ts';
export type PreviewAnswer={answer:string;sources:Source[];decision:GuardrailDecision|'no_source'|'unavailable';canEscalate:boolean;mode:'extractive_mock'};
type Retrieve=(terms:string[])=>Promise<KnowledgeRow[]>;
export async function previewAnswer(question:string,retrieve:Retrieve,provider:AIProvider=new ExtractiveMockProvider()):Promise<PreviewAnswer> {
  const decision=classifyQuestion(question);
  const result=(answer:string,canEscalate=false,d:PreviewAnswer['decision']=decision,sources:Source[]=[]):PreviewAnswer=>({answer,sources,decision:d,canEscalate,mode:'extractive_mock'});
  if (!question.trim()||question.length>2000) return result('Tulis pertanyaan antara 1 dan 2.000 karakter.',false,'ambiguous');
  if (decision==='sensitive') return result('Jangan masukkan NIK, password, atau data pribadi. Ubah pertanyaan menjadi contoh umum.');
  if (decision==='injection') return result('BILAH hanya menggunakan sumber yang telah disetujui dan tetap mengikuti batas layanan informasi. Silakan ajukan pertanyaan kepemiluan.');
  if (decision==='political') return result(guardrailMessages.political);
  if (decision==='out_of_domain') return result(guardrailMessages.outOfDomain);
  if (decision==='human') return result('Permintaan bantuan petugas perlu diteruskan melalui tiket konsultasi. Uji internal ini belum membuat atau mengirim tiket.',true);
  if (decision==='ambiguous') return result('Mohon perjelas pertanyaan yang berkaitan dengan Pemilu, pengawasan, atau pelayanan Bawaslu.',true);
  const prefix=decision==='legal'?guardrailMessages.legalAssessment+'\n\n':decision==='report'?'Tiket konsultasi BILAH bukan tanda penerimaan laporan pelanggaran secara resmi.\n\n':'';
  // Specific event assessments stop here; retrieval cannot establish relevance to a case.
  if (decision==='legal') return result(prefix.trim()+'\n\nSilakan konsultasikan peristiwa tersebut kepada petugas.',true);
  try {
    const rows=(await retrieve(retrievalTerms(question))).filter(r=>hasSourceProvenance(r)&&classifyQuestion(r.content)!=='injection');
    if(!rows.length) return result(prefix+guardrailMessages.noSource,true,'no_source');
    const context=rows.map(r=>({content:r.content,source:{documentId:r.document_id,chunkId:r.chunk_id,title:r.title,version:r.version,section:r.section_reference??undefined,url:r.source_url??undefined,filename:r.source_filename??undefined,sha256:r.source_sha256??undefined}}));
    const generated=await provider.generateAnswer({question,context});
    const selected=context.filter(c=>generated.sourceIds.includes(c.source.chunkId));
    // Fail closed: exact excerpts only. The demo cannot quietly become a generative provider.
    if(selected.length!==1||generated.sourceIds.length!==1||!generated.answer.trim()||!selected[0].content.includes(generated.answer)||generated.answer.length>12000) return result(prefix+guardrailMessages.noSource,true,'no_source');
    return result(prefix+'Kutipan sumber yang ditemukan:\n\n'+generated.answer,decision==='report'||generated.needsEscalation,decision,selected.map(c=>c.source));
  } catch {return result(guardrailMessages.unavailable,true,'unavailable');}
}
