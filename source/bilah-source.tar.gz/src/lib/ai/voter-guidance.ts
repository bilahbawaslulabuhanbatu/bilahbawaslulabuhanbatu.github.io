import type {Source} from './contracts.ts';
import {normalizeQuestion} from '../guardrails/classify.ts';

const source=(id:string,title:string,url:string,section?:string):Source=>({documentId:id,chunkId:id,title,url,section,version:0});
const portal=source('kpu-cek','Cek DPT Online KPU','https://cekdptonline.kpu.go.id/');
const service=source('kpu-397','Keputusan KPU Nomor 397 Tahun 2026','https://jdih.kpu.go.id/data/data_kepkpu/2026kpt397.pdf','Lampiran · Tindak lanjut jika data tidak ditemukan');
const localSite=source('kpu-labuhanbatu','Situs resmi KPU Kabupaten Labuhanbatu','https://kab-labuhanbatu.kpu.go.id/');
const directory=source('kpu-directory-sumut','Direktori kantor KPU di Sumatera Utara','https://www.kpu.go.id/koleksigambar/Sumatera_Utara.pdf','KPU Kabupaten Labuhanbatu');
const nationalElection=source('pkpu-25-2023','PKPU Nomor 25 Tahun 2023 · Pemilu','https://www.peraturan.go.id/files/peraturan-kpu-no-25-tahun-2023.pdf','Pasal 24 dan 31–32');
const nationalPolling=source('uu-pemilu-349','UU Nomor 7 Tahun 2017 · Pemilu','https://jdih.kpu.go.id/data/data_uu/UU_Nomor_7_Tahun_2017_-_Batang_Tubuh_-_Hal._151-317.pdf','Pasal 349');
const regionalPolling=source('pkpu-17-2024','PKPU Nomor 17 Tahun 2024 · Pilkada','https://jdih.kpu.go.id/data/data_pkpu/2024pkpu017.pdf','Pasal 19 dan 27');
const regionalAddress=source('pkpu-7-2024','PKPU Nomor 7 Tahun 2024 · Daftar Pemilih Pilkada','https://jdih.kpu.go.id/data/data_pkpu/2024pkpu007.pdf','Pasal 53');

const topic=/\b(pemilih|dpt)\b/;
const missing=/\b(?:belum|tidak|tak)\s+(?:terdaftar|tercatat|terdata|ada|muncul|masuk|ketemu|ditemukan)\b/;
const contact=/\b(nomor|no\.?\s*(?:hp|wa|telp)|telepon|telpon|telp|whatsapp|wa|kontak)\b/;
const office=/\b((?:datang|pergi|hubungi) ke mana|alamat kantor|lokasi kantor|kantornya (?:di|ke) mana)\b/;
const polling=/\b(hari (?:h|pencoblosan|pemungutan)|hari-h|saat (?:mencoblos|pencoblosan|pemungutan)|di tps|hak pilih)\b/;
const wrongScope=/\b(sanksi|pidana|gugat|pindah memilih|luar negeri|pemungutan suara ulang|psu|di bawah umur)\b/;
const otherJurisdiction=/\b(labuhan\s*batu\s*(?:utara|selatan)|labura|labusel|medan)\b/;
const helpdesk='Helpdesk Pemutakhiran Data Pemilih di KPU kabupaten/kota setempat';

export function voterGuidance(question:string):{answer:string;sources:Source[]}|null {
 const [current,previous='']=question.split('\n\nPertanyaan sebelumnya:',2).map(normalizeQuestion);
 const voterIssue=topic.test(current)&&missing.test(current);
 const ongoingIssue=topic.test(previous)&&missing.test(previous);
 if(wrongScope.test(current)||wrongScope.test(previous)||/\bnomor (?:tps|urut|antrean|laporan|tiket)\b/.test(current))return null;
 const identity=/\b(?:e[- ]?ktp|ktp(?:[- ]?el)?|kartu tanda penduduk)\b/;
 const unfinished=/\b(belum|belom|blm|belum jadi|menunggu|nunggu|proses|diproses|dicetak|perekaman|rekam|pengurusan)\b/;
 const pendingIdentity=(q:string)=>identity.test(q)&&unfinished.test(q)&&!/(?:ktp|kartu tanda penduduk).{0,16}(?:sudah|udah) (?:ada|jadi|selesai|terbit)/.test(q);
 if(pendingIdentity(previous)&&/^(?:nama saya )?(?:sudah|belum) muncul[.! ]*$/.test(current)){
  return {answer:current.includes('belum')?'Karena nama Anda belum muncul, hubungi layanan pemutakhiran data pemilih KPU kabupaten/kota sesuai domisili. Jelaskan bahwa KTP masih diproses dan minta pengecekan status pemilih serta dokumen yang perlu disiapkan. Jangan kirim NIK di sini.':'Kalau nama sudah muncul, catat lokasi TPS yang tertera. Sekarang yang perlu dikonfirmasi ke KPU adalah dokumen identitas yang diterima sebagai pengganti kartu fisik pada pemilihan Anda. Sebutkan dokumen yang sudah Anda miliki, tanpa mengirim nomornya di chat.',sources:[service,portal]};
 }
 if(pendingIdentity(current)&&/\b(tps|memilih|pemilih|nyoblos|coblos|mencoblos|pilkada|pemilu)\b/.test(current+' '+previous)&&!/\b(meninggal|pindah|palsu|ganda|orang lain|hilang|luar negeri)\b/.test(current)){
  return {answer:'KTP yang belum selesai dicetak tidak otomatis berarti Anda tidak bisa memilih. Yang perlu dipastikan adalah status Anda dalam daftar pemilih dan dokumen yang diterima untuk pemilihan tersebut.\n\nCek dulu nama dan TPS Anda di Cek DPT Online KPU. Jika kartu fisik belum terbit, tanyakan kepada Dukcapil apakah Biodata Penduduk Anda sudah tersedia. Lalu konfirmasikan ke KPU setempat apakah dokumen itu dapat dipakai sesuai status Anda. Sebagai contoh, panduan KPU untuk Pilkada 2024 mencantumkan Biodata Penduduk sebagai alternatif KTP-el; jangan langsung menganggap bukti pengurusan KTP pasti berlaku untuk setiap pemilihan.\n\nApakah nama Anda sudah muncul saat dicek di daftar pemilih?',sources:[portal,source('kpu-polling-guide','KPU: Persiapan ke TPS · Pilkada 2024','https://www.kpu.go.id/berita/baca/12685/cek-lokasi-dan-apa-yang-perlu-dipersiapkan-sebelum-ke-tps')]};
 }
 if(contact.test(current) && (voterIssue||ongoingIssue||(/\bkpu\b/.test(current)&&/\blabuhan\s*batu\b/.test(current))) && !/\b(bawaslu|panwas|pengawas|dkpp|dukcapil|ppid|otp|nik)\b/.test(current)) {
  if(otherJurisdiction.test(current+' '+previous))return {answer:'Saya belum punya nomor KPU setempat yang terverifikasi untuk wilayah itu. Untuk masalah nama yang tidak muncul, hubungi '+helpdesk+' atau gunakan kanal pengaduan di portal Cek DPT Online KPU.',sources:[service,portal]};
  return {answer:'Jika wilayah Anda Kabupaten Labuhanbatu, direktori KPU mencantumkan nomor kantor (0624) 325940. Nomor ini tercantum sebagai telepon kantor; saya belum bisa memastikan apakah masih aktif atau tersambung langsung ke helpdesk. Saat menghubungi, minta diarahkan ke bagian pemutakhiran data pemilih. Jika tidak tersambung, gunakan kanal pengaduan di portal Cek DPT Online KPU.',sources:[directory,service,portal]};
 }
 if(!voterIssue&&!ongoingIssue)return null;
 if(polling.test(current)&&! /\b(kontak|nomor|telepon)\b/.test(current)){
  if(/\b(tanpa ktp|tidak (?:punya|memiliki) ktp|belum (?:punya|memiliki) ktp|ktp hilang|pindah domisili)\b/.test(current+' '+previous))return null;
  const regional=/\b(pilkada|pemilihan (?:kepala daerah|bupati|gubernur|wali\s*kota))\b/.test(current+' '+previous);
  const national=/\b(pemilu|pemilihan umum|pilpres|pileg)\b/.test(current+' '+previous);
  const descriptions=[
   ...(!regional||national?['Pemilu (presiden atau legislatif): jika Anda memenuhi syarat, tidak ada dalam daftar tetap maupun daftar pindahan, dan memiliki KTP elektronik, bawa KTP elektronik ke TPS sesuai alamat KTP, lalu daftar ke petugas KPPS. Anda dapat dilayani sebagai pemilih dalam Daftar Pemilih Khusus (DPK) pada satu jam terakhir pemungutan suara, sesuai ketersediaan surat suara.']:[]),
   ...(regional||!national?['Pilkada (pemilihan kepala daerah): jika Anda memenuhi syarat dan tidak terdaftar dalam daftar tetap maupun daftar pindahan, tunjukkan KTP elektronik kepada petugas KPPS di TPS sesuai alamat KTP. Anda dapat dilayani sebagai Pemilih Tambahan pada satu jam terakhir, jika surat suara tersedia.']:[])
  ];
  return {answer:['Nama yang belum muncul tidak otomatis membuat Anda kehilangan kesempatan memilih. Minta KPU setempat mengecek status dan memastikan TPS Anda sebelum hari pencoblosan, jika masih sempat.',...descriptions,'Jika KPU menemukan nama Anda terdaftar di TPS lain, ikuti arahan KPU tentang TPS yang berlaku untuk Anda. Ketentuan teknis dapat berbeda menurut pemilihan yang sedang berlangsung; konfirmasi ke KPU atau KPPS.'].join('\n\n'),sources:[...(!regional||national?[nationalPolling,nationalElection]:[]),...(regional||!national?[regionalPolling,regionalAddress]:[])]};
 }
 if(office.test(current)&&! /\b(bawaslu|dukcapil|panwas|dkpp)\b/.test(current)){
  const local= !otherJurisdiction.test(current+' '+previous) && /\blabuhan\s*batu\b/.test(current+' '+previous);
  return {answer:'Pengaduan data pemilih ditangani '+helpdesk+'. '+(local?'Untuk Kabupaten Labuhanbatu, direktori KPU mencantumkan kantor di Jl. W.R. Supratman No. 52, Rantauprapat. ':'Datangi KPU kabupaten/kota yang menangani data domisili Anda. ')+'Sampaikan bahwa Anda sudah mengecek tetapi nama belum muncul, lalu minta petugas memeriksa status dan menjelaskan langkah pembaruan.',sources:local?[service,directory,localSite]:[service]};
 }
 if(missing.test(current)&&/\b(sudah|udah|telah)\b.{0,30}\b(cek|mengecek|periksa|memeriksa|periksa sendiri)\b/.test(current)){
  return {answer:'Karena Anda sudah mengecek dan nama masih belum muncul, laporkan ke '+helpdesk+'. Sampaikan hasil pengecekan dan minta petugas memeriksa data serta menjelaskan cara pembaruannya. Anda juga dapat menggunakan kanal pengaduan di portal Cek DPT Online KPU atau menghubungi PPID KPU setempat. Jangan kirim NIK atau kode OTP ke chat BILAH.',sources:[service,portal]};
 }
 if(voterIssue&&!/\b(meninggal|data orang lain|pemilih ganda|akta)\b/.test(current)){
  return {answer:'Kalau nama Anda belum muncul, langkah berikutnya adalah meminta KPU setempat memeriksa data Anda.\n\n1. Jika belum mengecek sendiri, buka Cek DPT Online KPU. Masukkan NIK hanya di situs resmi itu, jangan kirim NIK atau kode OTP ke chat ini.\n\n2. Kalau sudah mengecek dan nama tetap tidak ditemukan, hubungi layanan pemutakhiran data pemilih di KPU kabupaten/kota tempat Anda berdomisili. Sampaikan: “Nama saya belum muncul di Cek DPT. Mohon bantu periksa data saya dan jelaskan cara mengajukan pembaruan.”',sources:[portal,service]};
 }
 return null;
}
