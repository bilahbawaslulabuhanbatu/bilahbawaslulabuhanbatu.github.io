import type {AIProvider,AnswerRequest,AnswerResult} from './contracts.ts';
// Extractive mock: quotes an approved passage verbatim, never invents law.
export class ExtractiveMockProvider implements AIProvider {
  async generateAnswer(input:AnswerRequest):Promise<AnswerResult> {
    const match=input.context[0];
    if (!match) return {answer:'',sourceIds:[],needsEscalation:true,reason:'no_source'};
    const excerpt=match.content.trim();
    return {answer:excerpt,sourceIds:[match.source.chunkId],needsEscalation:false};
  }
}
