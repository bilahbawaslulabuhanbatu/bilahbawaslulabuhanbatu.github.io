import {contextualQuestion} from './question-context.ts';
import {answerFromIndex} from '../ai/rag-engine.ts';
import {PreviewServiceError,type GroundedAnswer,type RetrievedChunk} from '../ai/grounded.ts';
import {GeminiProvider} from '../ai/gemini-provider.ts';
import {SupplementProvider} from '../ai/supplement-provider.ts';
import {classifyQuestion} from '../guardrails/classify.ts';
type Environment={get:(key:string)=>string|undefined};
export function hasPersonalData(question:string):boolean {
 return classifyQuestion(question)==='sensitive'||/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(question)||/\b(?:\+?62|0)8[\d -]{7,15}\d\b/.test(question);
}
export function createPublicChatHandler(env:Environment,fetcher:typeof fetch=fetch,diagnostic:(event:Record<string,string|number>)=>void=()=>{}){
 return async(req:Request):Promise<Response>=>{
  const started=Date.now(),primaryOrigin=env.get('ALLOWED_ORIGIN')||'https://bilah-labuhanbatu-ray.rangkutiray3.chatgpt.site';
  const requestOrigin=req.headers.get('origin');
  const permitted=new Set([primaryOrigin,'https://rangkutiray3.github.io']);
  const origin=requestOrigin&&permitted.has(requestOrigin)?requestOrigin:primaryOrigin;
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'content-type, apikey','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin','X-Content-Type-Options':'nosniff'};
  const respond=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
  if(requestOrigin&&!permitted.has(requestOrigin))return respond({message:'Akses dibatasi.'},403);
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(req.method!=='POST')return respond({message:'Permintaan tidak didukung.'},405);
  if(env.get('PUBLIC_CHAT_ENABLED')==='false')return respond({message:'Chat BILAH sedang dinonaktifkan sementara.'},503);
  const url=env.get('SUPABASE_URL'),serviceKey=env.get('SUPABASE_SERVICE_ROLE_KEY'),key=(env.get('AI_API_KEY')??env.get('GEMINI_API_KEY')??'').trim();
  if(!url||!serviceKey||!key||(env.get('AI_PROVIDER')||'gemini')!=='gemini')return respond({message:'Sambungan chat BILAH belum siap. Silakan mencoba kembali nanti.'},503);
  if(!req.headers.get('content-type')?.includes('application/json'))return respond({message:'Format pertanyaan tidak valid.'},400);
  let data:unknown;
  try{
   const reader=req.body?.getReader();if(!reader)throw Error();let size=0;const parts:Uint8Array[]=[];
   while(true){const p=await reader.read();if(p.done)break;size+=p.value.byteLength;if(size>8192){await reader.cancel();return respond({message:'Pertanyaan terlalu panjang.'},413);}parts.push(p.value);}
   const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}data=JSON.parse(new TextDecoder().decode(bytes));
  }catch{return respond({message:'Format pertanyaan tidak valid.'},400);}
  if(!data||typeof data!=='object')return respond({message:'Format pertanyaan tidak valid.'},400);
  const input=data as Record<string,unknown>,question=typeof input.question==='string'?input.question.trim():'';
  if(!question||question.length>2000||typeof input.sessionToken!=='string'||!/^[a-f0-9]{64}$/.test(input.sessionToken)||typeof input.requestId!=='string'||!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(input.requestId))return respond({message:'Pertanyaan atau sesi tidak valid. Muat ulang halaman dan coba kembali.'},400);
  if(hasPersonalData(question))return respond({message:'Hapus NIK, password, nomor telepon atau alamat email dari pertanyaan. Gunakan pertanyaan umum tanpa data pribadi.'},400);
  const requestId=input.requestId;
  const rpc=async(name:string,body:unknown)=>{
   const response=await fetcher(url+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:serviceKey,Authorization:'Bearer '+serviceKey,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(8000)});
   if(!response.ok){diagnostic({event:'public_rpc_failed',rpc:name,status:response.status});throw Error('database');}return response.json();
  };
  try{
   const hmacKey=await crypto.subtle.importKey('raw',new TextEncoder().encode(serviceKey),{name:'HMAC',hash:'SHA-256'},false,['sign']);
   const hash=async(value:string)=>[...new Uint8Array(await crypto.subtle.sign('HMAC',hmacKey,new TextEncoder().encode(value)))].map(v=>v.toString(16).padStart(2,'0')).join('');
   const ip=(req.headers.get('cf-connecting-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]||'unavailable').slice(0,100);
   const [sessionHash,ipHash,questionHash]=await Promise.all([hash('session:'+input.sessionToken),hash('ip:'+ip),hash('question:'+question)]);
   const begin=await rpc('bilah_public_chat_begin',{p_request_id:requestId,p_session_hash:sessionHash,p_ip_hash:ipHash,p_question_hash:questionHash,p_question:question});
   if(begin.state==='limited'){
    const message=begin.reason==='minute'?'Pesan dikirim terlalu cepat. Tunggu satu menit, lalu lanjutkan percakapan Anda.':begin.reason==='session_day'?'Batas harian sesi atau jaringan ini tercapai. Batas akan berkurang bertahap dalam 24 jam; silakan gunakan layanan petugas jika mendesak.':begin.reason==='service_day'?'Batas harian seluruh layanan BILAH tercapai. Silakan mencoba lagi setelah kuota tersedia atau gunakan layanan petugas.':'Batas percobaan chat sedang tercapai. Tunggu sebentar atau gunakan layanan petugas.';
    return respond({message,code:begin.reason??'limited'},429);
   }
   if(begin.state==='pending')return respond({message:'Pertanyaan ini masih diproses. Tunggu beberapa saat sebelum mencoba kembali.'},409);
   if(begin.state==='complete')return respond(begin.response);
   if(begin.state!=='new')throw Error('unexpected state');
   let answer:GroundedAnswer;
   try{
    const deadline=Date.now()+35000,remaining=()=>deadline-Date.now(),model=(env.get('AI_MODEL')||'gemini-3.5-flash-lite').trim();
    const reserve=async()=>{if(remaining()<1000)throw new PreviewServiceError('timeout');if(await rpc('bilah_public_ai_reserve',{p_request_id:requestId})!==true)throw new PreviewServiceError('quota');};
    const supplement=new SupplementProvider(key,fetcher,diagnostic,model);
    answer=await answerFromIndex(contextualQuestion(question,begin.previousQuestions),async terms=>{
     const rows=await rpc('bilah_rag_search',{search_terms:terms});if(!Array.isArray(rows))throw Error('retrieval');return rows as RetrievedChunk[];
    },{
     refineEmpty:true,generate:async value=>{await reserve();return new GeminiProvider(key,model,fetcher,diagnostic,remaining()).generate(value);},
     ...(env.get('AI_SUPPLEMENT_MODE')==='web'?{search:async(q:string)=>{if(remaining()<1500)return null;try{await reserve();return await supplement.search(q,remaining());}catch{return null;}}}:{}),
     ...((env.get('AI_SUPPLEMENT_MODE')||'general')!=='off'?{navigate:async(q:string)=>{if(remaining()<1500)return null;try{await reserve();return await supplement.navigate(q,Math.min(7000,remaining()));}catch{return null;}}}:{}),
     ...((env.get('AI_SUPPLEMENT_MODE')||'general')==='off'?{}:{educate:async(q:string)=>{if(remaining()<1500)return null;try{await reserve();return await supplement.general(q,remaining(),true);}catch{return null;}},general:async(q:string)=>{if(remaining()<1000)return null;await reserve();return remaining()<1000?null:supplement.general(q,remaining());}})
    });
    if(answer.decision==='human')answer={...answer,answer:'Anda dapat membuat tiket konsultasi melalui tombol Butuh bantuan petugas. Pertanyaan akan diteruskan setelah Anda menyetujui pengiriman dan tiket berhasil dibuat. Tiket konsultasi bukan tanda penerimaan laporan pelanggaran resmi.'};
   }catch(error){
    diagnostic({event:'public_answer_failed',code:error instanceof PreviewServiceError?error.code:'internal'});
    answer={answer:error instanceof PreviewServiceError&&error.code==='quota'?'Batas penggunaan AI sedang tercapai. Silakan mencoba kembali nanti atau berkonsultasi kepada petugas.':'Maaf, BILAH sedang mengalami gangguan sementara. Silakan mencoba kembali atau menggunakan kanal pelayanan resmi Bawaslu.',sources:[],decision:'unavailable',canEscalate:true,mode:'guardrail'};
   }
   if(await rpc('bilah_public_chat_finish',{p_request_id:requestId,p_response:answer,p_response_time_ms:Date.now()-started})!==true)throw Error('persistence');
   return respond({...answer,requestId,recorded:true});
  }catch{diagnostic({event:'public_request_failed'});return respond({message:'Pertanyaan belum dapat diselesaikan. Silakan mencoba kembali nanti.'},503);}
 };
}
