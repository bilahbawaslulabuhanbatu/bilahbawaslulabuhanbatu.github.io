import {classifyQuestion} from '../guardrails/classify.ts';
const continuation=/^(siapa yang (membentuknya|dapat mengajukannya|berwenang)|bukti(nya)? (apa|harus)|apa (bedanya|yang perlu dicatat)|maksudnya|contohnya|bagaimana dengan|bagaimana (syaratnya|selanjutnya)|sudah muncul|belum muncul|nama saya (?:sudah|belum) muncul|bagaimana (jika|kalau|dengan|caranya)|gimana (jika|kalau|caranya)|kalau|jika|lalu|terus|apakah (itu|dia)|apa (syaratnya|akibatnya|sanksinya|ada (nomor|kontak|telepon|wa))|ada (nomor|kontak|telepon|wa)|nomor (telepon|kontak|wa)|bisa (telepon|hubungi)|alamat(nya)? di mana|harus datang ke mana|sudah (coba|cek)|udah (coba|cek)|berapa lama|syaratnya|sanksinya|saya (sudah|udah) (coba|cek)|tetap (tidak|belum)|masih (tidak|belum)|ke mana|kemana|di mana|dimana|siapa yang (bisa|harus) saya hubungi)\b/i;
const explicitTopic=/\b(asn|pns|kepala daerah|gubernur|bupati|wali ?kota|presiden|menteri|kepala desa|kpu|kpps|ppid|sengketa|informasi publik)\b/i;
const unsafe=new Set(['sensitive','injection','political','out_of_domain','human']);
// Server-loaded same-session questions only, newest first. Never reuse AI answers as evidence.
export function contextualQuestion(question:string,history:unknown):string {
 if(unsafe.has(classifyQuestion(question))||!Array.isArray(history)||question.length>1100)return question;
 if(!continuation.test(question.trim())||explicitTopic.test(question))return question;
 const recent:string[]=[];let anchor:string|undefined;
 for(const item of history.slice(0,8)){
  if(typeof item!=='string'||item.length>1000||unsafe.has(classifyQuestion(item)))break;
  if(continuation.test(item.trim())&&!explicitTopic.test(item)){recent.push(item);continue;}
  if(['information','report','legal'].includes(classifyQuestion(item)))anchor=item;
  break;
 }
 if(!anchor)anchor=recent.find(item=>['information','report','legal'].includes(classifyQuestion(item)));
 if(!anchor)return question;
 const context=[anchor.slice(0,450),...recent.filter(x=>x!==anchor).slice(0,3).reverse().map(x=>x.slice(0,120))].join(' → ');
 return question+'\n\nPertanyaan sebelumnya: '+context;
}
