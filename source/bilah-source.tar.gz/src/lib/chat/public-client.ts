'use client';
import type {GroundedAnswer} from '../ai/grounded';
export type PublicChatAnswer=GroundedAnswer&{recorded:boolean;requestId:string};
const sessionKey='bilah-public-session-v1';
export function newPublicConversation(){sessionStorage.removeItem(sessionKey);}
export function getPublicSessionToken(){
 let token=sessionStorage.getItem(sessionKey);
 if(!token||!/^[a-f0-9]{64}$/.test(token)){token=[...crypto.getRandomValues(new Uint8Array(32))].map(v=>v.toString(16).padStart(2,'0')).join('');sessionStorage.setItem(sessionKey,token);}
 return token;
}
export async function askPublicBilah(question:string,signal:AbortSignal):Promise<PublicChatAnswer>{
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL;
 if(!url)throw Error('Sambungan chat BILAH belum tersedia.');
 let token:string;try{token=getPublicSessionToken();}catch{throw Error('Izinkan penyimpanan sesi browser agar chat dapat digunakan.');}
 const response=await fetch(url+'/functions/v1/bilah-public-chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question,sessionToken:token,requestId:crypto.randomUUID()}),signal});
 let data;try{data=await response.json();}catch{throw Error('Sambungan chat belum dapat dihubungi. Silakan mencoba kembali.');}
 if(!response.ok)throw Error(typeof data?.message==='string'?data.message:'Pertanyaan belum dapat diproses.');
 if(typeof data?.answer!=='string'||!Array.isArray(data.sources)||data.recorded!==true||!['gemini','guardrail'].includes(data.mode))throw Error('Jawaban belum dapat diperiksa. Silakan mencoba kembali.');
 return data;
}
