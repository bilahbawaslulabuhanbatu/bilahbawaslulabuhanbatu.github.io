import 'server-only';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { getServerEnvironment } from '@/lib/config/server';

export async function createUserDatabaseClient() {
  const env = getServerEnvironment();
  const key = env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!env.NEXT_PUBLIC_SUPABASE_URL || !key) return null;
  const cookieStore = await cookies();
  return createServerClient(env.NEXT_PUBLIC_SUPABASE_URL, key, {
    cookies: {
      getAll: () => cookieStore.getAll(),
      setAll: values => {
        // Server Components cannot persist refresh cookies; proxy.ts handles refresh.
        try { values.forEach(({ name, value, options }) => cookieStore.set(name, value, options)); }
        catch { /* The server component is read-only; proxy persists refreshed cookies. */ }
      },
    },
  });
}
