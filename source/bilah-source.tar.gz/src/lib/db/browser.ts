'use client';
import { createBrowserClient } from '@supabase/ssr';
import type { SupabaseClient } from '@supabase/supabase-js';
let client: SupabaseClient | null = null;
export function getBrowserDatabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  client ??= createBrowserClient(url, key, { cookieOptions: { sameSite: 'lax', secure: url.startsWith('https:') && typeof window !== 'undefined' && window.location.protocol === 'https:', maxAge: 3600 } });
  return client;
}
