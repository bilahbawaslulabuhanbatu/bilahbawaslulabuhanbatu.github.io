export type GuardrailDecision = 'sensitive'|'injection'|'political'|'human'|'legal'|'report'|'information'|'out_of_domain'|'ambiguous';
export function classifyQuestion(question:string):GuardrailDecision {
  const q=normalizeQuestion(question);
  if (/\b(?:\d[ -]?){16}\b/.test(q)||/(?:password|kata sandi|nik)\s*[:=]\s*\S+/i.test(q)) return 'sensitive';
  if (/(abaikan|lupakan|ignore|disregard).{0,60}(instruksi|aturan|previous|instruction|safety)|system prompt|developer message|jailbreak|bocorkan.{0,30}(rahasia|kunci|token)/i.test(q)) return 'injection';
  if (/\b(terbaik|unggul|pilihlah|dukunglah|menangkan|rekomendasikan)\b|(?:siapa|mana|partai apa|calon apa).{0,60}(?:pilih|dukung|rekomendasi)|(?:memilih|mendukung|pilih|dukung)\s+(?:siapa|yang mana)/.test(q)&&/\b(calon|partai|kandidat|paslon|capres|caleg)\b/.test(q)) return 'political';
  if (/\b(petugas|manusia|operator)\b/.test(q)&&/(ingin|mau|bicara|hubung|bantu|konsultasi|temu)/.test(q)) return 'human';
  if (/\b(tanah|waris|perceraian|perdata|utang|hutang|kontrakan)\b/.test(q)&&!/(pemilu|bawaslu|pemilihan|pilkada|kampanye)/.test(q)) return 'out_of_domain';
  if (/(apakah|termasuk|merupakan|terbukti|tentukan|putuskan|nilai|kena pasal|pasal berapa)/.test(q)&&(/(tindakan|perbuatan|kasus|kejadian)/.test(q)||/(termasuk|merupakan|terbukti|tentukan|putuskan|kena pasal|pasal berapa).{0,60}(pelanggaran|melanggar)/.test(q))) return 'legal';
  if (/\b(pajak|pencurian|perampokan|resep|bitcoin|zodiak)\b/.test(q)&&!/(pemilu|bawaslu|pemilihan|kampanye)/.test(q)) return 'out_of_domain';
  if (/(ingin|mau|melapor|laporkan|cara lapor|prosedur lapor)/.test(q)&&/(lapor|pelanggaran)/.test(q)) return 'report';
  if (/(\bjarak\b.{0,30}\bbulan\b|\bresep\b|\bzodiak\b|\bbitcoin\b|\bsepak bola\b)/.test(q)) return 'out_of_domain';
  if (/\b(berkampanye|mengampanyekan|dikampanyekan|pelapor|terlapor|laporan|pelaporan|melaporkan|melapor|bukti|saksi|sentra gakkumdu|gakkumdu|baleg|caleg|capres|cawapres|paslon|pencalonan|pencoblosan|mencoblos|coblos|pemungutan|penghitungan|rekapitulasi|surat suara|tps|kpps|pps|ppk|ptps|panwascam|panwas|perbawaslu|pkpu|dkpp)\b/.test(q)) return 'information';
  if (/\b(demokrasi|hoaks|hoax|golput|netralitas|partai|kandidat)\b/.test(q)) return 'information';
  if (/\b(hak pilih|pindah memilih|ikut memilih|bisa memilih|tim sukses|dprd|mencalonkan)\b/.test(q)) return 'information';
  if (/\bcalon\b/.test(q)&&/\b(asn|pns|kepala daerah|kepala desa|perangkat desa|uang|sembako|baliho|dukungan|memilih|fitnah|bohong|ijazah|influencer|politik)\b/.test(q)) return 'information';
  if (isPublicInformationQuestion(q)) return 'information';
  if (/\b(pemilu|pemilihan|pilkada|bawaslu|panwaslu|pengawasan|pencegahan|kepemiluan|pelanggaran|ppid|partisipatif|pemilih|kampanye|kpu|sengketa|mediasi|adjudikasi|sips|sigaplapor|netralitas|divisi|dpt)\b|informasi publik|hukum pemilu|pelayanan bawaslu|politik uang/.test(q)) return 'information';
  if (q.trim().split(/\s+/).length<=3) return 'ambiguous';
  return 'ambiguous';
}
const stopWords=new Set('apa apakah itu yang dan di ke dari untuk dengan bagaimana cara saya ingin mau bisa tentang mengenai berdasarkan kepada oleh adalah dalam ini tersebut bawaslu pemilu pemilihan informasi tolong jelaskan berapa kapan siapa sudah coba tetap tidak belum masih punya tapi tetapi ada kalau jika begitu harus sampai masalah sebelumnya pertanyaan lakukan dilakukan ingin tahu'.split(' '));
export function normalizeQuestion(question:string):string {
 return question.toLocaleLowerCase('id-ID').replace(/\b(kampay[eE]|kampnye|kamapnye)\b/g,'kampanye').replace(/\bpemil[iu]h?u?u\b/g,'pemilu').replace(/\bbawslu\b/g,'bawaslu').replace(/\b(gimana|gmn|bagaimna)\b/g,'bagaimana').replace(/\b(ngelapor|ngadu|mengadu|laporin|laporinnya)\b/g,'melapor').replace(/\b(pengen|pingin|mau)\b/g,'ingin').replace(/\b(ngawas|ngawasin)\b/g,'pengawasan').replace(/\b(pemilunya|pemilihanumum)\b/g,'pemilu').replace(/\b(nggak|gak|ga|enggak)\b/g,'tidak');
}
export function isPublicInformationQuestion(question:string):boolean {
 return /\bppid\b|informasi publik|\b(?:minta|meminta|permintaan|permohonan|keterbukaan|keberatan|sengketa)\s+informasi\b/.test(normalizeQuestion(question));
}
export function retrievalTerms(question:string):string[] {
  const terms=[...new Set(normalizeQuestion(question).match(/[a-z0-9]{2,40}/g)??[])].filter(t=>!stopWords.has(t));
  if (terms.some(t=>['asn','pns','aparatur'].includes(t))) terms.push('asn','aparatur','sipil','negara');
  if (terms.includes('pns')) terms.push('pegawai','negeri');
  if (terms.some(t=>['tugas','wewenang','kewenangan','fungsi'].includes(t))) terms.push('tugas','wewenang','kewenangan','fungsi');
  if (isPublicInformationQuestion(question)) terms.push('ppid','permohonan');
  if (terms.some(t=>['berkampanye','mengampanyekan','dikampanyekan'].includes(t))) terms.push('kampanye');
  if (terms.some(t=>['lapor','melapor','melaporkan','pelaporan','pelapor','terlapor'].includes(t))) terms.push('pelaporan','laporan');
  if (terms.some(t=>['partisipatif','partisipasi'].includes(t))) terms.push('partisipatif','partisipasi');
  if (/\b(anak|bocah|balita|bawah umur)\b/.test(normalizeQuestion(question)) && /kampanye/.test(normalizeQuestion(question))) terms.push('mengikutsertakan','memilih','hak','280');
  if (/\b(apa itu|apa arti|apa maksud|apa beda|yang dimaksud|apa pengertian|definisi)\b/i.test(question)) terms.push('ragdef');
  if(terms.includes('tni'))terms.push('tentara','nasional','indonesia');if(terms.includes('polri'))terms.push('kepolisian','republik');
  if (!terms.length && /bawaslu/i.test(question)) terms.push('bawaslu');
  return [...new Set(terms)].slice(0,24);
}
