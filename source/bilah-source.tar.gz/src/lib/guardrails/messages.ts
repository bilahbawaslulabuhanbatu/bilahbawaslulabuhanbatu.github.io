export const serviceDisclaimer = 'BILAH memberikan informasi awal berdasarkan sumber resmi Bawaslu. Informasi yang diberikan tidak menggantikan keputusan, penilaian hukum, atau pelayanan formal oleh pejabat yang berwenang.';
export const guardrailMessages = {
  outOfDomain: 'Maaf, pertanyaan tersebut berada di luar ruang lingkup layanan BILAH. BILAH berfokus pada informasi kepemiluan, pengawasan Pemilu, layanan Bawaslu, dan pendidikan hukum Pemilu.',
  political: 'BILAH tidak memberikan rekomendasi, dukungan, atau preferensi politik terhadap peserta Pemilu maupun pihak tertentu.',
  legalAssessment: 'BILAH dapat memberikan informasi mengenai ketentuan yang relevan, tetapi penilaian apakah suatu peristiwa memenuhi unsur pelanggaran merupakan kewenangan pejabat/petugas yang berwenang setelah melalui proses pemeriksaan.',
  noSource: 'Informasi yang cukup untuk menjawab pertanyaan tersebut belum tersedia dalam basis pengetahuan BILAH.',
  unavailable: 'Maaf, BILAH sedang mengalami gangguan sementara. Silakan mencoba kembali atau menggunakan kanal pelayanan resmi Bawaslu Kabupaten Labuhanbatu.',
} as const;
