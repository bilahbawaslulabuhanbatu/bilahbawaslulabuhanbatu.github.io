import { isRole, type Role } from './permissions.ts';
export type InternalProfile = { id: string; name: string; role: Role };
export function parseInternalProfile(value: unknown): InternalProfile | null {
  if (!value || typeof value !== 'object' || !('id' in value) || !('is_active' in value) || !('roles' in value)) return null;
  const row = value as { id: unknown; display_name?: unknown; is_active: unknown; roles: unknown };
  const relation = Array.isArray(row.roles) ? row.roles[0] : row.roles;
  const role = relation && typeof relation === 'object' && 'name' in relation ? relation.name : null;
  if (row.is_active !== true || typeof row.id !== 'string' || !isRole(role)) return null;
  return { id: row.id, name: typeof row.display_name === 'string' ? row.display_name : '', role };
}
