export const roles = ['petugas', 'admin', 'pimpinan', 'superadmin'] as const;
export type Role = typeof roles[number];
export type Permission = 'dashboard:read' | 'analytics:read' | 'tickets:assigned' | 'tickets:all' | 'tickets:assign' | 'knowledge:write' | 'conversations:read' | 'users:manage' | 'settings:write';
const grants: Record<Role, readonly Permission[]> = {
  petugas: ['tickets:assigned'],
  admin: ['dashboard:read', 'analytics:read', 'tickets:all', 'tickets:assign', 'knowledge:write', 'conversations:read', 'settings:write'],
  pimpinan: ['dashboard:read', 'analytics:read'],
  superadmin: ['dashboard:read', 'analytics:read', 'tickets:all', 'tickets:assign', 'knowledge:write', 'conversations:read', 'users:manage', 'settings:write'],
};
export function isRole(value: unknown): value is Role {
  return typeof value === 'string' && roles.some(role => role === value);
}
export function can(role: unknown, permission: Permission): boolean {
  return isRole(role) && grants[role].includes(permission);
}
