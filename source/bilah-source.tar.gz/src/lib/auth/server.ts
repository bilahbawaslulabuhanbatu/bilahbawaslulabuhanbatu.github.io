import 'server-only';
import { redirect } from 'next/navigation';
import { createUserDatabaseClient } from '@/lib/db/server';
import { can, isRole, type Permission } from './permissions';

export async function getInternalUser() {
  const db = await createUserDatabaseClient();
  if (!db) return null;
  try {
    const { data: auth, error } = await db.auth.getUser();
    if (error || !auth.user) return null;
    // Reads the current database role, never editable user_metadata.
    // A missing, disabled, or unauthorized profile never grants internal access.
    const { data: profile, error: profileError } = await db.from('users')
      .select('id, display_name, is_active, roles(name)')
      .eq('id', auth.user.id).single();
    if (profileError || !profile?.is_active) return null;
    const relation = profile.roles as unknown;
    const roleRow = Array.isArray(relation) ? relation[0] : relation;
    const role = roleRow && typeof roleRow === 'object' && 'name' in roleRow ? roleRow.name : undefined;
    if (!isRole(role)) return null;
    return { id: auth.user.id, name: profile.display_name as string, role };
  } catch { return null; }
}

export async function requireInternalUser() {
  const user = await getInternalUser();
  if (!user) redirect('/admin/login');
  return user;
}

export async function requirePermission(permission: Permission) {
  const user = await requireInternalUser();
  if (!can(user.role, permission)) redirect('/admin/forbidden');
  return user;
}
