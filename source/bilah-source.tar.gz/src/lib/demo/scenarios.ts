// UI-only scenarios for phase 3. This is NOT the production domain classifier,
// knowledge retrieval, or mock AI adapter. No network/database is used here.
export type Scenario = {
  category: string;
  text: string;
  sourcePending?: boolean;
  canEscalate?: boolean;
  kind: 'information' | 'boundary' | 'escalation' | 'sensitive';
};
export const quickQuestions = [
  { id: 'tugas', title: 'Apa tugas Bawaslu?', description: 'Tugas dan kewenangan', icon: 'shield' },
  { id: 'laporan', title: 'Bagaimana melaporkan dugaan pelanggaran?', description: 'Arah layanan dan konsultasi', icon: 'message' },
  { id: 'ppid', title: 'Bagaimana meminta informasi publik?', description: 'Layanan informasi dan PPID', icon: 'document' },
  { id: 'partisipasi', title: 'Apa itu pengawasan partisipatif?', description: 'Peran masyarakat', icon: 'people' },
] as const;
export const introMessage = 'Halo! Saya BILAH, asisten informasi Bawaslu Kabupaten Labuhanbatu. Ada yang bisa saya bantu mengenai Pemilu, pengawasan, atau layanan Bawaslu?';
export function containsSensitivePattern(text: string): boolean {
  return /\b\d{16}\b/.test(text) || /(?:password|kata sandi|nik)\s*[:=]\s*\S+/i.test(text);
}
export function selectDemoScenario(input: string): Scenario {
  const q = input.toLocaleLowerCase('id-ID');
  if (containsSensitivePattern(input)) return { category: 'Privasi', kind: 'sensitive', text: 'Untuk mencoba BILAH, cukup gunakan pertanyaan contoh. Jangan masukkan NIK, password, atau data pribadi. Silakan ubah pertanyaan Anda.' };
  if (/(pilih|terbaik|dukung|unggul)/.test(q) && /(calon|partai|kandidat|paslon)/.test(q)) return { category: 'Netralitas politik', kind: 'boundary', text: 'BILAH tidak memberikan rekomendasi, dukungan, atau preferensi politik terhadap peserta Pemilu maupun pihak tertentu.' };
  if (/bulan|planet|resep|zodiak|sepak bola|bitcoin/.test(q)) return { category: 'Di luar cakupan', kind: 'boundary', text: 'Maaf, pertanyaan tersebut berada di luar ruang lingkup layanan BILAH. BILAH berfokus pada informasi kepemiluan, pengawasan Pemilu, layanan Bawaslu, dan pendidikan hukum Pemilu.' };
  if (/petugas|manusia|operator/.test(q)) return { category: 'Pendampingan petugas', kind: 'escalation', canEscalate: true, text: 'Anda dapat meminta pendampingan petugas melalui tiket konsultasi. Pada pratinjau ini, Anda bisa melihat contoh alurnya. Permintaan belum dikirim kepada petugas.' };
  if (/apakah|termasuk|merupakan|terbukti/.test(q) && /pelanggaran|melanggar/.test(q)) return { category: 'Batas penilaian hukum', kind: 'boundary', canEscalate: true, sourcePending: true, text: 'BILAH dapat memberikan informasi mengenai ketentuan yang relevan, tetapi penilaian apakah suatu peristiwa memenuhi unsur pelanggaran merupakan kewenangan pejabat/petugas yang berwenang setelah melalui proses pemeriksaan.\n\nDalam pratinjau ini, ketentuan hukum belum ditampilkan karena basis pengetahuan belum terhubung.' };
  if (/lapor|pelanggaran/.test(q)) return { category: 'Informasi pelaporan', kind: 'information', canEscalate: true, sourcePending: true, text: 'BILAH dirancang untuk membantu menemukan prosedur dan kanal pelaporan yang tepat. Tiket di BILAH merupakan konsultasi atau informasi awal, bukan bukti penerimaan laporan pelanggaran secara resmi.\n\nRincian prosedur dan persyaratan akan ditampilkan setelah sumber resmi dimasukkan dan diperiksa oleh pengelola.' };
  if (/tugas|wewenang|kewenangan/.test(q)) return { category: 'Tugas Bawaslu', kind: 'information', sourcePending: true, canEscalate: true, text: 'Pada layanan lengkap, jawaban ini akan memuat ringkasan tugas dan kewenangan Bawaslu beserta rujukan yang relevan.\n\nBasis pengetahuan belum terhubung pada tahap pratinjau. Karena itu, BILAH belum menampilkan rincian ketentuan atau nomor pasal.' };
  if (/ppid|informasi publik/.test(q)) return { category: 'Informasi pelayanan', kind: 'information', sourcePending: true, canEscalate: true, text: 'BILAH akan membantu Anda menemukan alur permohonan informasi publik melalui layanan PPID.\n\nAlamat layanan, persyaratan, dan waktu pelayanan akan ditampilkan setelah informasi resmi Bawaslu Kabupaten Labuhanbatu diverifikasi. Permohonan informasi belum dapat diajukan melalui pratinjau ini.' };
  if (/partisipatif|partisipasi/.test(q)) return { category: 'Pengawasan partisipatif', kind: 'information', sourcePending: true, canEscalate: true, text: 'Topik ini akan membantu masyarakat memahami cara berpartisipasi dalam pengawasan Pemilu.\n\nContoh kegiatan, panduan, dan kanal keterlibatan akan diambil dari materi resmi yang disetujui pengelola. Saat ini Anda sedang melihat contoh tampilan percakapannya.' };
  if (/^\s*(halo|hai|selamat pagi|selamat siang|selamat malam|terima kasih)[!.\s]*$/.test(q)) return { category: 'Sapaan', kind: 'information', text: 'Halo! Silakan pilih salah satu contoh pertanyaan atau ketik pertanyaan untuk mencoba tampilan percakapan. Jawaban saat ini masih berupa simulasi.' };
  return { category: 'Sumber belum tersedia', kind: 'information', sourcePending: true, canEscalate: true, text: 'Informasi yang cukup untuk menjawab pertanyaan tersebut belum tersedia dalam basis pengetahuan BILAH.\n\nPratinjau ini menggunakan beberapa skenario contoh, belum AI yang memahami seluruh pertanyaan. Anda dapat mencoba pertanyaan yang disediakan atau melihat alur bantuan petugas.' };
}
