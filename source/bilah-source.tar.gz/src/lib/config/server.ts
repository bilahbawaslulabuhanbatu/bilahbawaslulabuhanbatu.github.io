import 'server-only';
import { environmentSchema } from './schema';

export function getServerEnvironment() {
  const parsed = environmentSchema.safeParse(process.env);
  if (!parsed.success) throw new Error('Konfigurasi server BILAH belum valid.');
  return parsed.data;
}

export function isSupabaseConfigured() {
  const env = getServerEnvironment();
  return Boolean(env.NEXT_PUBLIC_SUPABASE_URL && (env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || env.NEXT_PUBLIC_SUPABASE_ANON_KEY));
}
