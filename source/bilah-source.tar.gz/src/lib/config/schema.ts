import { z } from 'zod';

const optionalText = z.preprocess(value => value === '' ? undefined : value, z.string().optional());
export const environmentSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.preprocess(value => value === '' ? undefined : value, z.url().optional()),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: optionalText,
  NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: optionalText,
  SUPABASE_SERVICE_ROLE_KEY: optionalText,
  APP_BASE_URL: z.url().default('http://localhost:3000'),
  APP_TIMEZONE: z.literal('Asia/Jakarta').default('Asia/Jakarta'),
  AI_PROVIDER: optionalText,
  AI_MODEL: optionalText,
  AI_API_KEY: optionalText,
  MOCK_AI_MODE: z.enum(['true', 'false']).default('true').transform(value => value === 'true'),
  SESSION_SIGNING_SECRET: optionalText,
  AI_TIMEOUT_MS: z.coerce.number().int().min(1000).max(60000).default(15000),
  CHAT_RATE_LIMIT_PER_MINUTE: z.coerce.number().int().min(1).max(120).default(10),
  RETENTION_DAYS: z.coerce.number().int().min(1).max(365).default(30),
}).superRefine((env, context) => {
  if (Boolean(env.NEXT_PUBLIC_SUPABASE_URL) !== Boolean(env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || env.NEXT_PUBLIC_SUPABASE_ANON_KEY)) {
    context.addIssue({ code: 'custom', path: ['NEXT_PUBLIC_SUPABASE_URL'], message: 'URL dan public key Supabase harus diisi bersama.' });
  }
  if (!env.MOCK_AI_MODE && (!env.AI_PROVIDER || !env.AI_MODEL || !env.AI_API_KEY)) {
    context.addIssue({ code: 'custom', path: ['AI_PROVIDER'], message: 'Mode AI nyata memerlukan provider, model, dan API key.' });
  }
});
