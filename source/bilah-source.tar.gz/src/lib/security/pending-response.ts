import 'server-only';
import { NextResponse } from 'next/server';
export function pendingResponse() {
  return NextResponse.json({ code: 'FEATURE_NOT_READY', message: 'Fitur ini belum aktif pada tahap kerangka proyek. Belum ada pertanyaan atau tiket yang disimpan.' }, { status: 503, headers: { 'Cache-Control': 'no-store' } });
}
