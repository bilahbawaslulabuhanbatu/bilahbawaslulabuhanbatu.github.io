export const ticketStatuses = ['baru', 'dalam_proses', 'menunggu_informasi', 'selesai'] as const;
export type TicketStatus = typeof ticketStatuses[number];
export const ticketStatusLabels:Record<TicketStatus,string>={baru:'Baru',dalam_proses:'Dalam Proses',menunggu_informasi:'Menunggu Informasi',selesai:'Selesai'};
export const ticketCategories=[{value:'pelayanan-ppid',label:'Informasi pelayanan / PPID'},{value:'informasi-pemilu',label:'Informasi Pemilu'},{value:'tugas-bawaslu',label:'Tugas dan kewenangan'},{value:'pengawasan-partisipatif',label:'Pengawasan partisipatif'},{value:'konsultasi-pelanggaran',label:'Konsultasi dugaan pelanggaran'},{value:'konsultasi-sengketa',label:'Konsultasi sengketa'}] as const;
export type TicketReceipt={ticketNumber:string;status:TicketStatus;createdAt:string;accessCode:string};
export type PublicTicket={ticketNumber:string;status:TicketStatus;question:string;createdAt:string;updatedAt:string;resolvedAt:string|null;replies:{message:string;createdAt:string}[]};
export const ticketDisclaimer = 'Tiket ini merupakan permintaan konsultasi/informasi awal, bukan bukti penerimaan laporan pelanggaran secara resmi.';
