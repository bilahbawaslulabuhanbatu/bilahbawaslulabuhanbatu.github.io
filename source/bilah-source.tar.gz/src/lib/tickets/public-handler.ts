import {ticketCategories} from './contracts.ts';
type Environment={get:(key:string)=>string|undefined};
export function createTicketHandler(env:Environment,fetcher:typeof fetch=fetch){
 return async(req:Request):Promise<Response>=>{
  const primaryOrigin=env.get('ALLOWED_ORIGIN')||'https://bilah-labuhanbatu-ray.rangkutiray3.chatgpt.site';
  const requestOrigin=req.headers.get('origin');
  const permitted=new Set([primaryOrigin,'https://rangkutiray3.github.io']);
  const origin=requestOrigin&&permitted.has(requestOrigin)?requestOrigin:primaryOrigin;
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'content-type, apikey','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin','X-Content-Type-Options':'nosniff'};
  const respond=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
  if(requestOrigin&&!permitted.has(requestOrigin))return respond({message:'Akses dibatasi.'},403);
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(req.method!=='POST')return respond({message:'Permintaan tidak didukung.'},405);
  const url=env.get('SUPABASE_URL'),key=env.get('SUPABASE_SERVICE_ROLE_KEY');
  if(!url||!key||env.get('PUBLIC_TICKETS_ENABLED')==='false')return respond({message:'Layanan tiket sedang tidak tersedia.'},503);
  if(!req.headers.get('content-type')?.includes('application/json'))return respond({message:'Format permintaan tidak valid.'},400);
  let input:Record<string,unknown>;
  try{
   const reader=req.body?.getReader();if(!reader)throw Error();let size=0;const chunks:Uint8Array[]=[];
   while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>8192){await reader.cancel();return respond({message:'Permintaan terlalu panjang.'},413);}chunks.push(part.value);}
   const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}input=JSON.parse(new TextDecoder().decode(bytes));if(!input||typeof input!=='object')throw Error();
  }catch{return respond({message:'Format permintaan tidak valid.'},400);}
  const action=input.action;
  const code=typeof input.accessCode==='string'?input.accessCode.replace(/\s/g,'').toLowerCase():'';
  if(!['create','lookup'].includes(String(action))||!/^[a-f0-9]{32}$/.test(code))return respond({message:'Periksa nomor tiket dan kode akses Anda.'},400);
  if(action==='create'&&(input.consent!==true||typeof input.requestId!=='string'||!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(input.requestId)||typeof input.sessionToken!=='string'||!/^[a-f0-9]{64}$/.test(input.sessionToken)||!ticketCategories.some(c=>c.value===input.category)))return respond({message:'Sesi, kategori, atau persetujuan belum lengkap. Ajukan pertanyaan melalui chat terlebih dahulu.'},400);
  const number=typeof input.ticketNumber==='string'?input.ticketNumber.trim().toUpperCase():'';
  if(action==='lookup'&&!/^BILAH-\d{4}-\d{6,12}$/.test(number))return respond({message:'Periksa nomor tiket dan kode akses Anda.'},400);
  try{
   const hmac=await crypto.subtle.importKey('raw',new TextEncoder().encode(key),{name:'HMAC',hash:'SHA-256'},false,['sign']);
   const hash=async(s:string)=>[...new Uint8Array(await crypto.subtle.sign('HMAC',hmac,new TextEncoder().encode(s)))].map(v=>v.toString(16).padStart(2,'0')).join('');
   const rpc=async(name:string,body:unknown)=>{const response=await fetcher(url+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error();return response.json();};
   const ip=(req.headers.get('cf-connecting-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]||'unavailable').slice(0,100);
   if(await rpc('bilah_ticket_rate',{p_ip_hash:await hash('ticket-ip:'+ip),p_kind:action})!==true)return respond({message:'Terlalu banyak percobaan. Tunggu beberapa saat sebelum mencoba kembali.'},429);
   const accessHash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode('bilah-ticket-code-v1:'+code)))].map(v=>v.toString(16).padStart(2,'0')).join('');
   const result=action==='create'?await rpc('bilah_ticket_create',{p_request_id:input.requestId,p_session_hash:await hash('session:'+input.sessionToken),p_access_hash:accessHash,p_category:input.category}):await rpc('bilah_ticket_lookup',{p_number:number,p_access_hash:accessHash});
   if(!result)return respond({message:action==='create'?'Tiket belum dapat dibuat. Pastikan memakai sesi chat yang sama. Jika tiket sudah pernah dibuat, gunakan nomor dan kode akses yang sebelumnya disimpan.':'Nomor tiket atau kode akses tidak sesuai.'},404);
   return respond(result);
  }catch{return respond({message:'Layanan tiket belum dapat menyelesaikan permintaan. Silakan mencoba kembali nanti.'},503);}
 };
}
