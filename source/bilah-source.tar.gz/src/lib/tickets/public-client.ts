'use client';
import {getPublicSessionToken} from '../chat/public-client';
import {ticketStatuses,type TicketReceipt,type PublicTicket} from './contracts';
async function call(body:unknown){
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL;if(!url)throw Error('Sambungan tiket belum tersedia.');
 const response=await fetch(url+'/functions/v1/bilah-public-tickets',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(30000)});
 const data=await response.json();if(!response.ok)throw Error(typeof data?.message==='string'?data.message:'Tiket belum dapat diproses.');
 if(typeof data?.ticketNumber!=='string'||!/^BILAH-\d{4}-\d{6,12}$/.test(data.ticketNumber)||!ticketStatuses.includes(data.status))throw Error('Hasil layanan tiket belum dapat diperiksa.');return data;
}
export async function createPublicTicket(requestId:string,category:string):Promise<TicketReceipt>{
 const key='bilah-ticket-code-'+requestId;
 let accessCode=sessionStorage.getItem(key);
 if(!accessCode||!/^[a-f0-9]{32}$/.test(accessCode)){accessCode=[...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join('');sessionStorage.setItem(key,accessCode);}
 const data=await call({action:'create',requestId,category,sessionToken:getPublicSessionToken(),accessCode,consent:true});
 const receipt={...data,accessCode} as TicketReceipt;
 try{sessionStorage.setItem('bilah-last-ticket',JSON.stringify(receipt));}catch{}
 return receipt;
}
export async function lookupPublicTicket(ticketNumber:string,accessCode:string):Promise<PublicTicket>{
 const data=await call({action:'lookup',ticketNumber,accessCode});if(!Array.isArray(data.replies)||typeof data.question!=='string')throw Error('Tanggapan tiket belum dapat diperiksa.');return data;
}
export function lastTicket():TicketReceipt|null {
 try{const item=JSON.parse(sessionStorage.getItem('bilah-last-ticket')||'null');return item&&typeof item.ticketNumber==='string'&&typeof item.accessCode==='string'?item:null;}catch{return null;}
}
