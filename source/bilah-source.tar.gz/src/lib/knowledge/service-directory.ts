// Published service instructions. These supplement uploaded regulations for navigation only.
import {normalizeQuestion} from '../guardrails/classify.ts';
import type {Source} from '../ai/contracts.ts';
const portal='https://cekdptonline.kpu.go.id/';
const source:Source={documentId:'kpu-layanan-dpt',chunkId:'kpu-397-2026-pencarian',version:1,title:'KPU · Panduan pengecekan daftar pemilih',section:'Lampiran Keputusan KPU 397/2026 · Pencarian data',url:'https://jdih.kpu.go.id/data/data_kepkpu/2026kpt397.pdf'};
const entry:Source={documentId:'portal-dpt',chunkId:'portal-dpt',version:1,title:'Buka Cek DPT Online KPU',url:portal};
export function serviceGuide(question:string){
 const [now,prev='']=normalizeQuestion(question).split('pertanyaan sebelumnya:');
 const topic=/\b(dpt|pemilih|daftar pemilih tetap)\b/;
 if(!topic.test(now+' '+prev))return null;
 if(/\b(sanksi|pidana|memilih tanpa|pencoblosan|pindah|meninggal|usia|umur|anonim|pelanggaran|sengketa|syarat|boleh memilih|berhak|sejarah|arti|definisi|siapa yang|berapa jumlah|cek suara)\b/.test(now))return null;
 if(/\b(tni|polri|asn|caleg|calon|partai|kampanye|ganda|anggota|pengawas|saksi|lowongan|pps|kpps|keberatan|telepon|alamat kantor)\b/.test(now)||/\b(jumlah|rekap|statistik|anggaran)\b/.test(now))return null;
 const missing=/\b(tidak|ga|gak|nggak|belum|tak|tetap tidak) (muncul|ketemu|ditemukan|tercantum|ada|terdaftar)\b/.test(now)&&!/(atau belum|atau tidak)/.test(now);
 if(!missing&&!/\b(cek|ngecek|mengecek|periksa|memeriksa|melihat|lihat|tau|tahu|mengetahui|terdaftar|tercatat|tercantum|masuk dpt|link|tautan)\b/.test(now))return null;
 const content=missing?'Jika nama tidak muncul setelah pencarian, hubungi layanan data pemilih KPU kabupaten/kota sesuai domisili atau PPID KPU setempat. Sampaikan bahwa nama tidak ditemukan dan minta pemeriksaan data. Jika belum melakukan pencarian, gunakan Cek DPT Online KPU.':'Untuk melihat status pemilih, buka Cek DPT Online KPU (cekdptonline.kpu.go.id). Masukkan NIK di portal KPU, selesaikan verifikasi bila diminta, lalu jalankan pencarian. Periksa nama dan lokasi TPS pada hasilnya. Jika nama tidak ditemukan, hubungi KPU kabupaten/kota sesuai domisili untuk pemeriksaan data.';
 return {content,source,entry};
}
