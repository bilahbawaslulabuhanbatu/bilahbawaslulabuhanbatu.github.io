export const pdfLimits={files:5,bytes:15*1024*1024,pages:300,characters:500000} as const;
export function inferPdfMetadata(filename:string,firstPages:string){
 const flat=firstPages.replace(/\s+/g,' ').trim();
 const name=filename.replace(/\.pdf$/i,'').replace(/[_-]+/g,' ').trim();
 const identified=(name+' '+flat.slice(0,5000)).match(/(?:NOMOR|NO\.?)[\s.:]*(\d{1,4})\s*(?:TAHUN|[\/])\s*((?:19|20|21)\d{2})/i);
 const number=identified?.[1]??'',year=identified?.[2]??'';
 const agency=/bawaslu|badan pengawas pemilihan/i.test(name+' '+flat.slice(0,1800))?'Bawaslu':/\bkpu\b|komisi pemilihan umum/i.test(name+' '+flat.slice(0,1800))?'KPU':'';
 const presentation=/paparan|presentasi|\blkip\b|profil/i.test(name);
 const title=!presentation&&number&&year&&agency?`Peraturan ${agency} Nomor ${number} Tahun ${year}`:name;
 return {title:title.slice(0,300)||'Dokumen peraturan',document_number:!presentation&&number?`${number} Tahun ${year}`:'',year};
}
export type PdfTextItem={str?:string;hasEOL?:boolean;transform?:number[]};
export function textFromPdfItems(items:PdfTextItem[]):string {
 let result='',lastY:number|undefined;
 for(const item of items){
  if(typeof item.str!=='string')continue;
  const y=item.transform?.[5];
  if(lastY!==undefined&&y!==undefined&&Math.abs(y-lastY)>4&&!result.endsWith('\n'))result+='\n';
  result+=item.str+(item.hasEOL?'\n':' ');lastY=y;
 }
 return result.replace(/[ \t]+/g,' ').replace(/ *\n */g,'\n').replace(/\n{3,}/g,'\n\n').trim();
}
