import { z } from 'zod';
import {isOfficialSource} from './source-provenance.ts';
export {isOfficialSource,hasSourceProvenance} from './source-provenance.ts';
export const sourceTypes = {
  regulasi: 'Regulasi', pedoman_internal: 'Pedoman internal',
  informasi_pelayanan: 'Informasi pelayanan', informasi_kelembagaan: 'Informasi kelembagaan',
} as const;
export const statusLabels = { active: 'Aktif', inactive: 'Draf / nonaktif', outdated: 'Tidak berlaku' } as const;
export const documentSchema = z.object({
  title: z.string().trim().min(4,'Judul minimal 4 karakter.').max(300),
  category_id: z.union([z.uuid(),z.literal('')]),
  source_type: z.enum(['regulasi','pedoman_internal','informasi_pelayanan','informasi_kelembagaan']),
  document_number: z.string().trim().max(100),
  year: z.string().refine(v => v === '' || /^(19\d{2}|20\d{2}|21\d{2}|2200)$/.test(v),'Tahun harus antara 1900 dan 2200.'),
  content: z.string().trim().min(40,'Isi sumber minimal 40 karakter.').max(500000,'Isi maksimal 500.000 karakter. Bagi dokumen besar menjadi beberapa berkas.'),
  summary: z.string().trim().max(3000),
  source_url: z.string().trim().max(2048).refine(v => v === '' || isOfficialSource(v),'Gunakan tautan HTTPS dari situs resmi Bawaslu, KPU, BPK, DPR, Setneg, atau peraturan.go.id.'),
  effective_date: z.string().refine(v => v === '' || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)) && new Date(v).toISOString().slice(0,10) === v),'Tanggal tidak valid.'),
  visibility: z.enum(['internal','public']),
});
export type DocumentForm = z.infer<typeof documentSchema>;
export const emptyDocument: DocumentForm = {title:'',category_id:'',source_type:'informasi_kelembagaan',document_number:'',year:'',content:'',summary:'',source_url:'',effective_date:'',visibility:'internal'};
export type KnowledgeDocument = Omit<DocumentForm,'year'|'effective_date'|'category_id'|'document_number'|'source_url'> & {
  id:string; year:number|null; effective_date:string|null; category_id:string|null;
  document_number:string|null; source_url:string|null; status:keyof typeof statusLabels;
  version:number; updated_at:string; verified_at:string|null;
  source_origin?:'official_url'|'uploaded_pdf'; source_filename?:string|null; source_sha256?:string|null; source_page_count?:number|null;
};
export type KnowledgeRow = {document_id:string;chunk_id:string;title:string;version:number;source_url:string|null;section_reference:string|null;content:string;score:number;source_origin?:string;source_filename?:string|null;source_sha256?:string|null};
export const documentFields = 'id,title,category_id,source_type,document_number,year,content,summary,source_url,effective_date,visibility,status,version,updated_at,verified_at,source_origin,source_filename,source_sha256,source_page_count';
