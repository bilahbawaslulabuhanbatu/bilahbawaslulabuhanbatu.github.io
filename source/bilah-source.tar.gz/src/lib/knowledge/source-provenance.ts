export function isOfficialSource(value:string):boolean {
 try {const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&['bawaslu.go.id','kpu.go.id','bpk.go.id','dpr.go.id','setneg.go.id','peraturan.go.id'].some(d=>u.hostname===d||u.hostname.endsWith('.'+d));}catch{return false;}
}
export function hasSourceProvenance(row:{source_url?:string|null;source_origin?:string;source_filename?:string|null;source_sha256?:string|null}):boolean {
 return row.source_origin==='uploaded_pdf'?!!row.source_filename&&/^[a-f0-9]{64}$/.test(row.source_sha256??''):!!row.source_url&&isOfficialSource(row.source_url);
}
