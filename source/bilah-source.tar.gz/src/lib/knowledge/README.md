Kontrak formulir dan record dokumen untuk tahap 5. Chunking otomatis dan RPC
retrieval terkurasi didefinisikan dalam supabase/schema/bilah_knowledge.sql.
RPC hanya untuk uji admin; tidak memberi akses masyarakat ke tabel dokumen.
