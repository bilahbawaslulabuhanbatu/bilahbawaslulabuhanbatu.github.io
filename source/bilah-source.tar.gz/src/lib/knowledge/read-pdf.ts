import {inferPdfMetadata,pdfLimits,textFromPdfItems,type PdfTextItem} from './pdf-metadata.ts';
class PdfReadError extends Error{}
export type ParsedPdf={title:string;document_number:string;year:string;content:string;pages:number;emptyPages:number[];filename:string;sha256:string};
// Lazy browser import. PDF JavaScript and links are never executed or followed.
export async function readPdf(file:File,onProgress:(page:number,total:number)=>void,signal:AbortSignal,workerSrc='/pdfjs/pdf.worker.min.mjs'):Promise<ParsedPdf>{
 if(!/\.pdf$/i.test(file.name)||file.size===0||file.size>pdfLimits.bytes)throw new PdfReadError('Pilih PDF maksimal 15 MB per berkas.');
 const bytes=new Uint8Array(await file.arrayBuffer());
 if(new TextDecoder().decode(bytes.slice(0,1024)).indexOf('%PDF-')<0)throw new PdfReadError('Berkas ini tidak dikenali sebagai PDF.');
 const hash=await crypto.subtle.digest('SHA-256',bytes.slice().buffer);
 const sha256=Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join('');
 if(signal.aborted)throw new PdfReadError('Pembacaan dibatalkan.');
 const pdfjs=await import('pdfjs-dist/legacy/build/pdf.mjs');
 pdfjs.GlobalWorkerOptions.workerSrc=workerSrc;
 const assetBase=typeof window==='undefined'?decodeURIComponent(new URL('../../',workerSrc).pathname):'/pdfjs/';
 const task=pdfjs.getDocument({data:bytes,standardFontDataUrl:assetBase+'standard_fonts/',cMapUrl:assetBase+'cmaps/',cMapPacked:true,enableXfa:false,disableFontFace:true,useSystemFonts:false,stopAtErrors:true,maxImageSize:0});
 const abort=()=>{void task.destroy().catch(()=>{});};signal.addEventListener('abort',abort,{once:true});
 // Bound malformed/encrypted/huge documents without retaining a stuck worker.
 const timeout=setTimeout(abort,90000);
 try{
  const pdf=await task.promise;
  if(pdf.numPages>pdfLimits.pages)throw new PdfReadError('PDF lebih dari 300 halaman. Bagi menjadi beberapa berkas.');
  const pages:string[]=[],emptyPages:number[]=[];let length=0;
  for(let pageNo=1;pageNo<=pdf.numPages;pageNo++){
   if(signal.aborted)throw new PdfReadError('Pembacaan dibatalkan.');
   const page=await pdf.getPage(pageNo),data=await page.getTextContent();
   const text=textFromPdfItems(data.items as PdfTextItem[]);
   if(text.replace(/https?:\/\/\S+/g,'').length<25)emptyPages.push(pageNo);
   const entry=`[[HALAMAN PDF ${pageNo}]]\n${text}`;length+=entry.length+2;
   if(length>pdfLimits.characters)throw new PdfReadError('Teks melebihi 500.000 karakter. Bagi dokumen menjadi beberapa berkas.');
   pages.push(entry);page.cleanup();onProgress(pageNo,pdf.numPages);
  }
  if(emptyPages.length===pdf.numPages)throw new PdfReadError('PDF ini berupa hasil pindai/gambar. Pembacaan OCR belum tersedia; gunakan PDF yang teksnya bisa dipilih.');
  return {...inferPdfMetadata(file.name,pages.slice(0,3).join('\n')),content:pages.join('\n\n'),pages:pdf.numPages,emptyPages,filename:file.name.slice(0,255),sha256};
 }catch(error){
  if(error instanceof Error&&error.name==='PasswordException')throw new PdfReadError('PDF terkunci dengan password. Gunakan salinan yang tidak terkunci.');
  if(error instanceof PdfReadError)throw error;
  throw new PdfReadError(signal.aborted?'Pembacaan dibatalkan.':'PDF tidak dapat dibaca. Pastikan berkas tidak rusak dan coba PDF lain.');
 }finally{clearTimeout(timeout);signal.removeEventListener('abort',abort);await task.destroy().catch(()=>{});}
}
