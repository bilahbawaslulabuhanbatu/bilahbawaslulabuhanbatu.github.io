import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const preview = path.join(root, '.preview-build');
await rm(preview, { recursive: true, force: true });
await mkdir(path.join(preview, 'src'), { recursive: true });
await cp(path.join(root, 'src'), path.join(preview, 'src'), { recursive: true });
await cp(path.join(root, 'public'), path.join(preview, 'public'), { recursive: true });
// Static public UI plus protected client shell. PostgREST RLS enforces all data access.
// Server APIs remain in the canonical Next.js project for future server hosting.
await rm(path.join(preview, 'src/app/api'), { recursive: true, force: true });
await rm(path.join(preview, 'src/app/admin/(protected)'), { recursive: true, force: true });
await rm(path.join(preview, 'src/proxy.ts'), { force: true });
await rm(path.join(preview, 'src/lib/auth/server.ts'), { force: true });
await rm(path.join(preview, 'src/lib/db/server.ts'), { force: true });
await rm(path.join(preview, 'src/lib/config/server.ts'), { force: true });
// Reuse the same Auth session, profile checks and database RLS in static hosting.
const internalRoot = path.join(preview, 'src/app/admin/(protected)');
await mkdir(internalRoot, { recursive: true });
await writeFile(path.join(internalRoot, 'layout.tsx'), `import { InternalAppShell } from '@/components/admin/internal-app-shell';\nexport default function Layout({children}:{children:React.ReactNode}) { return <InternalAppShell>{children}</InternalAppShell>; }\n`);
for (const section of ['dashboard','conversations','tickets','knowledge','analytics','users','settings','forbidden']) {
  const directory = section === 'dashboard' ? internalRoot : path.join(internalRoot, section);
  await mkdir(directory, { recursive: true });
  await writeFile(path.join(directory, 'page.tsx'), `import { AdminScreen } from '@/components/admin/admin-screen';\nexport default function Page() { return <AdminScreen section="${section}"/>; }\n`);
}
// Only publishable configuration is copied. No service-role or AI secret is read here.
let envText = '';
try { envText = await readFile(path.join(root, '.env.local'), 'utf8'); } catch {}
const publicEnv = envText.split(/\r?\n/).filter(line => /^NEXT_PUBLIC_SUPABASE_(URL|PUBLISHABLE_KEY|ANON_KEY)=/.test(line));
if (publicEnv.length) await writeFile(path.join(preview, '.env.local'), publicEnv.join('\n') + '\n');
for (const filename of ['tsconfig.json', 'next-env.d.ts', 'postcss.config.mjs']) await cp(path.join(root, filename), path.join(preview, filename));
const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
await writeFile(path.join(preview, 'package.json'), JSON.stringify({ ...pkg, name: 'bilah-public-preview', scripts: {} }, null, 2));
await writeFile(path.join(preview, 'next.config.mjs'), `import path from 'node:path';\nimport { fileURLToPath } from 'node:url';\nexport default { output: 'export', trailingSlash: true, poweredByHeader: false, images: { unoptimized: true }, turbopack: { root: path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..') } };\n`);
const result = spawnSync(process.execPath, [path.join(root, 'node_modules/next/dist/bin/next'), 'build'], { cwd: preview, stdio: 'inherit' });
if (result.status !== 0) process.exit(result.status ?? 1);
await rm(path.join(root, 'dist'), { recursive: true, force: true });
await cp(path.join(preview, 'out'), path.join(root, 'dist'), { recursive: true });
console.log('Public preview ready in dist/. No server APIs or secrets included.');
