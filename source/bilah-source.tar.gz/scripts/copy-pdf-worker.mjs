import {copyFile,mkdir,cp} from 'node:fs/promises';
const root=new URL('../',import.meta.url);
await mkdir(new URL('public/pdfjs/',root),{recursive:true});
await copyFile(new URL('node_modules/pdfjs-dist/legacy/build/pdf.worker.min.mjs',root),new URL('public/pdfjs/pdf.worker.min.mjs',root));
for(const directory of ['standard_fonts','cmaps'])await cp(new URL('node_modules/pdfjs-dist/'+directory+'/',root),new URL('public/pdfjs/'+directory+'/',root),{recursive:true});
console.log('PDF reader worker prepared locally.');
