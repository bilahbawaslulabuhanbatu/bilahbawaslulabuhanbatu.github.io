"""Train only on approved public passages; input JSON array = Indonesian PG lexemes per passage."""
import json,sys,numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
v=TfidfVectorizer(tokenizer=str.split,token_pattern=None,binary=True,lowercase=False,min_df=2,max_df=.92,max_features=4000)
m=v.fit_transform(json.load(open(sys.argv[1])))
model=TruncatedSVD(n_components=32,random_state=42).fit(m)
json.dump({t:[round(float(x),6) for x in model.components_[:,i]*v.idf_[i]] for i,t in enumerate(v.get_feature_names_out())},open(sys.argv[2],'w'),separators=(',',':'))
