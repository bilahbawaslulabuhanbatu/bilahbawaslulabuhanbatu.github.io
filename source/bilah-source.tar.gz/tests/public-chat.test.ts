import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPublicChatHandler} from '../src/lib/chat/public-handler.ts';
const session='a'.repeat(64),requestId='72b83a65-b08f-46d5-8d51-745df880ad12';
function req(question='Apa tugas Bawaslu?'){return new Request('https://function.example',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://bilah-labuhanbatu-ray.rangkutiray3.chatgpt.site'},body:JSON.stringify({question,sessionToken:session,requestId})});}
function fixture(options:{begin?:string;quota?:boolean;finish?:boolean;failModel?:boolean;rows?:boolean;previousQuestions?:string[];reason?:string}={}){
 const calls:string[]=[],payloads:{name:string;body:any}[]=[];
 const values:Record<string,string>={SUPABASE_URL:'https://db.example',SUPABASE_SERVICE_ROLE_KEY:'backend-only-secret',AI_API_KEY:'private-model-key'};
 const source='Sekretariat Bawaslu memberikan dukungan administrasi dan teknis operasional.';
 const fetcher:typeof fetch=async(input,init)=>{
  const url=String(input);calls.push(url);assert(!url.includes('backend-only-secret'));assert(!url.includes('private-model-key'));
  if(url.includes('/rpc/')){
   assert.equal(new Headers(init?.headers).get('apikey'),'backend-only-secret');const name=url.split('/').pop()!;const body=JSON.parse(String(init?.body));payloads.push({name,body});
   if(name==='bilah_public_chat_begin')return Response.json({state:options.begin??'new',reason:options.reason,previousQuestions:options.previousQuestions,response:{answer:'Tersimpan',sources:[],mode:'guardrail',decision:'information',recorded:true}});
   if(name==='bilah_rag_search')return Response.json(options.rows===false?[]:[{document_id:'d',chunk_id:'c',title:'Sumber Bawaslu',version:1,source_url:'https://bawaslu.go.id/',section_reference:'Bagian 1',content:source}]);
   if(name==='bilah_public_ai_reserve')return Response.json(options.quota!==false);
   if(name==='bilah_public_chat_finish')return Response.json(options.finish!==false);
  }
  if(url.includes('googleapis')){
   assert.equal(new Headers(init?.headers).get('x-goog-api-key'),'private-model-key');assert(!String(init?.body).includes('backend-only-secret'));assert(!String(init?.body).includes(session));
   if(options.failModel)throw new DOMException('private details','TimeoutError');
   return Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify({status:'answered',paragraphs:[{text:'Sekretariat membantu melalui dukungan administrasi dan teknis operasional.',citations:[{sourceId:'c',quote:source}]}]})}]}}]});
  }
  throw Error('Unexpected request');
 };
 return {handler:createPublicChatHandler({get:k=>values[k]},fetcher),calls,payloads};
}
test('chat publik tanpa login memakai RPC server dan mencatat pasangan pesan sebelum menyatakan tersimpan',async()=>{
 const f=fixture(),response=await f.handler(req());assert.equal(response.status,200);const answer=await response.json();assert.equal(answer.recorded,true);assert.equal(answer.basis,'knowledge');
 assert.deepEqual(f.payloads.map(p=>p.name),['bilah_public_chat_begin','bilah_rag_search','bilah_public_ai_reserve','bilah_public_chat_finish']);
 const begin=f.payloads[0].body;assert.notEqual(begin.p_session_hash,session);assert.match(begin.p_session_hash,/^[a-f0-9]{64}$/);assert(!JSON.stringify(answer).includes('secret'));
 const failure=await fixture({finish:false}).handler(req());assert.equal(failure.status,503);assert.notEqual((await failure.json()).recorded,true);
});
test('data pribadi, origin lain, dan input rusak ditolak sebelum ditulis atau dikirim ke model',async()=>{
 for(const question of ['NIK: 1234567890123456','hubungi saya 081234567890','email saya contoh@example.com']){
  const f=fixture();assert.equal((await f.handler(req(question))).status,400);assert.equal(f.calls.length,0);
 }
 const f=fixture(),foreign=req();foreign.headers.set('Origin','https://evil.test');assert.equal((await f.handler(foreign)).status,403);assert.equal(f.calls.length,0);
 const malformed=new Request('https://function.example',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});assert.equal((await f.handler(malformed)).status,400);
});
test('permintaan ulang, pembatasan dan kuota tidak memicu panggilan model tambahan',async()=>{
 for(const state of ['complete','limited','pending']){
  const f=fixture({begin:state});const r=await f.handler(req());assert.equal(r.status,state==='complete'?200:state==='limited'?429:409);assert.equal(f.calls.length,1);
 }
 const f=fixture({quota:false}),r=await f.handler(req());assert.equal(r.status,200);assert.equal((await r.json()).decision,'unavailable');assert(!f.calls.some(u=>u.includes('googleapis')));
});
test('batas domain tetap tercatat tanpa panggilan AI dan tiket tidak diklaim terkirim',async()=>{
 const f=fixture();const r=await f.handler(req('Berapa jarak bumi ke bulan?'));assert.equal((await r.json()).decision,'out_of_domain');assert(!f.calls.some(u=>u.includes('googleapis')));
 const human=fixture();const body=await (await human.handler(req('Saya ingin bicara dengan petugas.'))).json();assert(body.answer.includes('tombol Butuh bantuan petugas'));assert(body.answer.includes('setelah Anda menyetujui'));assert(!human.calls.some(url=>url.includes('bilah_ticket_create')));assert(!body.answer.includes('Uji internal'));
});
test('timeout AI tetap menghasilkan cuplikan bersumber dan pencatatan nyata',async()=>{
 const f=fixture({failModel:true});const result=await (await f.handler(req())).json();assert.equal(result.delivery,'excerpt');assert.equal(result.recorded,true);assert.equal(result.sources.length,1);
});

test('handler membawa konteks pertanyaan yang dimuat server dari sesi',async()=>{
 const f=fixture({previousQuestions:['apakah kepala daerah boleh berkampanye?']});
 await f.handler(req('bagaimana jika berkampanye tanpa izin cuti?'));
 const terms=f.payloads.find(p=>p.name==='bilah_rag_search')?.body.search_terms;
 assert(terms.includes('kepala'));assert(terms.includes('cuti'));
});

test('batas pesan menit dibedakan dari batas sesi dan layanan harian',async()=>{
 for(const [reason,expected] of [['minute',/satu menit/],['session_day',/sesi atau jaringan/],['service_day',/seluruh layanan/]] as const){
 const f=fixture({begin:'limited',reason});const r=await f.handler(req());assert.equal(r.status,429);assert.match((await r.json()).message,expected);assert.ok(!f.calls.some(c=>c.includes('googleapis')));
 }
});
