import {test} from 'node:test';
import assert from 'node:assert/strict';
import {classifyQuestion,retrievalTerms} from '../src/lib/guardrails/classify.ts';
import {groundedAnswer} from '../src/lib/ai/grounded.ts';
import {relevantExcerpt} from '../src/lib/ai/excerpt.ts';
import {GeminiProvider} from '../src/lib/ai/gemini-provider.ts';
test('sengketa dipahami dalam konteks layanan tanpa mewajibkan kata pemilu',()=>{
 for(const q of ['bagaimana cara mengajukan permohonan sengketa','gimana mengajukan sengketa','Apa saja divisi di Bawaslu?'])assert.equal(classifyQuestion(q),'information');
 assert.equal(classifyQuestion('bagaimana cara mengajukan permohonan'),'ambiguous');
 assert.equal(classifyQuestion('bagaimana menyelesaikan sengketa tanah'),'out_of_domain');
 assert.equal(classifyQuestion('bagaimana mengajukan sengketa waris'),'out_of_domain');
 const terms=retrievalTerms('bagaimana cara mengajukan permohonan sengketa');
 assert(terms.includes('sengketa'));assert(!terms.includes('ppid'));
 assert(retrievalTerms('bagaimana mengajukan permohonan informasi publik').includes('ppid'));
});
const body='Pasal 32\n\n(1) Penyampaian permohonan secara langsung dilakukan melalui loket penerimaan permohonan sengketa di kantor Bawaslu Kabupaten/Kota.\n\n(2) Ketentuan pelayanan mengikuti peraturan.';
const row={document_id:'d',chunk_id:'c',title:'Peraturan Tata Cara Penyelesaian Sengketa Proses Pemilu',version:1,source_url:'https://jdih.bawaslu.go.id/',section_reference:'Halaman PDF 15',content:body};
test('asumsi jenis sengketa dinyatakan; sumber dan parafrase tetap diperiksa',async()=>{
 const provider={generate:async()=>({status:'answered',paragraphs:[{text:'Permohonan secara langsung disampaikan melalui loket penerimaan di kantor Bawaslu Kabupaten/Kota.',citations:[{sourceId:'c',quote:'Penyampaian permohonan secara langsung dilakukan melalui loket penerimaan permohonan sengketa di kantor Bawaslu Kabupaten/Kota.'}]}]})};
 const result=await groundedAnswer('bagaimana cara mengajukan permohonan sengketa',async()=>[row],provider);
 assert.equal(result.basis,'knowledge');assert(result.answer.includes('Jika yang dimaksud sengketa Pemilihan (Pilkada)'));assert.equal(result.sources[0].chunkId,'c');
 const explicit=await groundedAnswer('bagaimana cara mengajukan permohonan sengketa pemilu',async()=>[row],provider);
 assert(!explicit.answer.includes('Jika yang dimaksud'));assert.equal(explicit.basis,'knowledge');
});
test('sumber khusus Pemilu tidak diterapkan untuk sengketa Pilkada',async()=>{
 const result=await groundedAnswer('bagaimana cara mengajukan permohonan sengketa pilkada',async()=>[row],{generate:async()=>{throw Error('must not apply Pemilu source');}});
 assert.equal(result.decision,'no_source');
});
test('cuplikan cadangan mengambil awal pasal yang sesuai, bukan kepala halaman atau ayat yang terpotong',()=>{
 const page='- 15 -\nhttps://jdih.bawaslu.go.id/\n\n'+body+'\n\nPasal 33\n\n(1) Rapat pleno dilakukan pada hari yang sama.';
 const excerpt=relevantExcerpt(page,'bagaimana mengajukan permohonan sengketa');
 assert(excerpt.startsWith('Pasal 32'));assert(excerpt.includes('loket penerimaan'));assert(!excerpt.includes('https:'));assert(!excerpt.includes('Pasal 33'));assert(!excerpt.includes('(2)'));assert(page.includes(excerpt));
});
test('model Flash-Lite memakai tingkat pemrosesan minimal yang didukung',async()=>{
 const p=new GeminiProvider('private','gemini-3.5-flash-lite',async(_url,init)=>{
  const request=JSON.parse(String(init?.body));assert.equal(request.generationConfig.thinkingConfig.thinkingLevel,'MINIMAL');
  return Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:'{"status":"insufficient","paragraphs":[]}'}]}}]});
 });
 await p.generate({question:'q',context:[]});
});
