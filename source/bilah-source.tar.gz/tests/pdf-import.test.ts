import {test} from 'node:test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {readPdf} from '../src/lib/knowledge/read-pdf.ts';
import {inferPdfMetadata,textFromPdfItems} from '../src/lib/knowledge/pdf-metadata.ts';
import {previewAnswer} from '../src/lib/ai/pipeline.ts';
const worker=pathToFileURL(process.cwd()+'/node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs').href;
function fixture(text:string){
 const stream=text?`BT /F1 12 Tf 40 100 Td (${text}) Tj ET`:'';
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 800] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`];
 let pdf='%PDF-1.4\n',offsets=[0];
 objects.forEach((object,i)=>{offsets.push(pdf.length);pdf+=`${i+1} 0 obj\n${object}\nendobj\n`;});
 const xref=pdf.length;pdf+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
 for(const offset of offsets.slice(1))pdf+=`${String(offset).padStart(10,'0')} 00000 n \n`;
 pdf+=`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
 return new File([pdf],'Peraturan Bawaslu Nomor 1 Tahun 2021.pdf',{type:'application/pdf'});
}
test('PDF asli dibaca menjadi teks, halaman, identitas dan hash yang stabil',async()=>{
 const file=fixture('Pasal 92 Sekretariat Bawaslu mempunyai tugas dukungan administrasi.');
 const parsed=await readPdf(file,()=>{},new AbortController().signal,worker);
 assert.equal(parsed.pages,1);assert.equal(parsed.year,'2021');assert(parsed.content.includes('[[HALAMAN PDF 1]]'));assert(parsed.content.includes('Pasal 92'));assert.match(parsed.sha256,/^[a-f0-9]{64}$/);
 const copy=await readPdf(file,()=>{},new AbortController().signal,worker);assert.equal(copy.sha256,parsed.sha256);
});
test('berkas palsu dan PDF tanpa teks ditolak dengan pesan yang dapat ditindaklanjuti',async()=>{
 await assert.rejects(()=>readPdf(new File(['not a PDF'],'fake.pdf'),()=>{},new AbortController().signal,worker),/tidak dikenali/);
 await assert.rejects(()=>readPdf(fixture(''),()=>{},new AbortController().signal,worker),/OCR belum tersedia/);
});
test('metadata adalah usulan dan nama berkas tetap dapat menjadi fallback',()=>{
 assert.equal(inferPdfMetadata('panduan_pelayanan.pdf','').title,'panduan pelayanan');
 assert.equal(inferPdfMetadata('Peraturan Bawaslu Nomor 1 Tahun 2021.pdf','Teks mengutip Nomor 7 Tahun 2017').year,'2021');
 assert.equal(textFromPdfItems([{str:'Pasal 1',hasEOL:true},{str:'Isi sumber.'}]),'Pasal 1\nIsi sumber.');
});
test('sumber unggahan terverifikasi menyertakan nama berkas dan halaman tanpa tautan palsu',async()=>{
 const row={document_id:'d',chunk_id:'c',title:'Peraturan uji',version:1,source_url:null,source_origin:'uploaded_pdf',source_filename:'uji.pdf',source_sha256:'a'.repeat(64),section_reference:'Halaman PDF 2 · bagian 1',content:'Teks fiktif untuk pengujian perangkat lunak.',score:1};
 const result=await previewAnswer('Apa tugas Bawaslu?',async()=>[row]);assert.equal(result.sources[0].filename,'uji.pdf');assert.equal(result.sources[0].url,undefined);assert.match(result.sources[0].section??'',/Halaman PDF 2/);
 const invalid=await previewAnswer('Apa tugas Bawaslu?',async()=>[{...row,source_sha256:null}]);assert.equal(invalid.decision,'no_source');
});
