import {test} from 'node:test';import assert from 'node:assert/strict';
import {evidenceSpans} from '../src/lib/ai/gemini-provider.ts';
import {validateGroundedOutput} from '../src/lib/ai/grounded.ts';
test('rujukan tidak bergeser ke pasal berikutnya pada satu halaman PDF',()=>{
 const a='Pasal 200\n\nKetentuan pertama dengan penjelasan yang cukup panjang.',b='Pasal 201\n\nKetentuan lain yang juga tampil pada halaman yang sama.';
 const page=a+'\n\nBAB V\n\nJUDUL BAGIAN\n\n'+b;
 assert.ok(evidenceSpans(page).includes(a));assert.ok(!evidenceSpans(page).some(s=>s.includes('200')&&s.includes('201')));
 const payload={status:'answered',paragraphs:[{text:'Ketentuan ini terdapat dalam Pasal 200.',citations:[{sourceId:'a',quote:b}]}]};
 assert.equal(validateGroundedOutput(payload,[{content:page,source:{title:'Undang-undang',version:1,chunkId:'a',documentId:'d'}}]),null);
});
