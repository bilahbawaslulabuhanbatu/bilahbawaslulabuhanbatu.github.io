import {test} from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {contextualQuestion} from '../src/lib/chat/question-context.ts';
import {retrievalTerms,classifyQuestion} from '../src/lib/guardrails/classify.ts';
const cases=JSON.parse(fs.readFileSync(new URL('./fixtures/conversations-10x5.json',import.meta.url),'utf8')) as string[][];
for(const chain of cases)test('Topik sesi: '+chain[0],()=>{
 const history:string[]=[];for(const question of chain){
 const combined=contextualQuestion(question,history);if(history.length)assert.ok(combined.includes(chain[0]));
 assert.ok(retrievalTerms(combined).length>0);assert.ok(['information','legal','report'].includes(classifyQuestion(combined)));history.unshift(question);
 }
});
