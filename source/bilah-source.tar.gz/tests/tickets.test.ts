import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createTicketHandler} from '../src/lib/tickets/public-handler.ts';
const requestId='c1ef8dc0-77f6-4368-a01b-cb1454dc5b5e',sessionToken='a'.repeat(64),accessCode='b'.repeat(32),ticketNumber='BILAH-2026-000127';
function req(body:unknown){return new Request('https://function.example',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://bilah-labuhanbatu-ray.rangkutiray3.chatgpt.site'},body:JSON.stringify(body)});}
function fixture(options:{limited?:boolean;missing?:boolean;failure?:boolean}={}){
 const calls:{name:string;body:Record<string,unknown>}[]=[];
 const handler=createTicketHandler({get:k=>({SUPABASE_URL:'https://db.example',SUPABASE_SERVICE_ROLE_KEY:'server-only-key'} as Record<string,string>)[k]},async(input,init)=>{
  const url=String(input);assert(!url.includes('server-only-key'));assert(!url.includes(accessCode));assert(!url.includes('googleapis'));
  assert.equal(new Headers(init?.headers).get('apikey'),'server-only-key');
  const body=JSON.parse(String(init?.body));const name=url.split('/').pop()!;calls.push({name,body});
  assert(!JSON.stringify(body).includes(accessCode));assert(!JSON.stringify(body).includes(sessionToken));
  if(options.failure)return new Response('private SQL details',{status:500});
  if(name==='bilah_ticket_rate')return Response.json(!options.limited);
  if(options.missing)return Response.json(null);
  return Response.json(name==='bilah_ticket_create'?{ticketNumber,status:'baru',createdAt:'2026-11-05T00:00:00Z'}:{ticketNumber,status:'selesai',question:'Pertanyaan',createdAt:'2026-11-05T00:00:00Z',updatedAt:'2026-11-05T00:00:00Z',resolvedAt:null,replies:[{message:'Tanggapan publik',createdAt:'2026-11-05T00:00:00Z'}]});
 });return {handler,calls};
}
const creation={action:'create',requestId,sessionToken,accessCode,category:'pelayanan-ppid',consent:true};
test('pembuatan tiket membutuhkan persetujuan dan sesi, tanpa akun masyarakat atau panggilan AI',async()=>{
 const f=fixture(),response=await f.handler(req(creation));assert.equal(response.status,200);const body=await response.json();assert.equal(body.ticketNumber,ticketNumber);assert(!('accessCode' in body));assert(!JSON.stringify(body).includes('server-only-key'));
 assert.deepEqual(f.calls.map(c=>c.name),['bilah_ticket_rate','bilah_ticket_create']);
 assert.match(String(f.calls[1].body.p_session_hash),/^[a-f0-9]{64}$/);assert.match(String(f.calls[1].body.p_access_hash),/^[a-f0-9]{64}$/);
 const invalid=fixture();assert.equal((await invalid.handler(req({...creation,consent:false}))).status,400);assert.equal(invalid.calls.length,0);
});
test('lookup memakai POST, kode hash, rate limit, dan pesan seragam untuk kredensial tidak cocok',async()=>{
 const f=fixture();const response=await f.handler(req({action:'lookup',ticketNumber:ticketNumber.toLowerCase(),accessCode}));assert.equal(response.status,200);assert.equal(f.calls[1].body.p_number,ticketNumber);
 const missing=await fixture({missing:true}).handler(req({action:'lookup',ticketNumber,accessCode}));assert.equal(missing.status,404);assert.equal((await missing.json()).message,'Nomor tiket atau kode akses tidak sesuai.');
 const limited=fixture({limited:true});assert.equal((await limited.handler(req(creation))).status,429);assert.equal(limited.calls.length,1);
});
test('origin lain, input palsu, kode pendek dan balasan server sensitif ditolak',async()=>{
 const f=fixture(),foreign=req(creation);foreign.headers.set('Origin','https://evil.test');assert.equal((await f.handler(foreign)).status,403);assert.equal(f.calls.length,0);
 assert.equal((await f.handler(req({...creation,accessCode:'1234'}))).status,400);
 assert.equal((await f.handler(req({...creation,sessionToken:'fake'}))).status,400);
 const fail=await fixture({failure:true}).handler(req(creation));assert.equal(fail.status,503);assert(!(await fail.text()).includes('private SQL'));
});
test('hash kode pelacakan tidak berubah ketika kunci backend diputar',async()=>{
 const hashes:string[]=[];
 for(const key of ['first-server-key','rotated-server-key']){
  const handler=createTicketHandler({get:k=>k==='SUPABASE_URL'?'https://db.example':k==='SUPABASE_SERVICE_ROLE_KEY'?key:undefined},async(url,init)=>{
   const body=JSON.parse(String(init?.body));if(String(url).endsWith('/bilah_ticket_rate'))return Response.json(true);hashes.push(body.p_access_hash);return Response.json({ticketNumber,status:'baru'});
  });await handler(req({action:'lookup',ticketNumber,accessCode}));
 }
 assert.equal(hashes[0],hashes[1]);
});
