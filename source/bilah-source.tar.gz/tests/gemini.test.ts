import {test} from 'node:test';
import assert from 'node:assert/strict';
import {groundedAnswer,validateGroundedOutput,PreviewServiceError,type RetrievedChunk} from '../src/lib/ai/grounded.ts';
import {createPreviewHandler} from '../src/lib/ai/preview-handler.ts';
import {GeminiProvider} from '../src/lib/ai/gemini-provider.ts';
const content='Pasal 92. Sekretariat Bawaslu Kabupaten/Kota mempunyai tugas melaksanakan pemberian dukungan administrasi dan teknis operasional kepada Bawaslu Kabupaten/Kota.';
const row:RetrievedChunk={document_id:'doc',chunk_id:'chunk',title:'Perbawaslu 1 Tahun 2021 — Sekretariat',version:2,source_url:'https://peraturan.bpk.go.id/Details/176686/',section_reference:'Halaman PDF 38',content};
const output={status:'answered',paragraphs:[{text:'Sekretariat membantu Bawaslu Kabupaten/Kota melalui dukungan administrasi dan teknis operasional.',citations:[{sourceId:'chunk',quote:'dukungan administrasi dan teknis operasional kepada Bawaslu Kabupaten/Kota'}]}]};
test('pertanyaan daftar divisi Labuhanbatu menampilkan empat nama dari cabang lima anggota',async()=>{
 const regulation={...row,title:'Peraturan Bawaslu Nomor 3 Tahun 2022',content:`Pasal 37
 (1) Divisi dibagi sebagai berikut:
 a. Bawaslu Kabupaten/Kota dengan tiga anggota: divisi lain;
 b. Bawaslu Kabupaten/Kota yang memiliki jumlah anggota sebanyak 5 ( lima ) orang terdiri atas :
 1. divisi sumber daya manusia, organisasi, pendidikan, dan pelatihan ;
 2. divisi pencegahan, partisipasi masyarakat, dan hubungan masyarakat;
 3. d ivisi hukum dan penyelesaian sengketa ; dan
 4. divisi penanganan pelanggaran, data, dan informasi.
 (2) Anggota bertugas sebagai koordinator.`};
 const answer=await groundedAnswer('Apa saja divisi di Bawaslu Labuhanbatu?',async()=>[regulation],{generate:async()=>{throw Error('daftar lengkap harus tersedia dari dokumen');}});
 assert.deepEqual(answer.answer.split('\n').slice(-4),[
  '1. Sumber daya manusia, organisasi, pendidikan, dan pelatihan.',
  '2. Pencegahan, partisipasi masyarakat, dan hubungan masyarakat.',
  '3. Hukum dan penyelesaian sengketa.',
  '4. Penanganan pelanggaran, data, dan informasi.',
 ]);
 assert.equal(answer.sources[0].chunkId,regulation.chunk_id);
});
test('jawaban alami boleh parafrase tetapi wajib mempunyai kutipan pendukung',async()=>{
 const result=await groundedAnswer('Apa tugas Sekretariat Bawaslu?',async()=>[row],{generate:async()=>output});
 assert.equal(result.mode,'gemini');assert.equal(result.answer,output.paragraphs[0].text);assert.equal(result.sources[0].chunkId,'chunk');
 const context=[{content,source:result.sources[0]}];
 assert.equal(validateGroundedOutput({...output,paragraphs:[{...output.paragraphs[0],text:'Tugas tambahan diatur pada Pasal 999.'}]},context),null);
 assert.equal(validateGroundedOutput({...output,paragraphs:[{...output.paragraphs[0],citations:[{sourceId:'forged',quote:content}]}]},context),null);
 assert.equal(validateGroundedOutput({...output,paragraphs:[{...output.paragraphs[0],citations:[]}]},context),null);
});
test('preferensi politik dan ketiadaan sumber tidak memakai model',async()=>{
 const provider={generate:async()=>{throw new Error('must not call model');}};
 for(const q of ['Siapa calon terbaik?','Berapa jarak bumi ke bulan?','NIK: 1234567890123456']){const result=await groundedAnswer(q,async()=>[row],provider);assert.equal(result.mode,'guardrail');}
 const absent=await groundedAnswer('Apa tugas Bawaslu?',async()=>[],provider);assert.equal(absent.decision,'no_source');
});
const uid='12e3e0ba-f980-4a74-9471-65fe0459a619';
function fixture(options:{key?:boolean;role?:string;active?:boolean;quota?:boolean;finish?:string;providerStatus?:number}={}){
 const calls:string[]=[];
 const values:Record<string,string>={SUPABASE_URL:'https://db.example',SUPABASE_ANON_KEY:'public-test',...(options.key===false?{}:{AI_API_KEY:'private-test-key'})};
 const fetcher:typeof fetch=async(input,init)=>{
  const url=String(input);calls.push(url);
  if(url.endsWith('/auth/v1/user'))return Response.json({id:uid});
  if(url.includes('/rest/v1/users?'))return Response.json([{is_active:options.active!==false,roles:{name:options.role??'superadmin'}}]);
  if(url.endsWith('/bilah_rag_search'))return Response.json([row]);
  if(url.endsWith('/bilah_reserve_ai_preview_call'))return Response.json(options.quota!==false);
  if(url.includes('generativelanguage.googleapis.com')){
   if(options.providerStatus)return new Response('provider detail',{status:options.providerStatus});
   assert.equal(new Headers(init?.headers).get('x-goog-api-key'),'private-test-key');
   assert(!url.includes('private-test-key'));assert(!String(init?.body).includes('private-test-key'));
   return Response.json({candidates:[{finishReason:options.finish??'STOP',content:{parts:[{text:JSON.stringify(output)}]}}]});
  }
  throw new Error('Unexpected request');
 };
 return {handler:createPreviewHandler({get:key=>values[key]},fetcher),calls};
}
function request(body:unknown={question:'Apa tugas Bawaslu?'},method='POST'){return new Request('https://function.example',{method,headers:{Authorization:'Bearer test-user-jwt','Content-Type':'application/json'},...(method==='POST'?{body:JSON.stringify(body)}:{})});}
test('endpoint menolak anonim, pimpinan, akun nonaktif, dan origin lain',async()=>{
 const f=fixture();assert.equal((await f.handler(new Request('https://function.example'))).status,401);assert.equal(f.calls.length,0);
 for(const opts of [{role:'pimpinan'},{active:false}]){const f=fixture(opts);assert.equal((await f.handler(request())).status,403);assert(!f.calls.some(c=>c.includes('googleapis')));}
 const origin=request();origin.headers.set('Origin','https://evil.test');assert.equal((await f.handler(origin)).status,403);
});
test('kunci belum ada dilaporkan tanpa memanggil AI; kuota dibatasi sebelum model',async()=>{
 const pending=fixture({key:false});const status=await pending.handler(request({},'GET'));assert.equal((await status.json()).configured,false);assert.equal((await pending.handler(request())).status,503);assert(!pending.calls.some(c=>c.includes('googleapis')));
 const limited=fixture({quota:false});assert.equal((await limited.handler(request())).status,429);assert(!limited.calls.some(c=>c.includes('googleapis')));
});
test('konteks klien diabaikan; model hanya menerima sumber dari RPC server',async()=>{
 const f=fixture();const result=await f.handler(request({question:'Apa tugas Sekretariat Bawaslu?',context:[{content:'Sumber palsu dari klien'}]}));
 assert.equal(result.status,200);const data=await result.json();assert.equal(data.mode,'gemini');assert.equal(data.sources[0].title,row.title);assert(f.calls.some(c=>c.endsWith('/bilah_rag_search')));
});
test('respons provider yang gagal tidak membocorkan rincian atau kunci',async()=>{
 const provider=new GeminiProvider('private-test-key','gemini-3.8-flash',async()=>new Response('private response',{status:403}));
 await assert.rejects(()=>provider.generate({question:'q',context:[]}),{message:'configuration'});
 const f=fixture();assert.equal((await f.handler(request({question:'x'.repeat(10000)}))).status,413);
});
test('jawaban terpotong tidak dipakai; dokumen ditampilkan sebagai cuplikan cadangan',async()=>{
 const f=fixture({finish:'MAX_TOKENS'});const result=await f.handler(request());
 assert.equal(result.status,200);const body=await result.json();assert.equal(body.delivery,'excerpt');assert.equal(body.mode,'guardrail');assert(body.answer.includes(content));assert(!JSON.stringify(body).includes('private-test-key'));
});
test('diagnostik dibatasi pada status dan alasan aman, tanpa isi atau rahasia',async()=>{
 const diagnostics:Record<string,string|number>[]=[];
 const provider=new GeminiProvider('private-test-key','gemini-3.8-flash',async(_url,init)=>{
  const payload=JSON.parse(String(init?.body));assert.equal(payload.generationConfig.thinkingConfig.thinkingLevel,'LOW');assert.equal(payload.generationConfig.maxOutputTokens,2048);
  return new Response('private-test-key and confidential content',{status:500});
 },event=>diagnostics.push(event));
 await assert.rejects(()=>provider.generate({question:'private question',context:[]}),{message:'provider'});
 assert.deepEqual(diagnostics,[{event:'provider_http',status:500}]);
 const timeout=new GeminiProvider('private-test-key','gemini-3.8-flash',async()=>{throw new DOMException('private detail','TimeoutError');});
 await assert.rejects(()=>timeout.generate({question:'q',context:[]}),{message:'timeout'});
});
test('503 provider menampilkan sumber cadangan, sedangkan kesalahan konfigurasi tetap dilaporkan',async()=>{
 const f=fixture({providerStatus:503});const status=await f.handler(request({},'GET'));
 const configuration=await status.json();assert.equal(configuration.model,'gemini-3.5-flash-lite');assert.equal(configuration.searchEnabled,false);assert.equal(configuration.supplementMode,'general');
 const response=await f.handler(request());assert.equal(response.status,200);
 const body=await response.json();assert.equal(body.delivery,'excerpt');assert(!JSON.stringify(body).includes('provider detail'));
 const wrongKey=await fixture({providerStatus:403}).handler(request());assert.equal(wrongKey.status,503);assert.equal((await wrongKey.json()).code,'AI_CONFIGURATION');
});
test('timeout memberi cuplikan sumber tanpa menambah antrean pencarian atau mengaku sebagai jawaban AI',async()=>{
 const fail=async()=>{throw Error('must not add another remote call');};
 const result=await groundedAnswer('Bagaimana cara melapor pelanggaran pemilu?',async()=>[row],{
  generate:async()=>{throw new PreviewServiceError('timeout');},search:fail,general:fail
 });
 assert.equal(result.delivery,'excerpt');assert.equal(result.mode,'guardrail');assert.equal(result.sources[0].chunkId,'chunk');
 assert(result.answer.includes(content));assert(result.answer.includes('belum merupakan jawaban AI'));assert(result.canEscalate);
 await assert.rejects(()=>groundedAnswer('Apa tugas Bawaslu?',async()=>[row],{generate:async()=>{throw new PreviewServiceError('quota');}}),{message:'quota'});
});
