import { test } from 'node:test';
import assert from 'node:assert/strict';
import { can, isRole } from '../src/lib/auth/permissions.ts';
import { environmentSchema } from '../src/lib/config/schema.ts';

test('pimpinan hanya membaca agregat, tidak bisa mengubah dokumen atau membaca percakapan', () => {
  assert.equal(can('pimpinan', 'dashboard:read'), true);
  assert.equal(can('pimpinan', 'analytics:read'), true);
  for (const permission of ['knowledge:write', 'conversations:read', 'users:manage', 'tickets:all', 'settings:write'] as const) assert.equal(can('pimpinan', permission), false);
});
test('petugas tidak boleh mengakses semua tiket atau mengubah knowledge base', () => {
  assert.equal(can('petugas', 'tickets:assigned'), true);
  assert.equal(can('petugas', 'tickets:all'), false);
  assert.equal(can('petugas', 'knowledge:write'), false);
});
test('admin tidak dapat memberi dirinya peran superadmin', () => {
  assert.equal(can('admin', 'users:manage'), false);
  assert.equal(can('superadmin', 'users:manage'), true);
});
test('peran tidak dikenal ditolak', () => {
  for (const value of [undefined, null, '', 'owner', '__proto__', {}, 'ADMIN']) {
    assert.equal(isRole(value), false);
    assert.equal(can(value, 'dashboard:read'), false);
  }
});
test('mode mock default aktif dan string false tidak ditafsirkan sebagai true', () => {
  assert.equal(environmentSchema.parse({}).MOCK_AI_MODE, true);
  assert.equal(environmentSchema.parse({ MOCK_AI_MODE: 'false', AI_PROVIDER: 'test', AI_MODEL: 'test', AI_API_KEY: 'test-only' }).MOCK_AI_MODE, false);
});
test('konfigurasi AI nyata yang tidak lengkap dan konfigurasi Supabase parsial ditolak', () => {
  assert.equal(environmentSchema.safeParse({ MOCK_AI_MODE: 'false' }).success, false);
  assert.equal(environmentSchema.safeParse({ NEXT_PUBLIC_SUPABASE_URL: 'https://example.supabase.co' }).success, false);
  assert.equal(environmentSchema.safeParse({ CHAT_RATE_LIMIT_PER_MINUTE: 0 }).success, false);
});

test('configuration accepts the recommended publishable key', () => {
  assert.equal(environmentSchema.safeParse({ NEXT_PUBLIC_SUPABASE_URL: 'https://example.supabase.co', NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_test' }).success, true);
});
