import {test} from 'node:test';
import assert from 'node:assert/strict';
import {groundedAnswer} from '../src/lib/ai/grounded.ts';
import {classifyQuestion,retrievalTerms} from '../src/lib/guardrails/classify.ts';
import {requiresOfficialSource,validateGeneral,validateSearch,officialSearchURL} from '../src/lib/ai/supplement.ts';
import {SupplementProvider} from '../src/lib/ai/supplement-provider.ts';
import {createPreviewHandler} from '../src/lib/ai/preview-handler.ts';
const conceptual={answer:'Pengawasan partisipatif adalah keterlibatan masyarakat dalam mengawasi jalannya pemilu agar lebih jujur dan adil.',sources:[],basis:'general' as const};
test('bahasa percakapan dipahami tanpa membuka domain lain',()=>{
 assert.equal(classifyQuestion('gimana mau ngelapor pelanggaran pemilu?'),'report');
 assert.equal(classifyQuestion('apakah saya bisa melapor pelanggaran pemilu?'),'report');
 assert.equal(classifyQuestion('Apakah tindakan calon ini merupakan pelanggaran?'),'legal');
 assert.equal(classifyQuestion('cara lapor pajak'),'out_of_domain');
 assert(retrievalTerms('gimana ngelapor pelanggaran').includes('laporan'));
});
test('konsep umum dijawab tanpa pencarian dokumen dengan label terpisah',async()=>{
 const calls:string[]=[];
 const result=await groundedAnswer('Apa itu pengawasan partisipatif?',async()=>{throw Error('unexpected document search')},{
  generate:async()=>{throw Error('no KB');},search:async()=>{calls.push('web');return null;},general:async()=>{calls.push('general');return conceptual;}
 });
 assert.deepEqual(calls,['general']);assert.equal(result.basis,'general');assert.equal(result.sources.length,0);
});
test('prosedur dan fakta terkini tidak memakai fallback pengetahuan umum',async()=>{
 for(const question of ['gimana cara melapor pelanggaran pemilu?','Siapa ketua Bawaslu sekarang?','Apa sanksi pelanggaran pemilu?']){
  assert(requiresOfficialSource(question));
  const result=await groundedAnswer(question,async()=>[],{generate:async()=>null,search:async()=>null,general:async()=>{throw Error('must not call');}});
  assert.equal(result.decision,'no_source');
 }
 assert.equal(validateGeneral({status:'general',answer:'Menurut Pasal 99, laporan disampaikan dalam 7 hari.'},'Apa itu pemilu?'),null);
 assert.equal(validateGeneral({status:'general',answer:conceptual.answer},'Apa itu pengawasan partisipatif?')?.basis,'general');
});
test('batas politik dan domain tetap berlaku sebelum suplemen',async()=>{
 for(const q of ['Siapa calon terbaik?','Berapa jarak bumi ke bulan?','NIK: 1234567890123456']){
  const fail=async()=>{throw Error('must not call');};
  assert.equal((await groundedAnswer(q,fail,{generate:fail,search:fail,general:fail})).mode,'guardrail');
 }
});
const sentence='Pengawasan partisipatif melibatkan masyarakat dalam pengawasan pemilu.';
function searchCandidate(uri='https://bawaslu.go.id/contoh'){
 return {finishReason:'STOP',content:{parts:[{text:sentence+' Pernyataan tambahan tanpa sumber.'}]},groundingMetadata:{groundingChunks:[{web:{uri,title:'Bawaslu'}}],groundingSupports:[{segment:{text:sentence},groundingChunkIndices:[0]}],searchEntryPoint:{renderedContent:'<div>Penelusuran Google</div>'}}};
}
test('hasil web hanya menampilkan segmen yang didukung sumber resmi',async()=>{
 const noFetch:typeof fetch=async()=>{throw Error('must not fetch');};
 const result=await validateSearch(searchCandidate(),noFetch);
 assert.equal(result?.answer,sentence);assert.equal(result?.basis,'web');assert.equal(result?.sources[0].version,0);
 assert.equal(await validateSearch(searchCandidate('https://bawaslu.go.id.evil.test/'),noFetch),null);
 const noSupport=searchCandidate();noSupport.groundingMetadata.groundingSupports=[];
 assert.equal(await validateSearch(noSupport,noFetch),null);
 const noSuggestions=searchCandidate();noSuggestions.groundingMetadata.searchEntryPoint.renderedContent='';
 assert.equal(await validateSearch(noSuggestions,noFetch),null);
});
test('redirect Google dibatasi; alamat arbitrer dan skema lokal tidak diakses',async()=>{
 let count=0;const resolver:typeof fetch=async(_url,init)=>{count++;assert.equal(init?.redirect,'manual');return new Response(null,{status:302,headers:{Location:'https://labuhanbatu.bawaslu.go.id/profil'}});};
 assert.equal(await officialSearchURL('https://vertexaisearch.cloud.google.com/grounding-api-redirect/id',resolver),'https://labuhanbatu.bawaslu.go.id/profil');
 assert.equal(await officialSearchURL('http://127.0.0.1/private',resolver),null);assert.equal(count,1);
 assert.equal(await officialSearchURL('https://vertexaisearch.cloud.google.com/grounding-api-redirect/id',async()=>new Response(null,{status:302,headers:{Location:'http://169.254.169.254/latest'}})),null);
});
test('pencarian menggunakan model dengan kuota pencarian gratis dan tidak mengekspos kunci',async()=>{
 const p=new SupplementProvider('private-key',async(url,init)=>{
  assert(String(url).includes('/gemini-2.5-flash-lite:generateContent'));
  const body=JSON.parse(String(init?.body));assert(body.tools[0].google_search);assert(!String(init?.body).includes('private-key'));
  assert.equal(new Headers(init?.headers).get('x-goog-api-key'),'private-key');
  return Response.json({candidates:[searchCandidate()]});
 });
 assert.equal((await p.search('Apa itu pengawasan partisipatif?'))?.basis,'web');
 const unavailable=new SupplementProvider('private-key',async()=>new Response('private detail',{status:429}));
 assert.equal(await unavailable.search('q'),null);
});
test('endpoint memeriksa dokumen dulu dan setiap panggilan tambahan tetap memakai kuota',async()=>{
 const calls:string[]=[];let reserves=0;
 const fetcher:typeof fetch=async(input)=>{
  const url=String(input);calls.push(url);
  if(url.endsWith('/auth/v1/user'))return Response.json({id:'12e3e0ba-f980-4a74-9471-65fe0459a619'});
  if(url.includes('/rest/v1/users?'))return Response.json([{is_active:true,roles:{name:'admin'}}]);
  if(url.endsWith('/bilah_rag_search'))return Response.json([]);
  if(url.endsWith('/bilah_reserve_ai_preview_call')){reserves++;return Response.json(true);}
  if(url.includes('gemini-2.5-flash-lite'))return Response.json({candidates:[searchCandidate()]});
  throw Error('Unexpected request');
 };
 const values:Record<string,string>={SUPABASE_URL:'https://db.example',SUPABASE_ANON_KEY:'public',AI_API_KEY:'private',AI_SUPPLEMENT_MODE:'web'};
 const handler=createPreviewHandler({get:k=>values[k]},fetcher);
 const response=await handler(new Request('https://function.example',{method:'POST',headers:{Authorization:'Bearer user-session','Content-Type':'application/json'},body:JSON.stringify({question:'Apa tugas Bawaslu?'})}));
 const result=await response.json();assert.equal(result.basis,'web');assert.equal(reserves,1);
 assert(calls.findIndex(s=>s.endsWith('/bilah_rag_search'))<calls.findIndex(s=>s.includes('googleapis')));
});
test('pemilih belum tercatat mendapat tindakan dan kanal resmi tanpa KB atau AI',async()=>{
 const fail=async()=>{throw Error('unexpected call')};
 const r=await groundedAnswer('Data saya belum terdaftar sebagai pemilih, apa yang harus saya lakukan?',fail,{generate:fail,general:fail});
 assert.equal(r.basis,'web');assert.match(r.answer,/pemutakhiran data/);assert(r.sources.some(s=>s.url==='https://cekdptonline.kpu.go.id/'));
});
