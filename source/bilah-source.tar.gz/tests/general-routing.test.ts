import {test} from 'node:test';
import assert from 'node:assert/strict';
import {groundedAnswer} from '../src/lib/ai/grounded.ts';
import {requiresOfficialSource} from '../src/lib/ai/supplement.ts';
import {classifyQuestion} from '../src/lib/guardrails/classify.ts';
const generalQuestions=[
'Apa itu pemilu?','Mengapa pengawasan partisipatif penting?','Apa manfaat demokrasi?',
'Bagaimana cara mengenalkan pemilu kepada anak SMA?','Gimana cara mengecek hoaks pemilu?',
'Bagaimana menyikapi perbedaan pilihan politik dalam pemilu?','Tips berdiskusi tentang pemilu dengan keluarga?',
'Bagaimana menjaga kerahasiaan pilihan politik dalam pemilu?','Apa itu netralitas ASN?',
'Mengapa Bawaslu penting?','Apa tujuan kampanye?','Bagaimana membedakan informasi kampanye dan hoaks?',
'Mengapa pemilih perlu memeriksa informasi calon?','Apa pengertian golput?','Cara belajar tentang demokrasi?',
'Mengapa partisipasi pemilih penting?','Bagaimana menghadapi hoaks di grup keluarga?'
];
for(const question of generalQuestions)test('umum: '+question,async()=>{
 assert.equal(classifyQuestion(question),'information');
 assert.equal(requiresOfficialSource(question),false);
 const r=await groundedAnswer(question,async()=>{throw Error('must not search KB')},{generate:async()=>{throw Error('must not generate grounded')},general:async()=>({answer:'Penjelasan umum sesuai kebutuhan penanya.',sources:[],basis:'general'})});
 assert.equal(r.basis,'general');
});
for(const question of ['Siapa ketua Bawaslu saat ini?','Bagaimana mengajukan sengketa pemilu?','Apa sanksi ASN berkampanye?','Kapan pendaftaran pemilih ditutup?','Apa syarat pindah memilih?','Bagaimana cara melapor pelanggaran pemilu?'])test('rujukan: '+question,()=>assert(requiresOfficialSource(question)));
test('netralitas tidak menolak edukasi calon, tetapi menolak rekomendasi politik',()=>{
 assert.equal(classifyQuestion('Siapa calon terbaik?'),'political');
 assert.equal(classifyQuestion('Partai mana yang harus saya pilih?'),'political');
});
