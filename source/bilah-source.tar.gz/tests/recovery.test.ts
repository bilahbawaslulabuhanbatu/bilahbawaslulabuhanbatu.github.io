import {test} from 'node:test';
import assert from 'node:assert/strict';
import {groundedAnswer,validateGroundedOutput} from '../src/lib/ai/grounded.ts';
import {contextualQuestion} from '../src/lib/chat/question-context.ts';
const fail=async()=>{throw Error('unexpected provider call')};
for(const q of ['Ktp saya belum selesai, apakah saya tetap bisa memilih di tps?','Kartu tanda penduduk masih diproses, boleh mencoblos?', 'E-KTP belum dicetak. Bagaimana saat pemilu?']){
 test(q,async()=>{const a=await groundedAnswer(q,fail,{generate:fail});assert.match(a.answer,/tidak otomatis/);assert.match(a.answer,/Pilkada 2024/);assert.equal(a.sources.length,2);
 const follow=await groundedAnswer(contextualQuestion('Sudah muncul',[q]),fail,{generate:fail});assert.match(follow.answer,/catat lokasi TPS/);});
}
test('invalid citation uses a second source without repeating rejected material',async()=>{
 const a=await groundedAnswer('Apa syarat pindah memilih?',async()=>[{document_id:'d',chunk_id:'c',title:'KPU',version:1,source_url:'https://kpu.go.id/',section_reference:null,content:'Dokumen harus diperiksa terlebih dahulu.'}],{generate:async()=>({status:'answered',paragraphs:[]}),search:async()=>null,navigate:async()=>'Tanyakan dokumen pendukung ke KPU sesuai domisili Anda.'});
 assert.equal(a.decision,'no_source');assert.match(a.answer,/domisili/);assert.deepEqual(a.sources,[]);
});
test('list numbering is not a factual number; invented deadlines remain invalid',()=>{
 const quote='Periksa nama dan simpan hasil pemeriksaan.',source={chunkId:'s',documentId:'d',title:'Panduan',version:1};
 const check=(text:string)=>validateGroundedOutput({status:'answered',paragraphs:[{text,citations:[{sourceId:'s',quote}]}]},[{content:quote,source}]);
 assert(check('1. Periksa nama.\n2. Simpan hasilnya.'));assert.equal(check('1. Tunggu selama 15 hari.'),null);
});
test('general recovery searches using formal terminology for a previously unseen question',async()=>{
 const row=(c:string)=>({document_id:'d',chunk_id:c,title:'KPU',version:1,source_url:'https://kpu.go.id/',section_reference:null,content:c==='new'?'Pemilih dapat meminta informasi kepada petugas setempat.':'Cuplikan tidak relevan.'});
 let calls=0;
 const a=await groundedAnswer('Apa prosedur layanan pemilih keliling?',async terms=>terms.includes('bergerak')?[row('new')]:[row('old')],{generate:async({context})=>{
  calls++;return context[0].source.chunkId==='old'?{status:'insufficient',searchTerms:['bergerak','pelayanan']}:{status:'answered',paragraphs:[{text:context[0].content,citations:[{sourceId:'new',quote:context[0].content}]}]};
 }});assert.equal(calls,2);assert.equal(a.sources[0].chunkId,'new');
});
test('confirmed campaign rule across wording; no automatic verdict on different activities',async()=>{
 for(const q of ['Bolehkah anak kecil ikut berkampanye?','Balita boleh diajak kampanye pemilu?','Bocah boleh ikut kampanye?']){
  const a=await groundedAnswer(q,fail,{generate:fail});assert.match(a.answer,/^Tidak\./);assert.match(a.answer,/huruf k/);assert(a.sources[0].url?.includes('bawaslu.go.id'));
 }
 const a=await groundedAnswer('Bolehkah anak kecil ikut simulasi kampanye di sekolah?',async()=>[],{generate:fail});assert(!a.answer.startsWith('Tidak.'));
});
