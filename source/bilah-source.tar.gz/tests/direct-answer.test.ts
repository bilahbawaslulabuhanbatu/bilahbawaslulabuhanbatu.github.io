import {test} from 'node:test';
import assert from 'node:assert/strict';
import {classifyQuestion,retrievalTerms} from '../src/lib/guardrails/classify.ts';
import {groundedAnswer} from '../src/lib/ai/grounded.ts';

test('pertanyaan nyata yang jelas mencapai pencarian dan AI tanpa klarifikasi kategori',async()=>{
 const content='Dokumen persyaratan pelaporan dan ketentuan netralitas tersedia untuk penjelasan oleh petugas.';
 const row={document_id:'d',chunk_id:'c',title:'Contoh uji',version:1,source_url:'https://bawaslu.go.id/',section_reference:null,content};
 for(const question of ['Apakah ASN boleh berkampanye?','apa yang perlu dibawa pelapor','Apa tugas KPPS?']){
  let retrieved=false,generated=false;
  const answer=await groundedAnswer(question,async()=>{retrieved=true;return [row]}, {generate:async()=>{generated=true;return {status:'answered',paragraphs:[{text:content,citations:[{sourceId:'c',quote:content}]}]}}});
  assert(retrieved);assert(generated);assert.equal(answer.basis,'knowledge');assert.equal(answer.sources.length,1);
 }
 assert(retrievalTerms('Apakah ASN boleh berkampanye?').includes('kampanye'));
 assert(retrievalTerms('apa yang perlu dibawa pelapor').includes('laporan'));
});
test('kekurangan sumber tidak diperlakukan sebagai pertanyaan ambigu',async()=>{
 const answer=await groundedAnswer('Apakah ASN boleh berkampanye?',async()=>[],{generate:async()=>null,general:async()=>null});
 assert.equal(answer.decision,'no_source');assert(answer.canEscalate);assert(!/diperjelas|konteks|kategori/i.test(answer.answer));
});
test('pertanyaan tanpa objek tetap diklarifikasi; batas domain dan kewenangan tetap aktif',async()=>{
 const answer=await groundedAnswer('bagaimana mengajukan permohonan',async()=>{throw Error('not needed')},{generate:async()=>null});
 assert.equal(answer.decision,'ambiguous');assert.equal(answer.answer,'Permohonan apa yang ingin Anda ajukan?');
 assert.equal(classifyQuestion('bagaimana melapor pencurian'),'out_of_domain');
 assert.equal(classifyQuestion('Berapa jarak bumi ke bulan?'),'out_of_domain');
 assert.equal(classifyQuestion('Siapa calon terbaik?'),'political');
 assert.equal(classifyQuestion('Apakah tindakan ASN ini merupakan pelanggaran?'),'legal');
});
test('pencarian ASN dan PNS menyertakan istilah lengkap dalam peraturan',()=>{
 for(const q of ['Apakah ASN boleh berkampanye?','Bolehkah PNS ikut kampanye?','Apakah aparatur sipil negara boleh kampanye?']){
  const terms=retrievalTerms(q);for(const term of ['asn','aparatur','sipil','negara','kampanye'])assert(terms.includes(term));
 }
 assert(!retrievalTerms('Apakah kepala daerah boleh berkampanye?').includes('asn'));
});
test('jawaban ASN langsung saat kedua ketentuan ditemukan, tanpa model atau cuplikan acak',async()=>{
 const row=(id:string,content:string)=>({document_id:'d',chunk_id:id,title:'UU 7 2017 Halaman Asli 1 207',version:1,source_url:'https://peraturan.go.id/',section_reference:null,content});
 const roles=row('a','f. aparatur sipil negara; (3) dilarang ikut serta sebagai pelaksana dan tim Kampanye Pemilu.');
 const neutrality=row('b','Pasal 283 (1) aparatur sipil negara lainnya dilarang mengadakan kegiatan yang mengarah kepada keberpihakan.');
 const q='Apakah ASN boleh berkampanye?';
 const r=await groundedAnswer(q,async()=>[roles,neutrality],{generate:async()=>{throw Error('model should not run')}});
 assert(r.answer.startsWith('Tidak.'));assert.equal(r.sources.length,2);assert.equal(r.basis,'knowledge');
 const partial=await groundedAnswer(q,async()=>[roles],{generate:async()=>({status:'insufficient'})});assert.equal(partial.decision,'no_source');
});
