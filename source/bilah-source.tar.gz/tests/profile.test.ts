import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseInternalProfile} from '../src/lib/auth/profile.ts';

test('unverified and inactive role claims never activate an internal profile',()=>{
 assert.equal(parseInternalProfile({id:'test',is_active:false,roles:{name:'superadmin'}}),null);
 assert.equal(parseInternalProfile({id:'test',is_active:true,user_metadata:{role:'superadmin'}}),null);
 assert.equal(parseInternalProfile({id:'test',is_active:true,roles:{name:'owner'}}),null);
});
test('profile role comes from the database relation',()=>{
 assert.deepEqual(parseInternalProfile({id:'test',display_name:'Petugas uji',is_active:true,roles:{name:'petugas'},user_metadata:{role:'superadmin'}}),{id:'test',name:'Petugas uji',role:'petugas'});
});
