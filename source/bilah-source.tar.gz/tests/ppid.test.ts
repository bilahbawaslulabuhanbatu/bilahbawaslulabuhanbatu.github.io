import {test} from 'node:test';
import assert from 'node:assert/strict';
import {classifyQuestion,isPublicInformationQuestion,retrievalTerms} from '../src/lib/guardrails/classify.ts';
import {groundedAnswer} from '../src/lib/ai/grounded.ts';
test('permintaan informasi dikenali sebagai PPID tanpa tercampur permohonan sengketa',()=>{
 for(const question of ['Bagaimana meminta informasi publik?','gimana minta informasi?','bagaimana mengajukan sengketa informasi?']){
  assert.equal(classifyQuestion(question),'information');assert(isPublicInformationQuestion(question));assert(retrievalTerms(question).includes('ppid'));
 }
 assert(!retrievalTerms('bagaimana mengajukan permohonan sengketa pemilu?').includes('ppid'));
});
test('sengketa informasi tidak diberi asumsi sengketa proses Pemilu',async()=>{
 const result=await groundedAnswer('bagaimana mengajukan sengketa informasi?',async()=>[],{generate:async()=>null});
 assert(!result.answer.includes('sengketa proses Pemilu'));assert.equal(result.decision,'no_source');
});
test('kekurangan sumber PPID tidak dianggap sebagai pertanyaan yang kurang jelas',async()=>{
 const result=await groundedAnswer('Bagaimana meminta informasi publik?',async()=>[],{generate:async()=>null,general:async()=>{throw Error('procedure requires a source');}});
 assert.equal(result.decision,'no_source');assert(result.answer.includes('termasuk layanan PPID'));assert(!result.answer.includes('diperjelas'));
});
