import { test } from 'node:test';
import assert from 'node:assert/strict';
import { containsSensitivePattern, quickQuestions, selectDemoScenario } from '../src/lib/demo/scenarios.ts';

test('contoh pertanyaan belum mengklaim sumber terverifikasi', () => {
  for (const question of quickQuestions) {
    const result = selectDemoScenario(question.title);
    assert.equal(result.sourcePending, true);
    assert(!/Pasal \d|Perbawaslu Nomor \d/.test(result.text));
  }
});
test('simulasi menampilkan netralitas dan batas penilaian', () => {
  assert.equal(selectDemoScenario('Siapa calon terbaik?').category, 'Netralitas politik');
  assert.equal(selectDemoScenario('Berapa jarak bumi ke bulan?').category, 'Di luar cakupan');
  const result = selectDemoScenario('Apakah tindakan calon ini merupakan pelanggaran?');
  assert.equal(result.canEscalate, true);
  assert(result.text.includes('kewenangan pejabat/petugas'));
});
test('permintaan petugas tidak mengklaim tiket berhasil dibuat', () => {
  const result = selectDemoScenario('Saya ingin bicara dengan petugas.');
  assert.equal(result.canEscalate, true);
  assert(result.text.includes('belum dikirim'));
});
test('pola NIK dan password diperingatkan sebelum tampil dalam percakapan', () => {
  assert.equal(containsSensitivePattern('NIK: 1234567890123456'), true);
  assert.equal(containsSensitivePattern('password: contoh-rahasia'), true);
  assert.equal(containsSensitivePattern('Apa tugas Bawaslu?'), false);
});
